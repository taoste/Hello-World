var cfg;

function createFrame(src) {
    var iframe = document.createElement('iframe');
    iframe.src = src;
    iframe.frameBorder = 0;
    iframe.scrolling = 'no';
    iframe.style = 'width:1px;height:1px;margin-left:1px;margin-top:10px;';
    return iframe;
}

function htmlspecialchars(str) {
    str = str.replace(/</g, '&lt;');
    str = str.replace(/>/g, '&gt;');
    str = str.replace(/"/g, '&quot;');
    str = str.replace(/'/g, '&#039;');
    return str;
}

if (self === top){
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "https://hm.baidu.com/hm.js?cdce8cda34e84469b1c8015204129522";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();
}
