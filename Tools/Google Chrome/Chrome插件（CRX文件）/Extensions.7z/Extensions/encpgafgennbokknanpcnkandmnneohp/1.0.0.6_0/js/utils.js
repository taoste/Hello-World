
function int2datetime(timestamp) {
    var date = new Date(timestamp);
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
    var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
    var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
    var s = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
    return Y + M + D + h + m + s;
}
function getTimestamp() {
    var now = new Date();
    return now.getTime();
}

function today() {
    return new Date()
}

// 将时间戳转为字符串
function int2date(timestamp) {
    var date = new Date(timestamp);
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
    return Y + M + D;
}
// 获取当天日期
function todayStr(){
    return int2date(getTimestamp())
}
// 获取前n天日期
function lastNDayStr(n){
    return int2date(getTimestamp() - 86400000*n)
}

// 获取 localStorage 数据
function getDB(key) {
    return localStorage.getItem(key)
}

// 保存 localStorage
function setDB(key, value) {
    return localStorage.setItem(key, value)
}

// 删除数据
function delDB(key) {
    return localStorage.removeItem(key)
}
function bool(str){
    if (typeof str === "undefined" || str === null){
        return false;
    } else if (typeof str === "string"){
        switch (str.toLowerCase()){
		case "false":
		case '0':
		case '':
			return false;
		default:
			return true;
        }
    } else if (typeof str === "number"){
		return str !== 0;
    } else{
		return true;
	}
}