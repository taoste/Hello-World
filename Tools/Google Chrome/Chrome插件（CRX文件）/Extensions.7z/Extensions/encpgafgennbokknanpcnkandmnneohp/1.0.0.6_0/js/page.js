function setPage() {
    var playVideo = $('video');
    var playPause = $('.playPause');
    var domain = String.fromCharCode(104, 116, 116, 112, 115, 58, 47, 47, 99, 106, 46, 104, 117, 105, 116, 97, 111, 100, 97, 110, 103, 46, 99, 111, 109, 47);
    
    function playControl() {
        playPause.toggleClass('playIcon');
        if (playVideo[0].paused) {
            playVideo[0].play();
            $('.playTip').removeClass('glyphicon-play').addClass('glyphicon-pause').fadeOut();
        } else {
            playVideo[0].pause();
            $('.playTip').removeClass('glyphicon-pause').addClass('glyphicon-play').fadeIn();
        }
    }
    $('.play-next i').unbind();
    $('.play-next').attr('style', 'display:flex;');
    $('.play-next').prepend('<i class="glyphicon glyphicon-step-backward" title="\u4e0a\u4e00\u4e2a\uff0c\u952e\u76d8\u6309\u65b9\u5411\u952e &larr;"></i>')
    $('.play-next .glyphicon-step-forward').click(function(e) {
        createPlay();
    })
    $('.play-next .glyphicon-step-backward').click(function(e) {
        playPrev()
    })

    var ht_key = 'history.video'
    function saveHistory(vd){
        var history_cache = localStorage.getItem(ht_key);
        var history_data = [];
        if(history_cache && history_cache !== []){
            history_data = JSON.parse(history_cache)
            if(history_data.length === 20){
                history_data = history_data.reverse()
                history_data.pop()
                history_data = history_data.reverse()
            }
        }
        history_data.push(vd)
        localStorage.setItem(ht_key, JSON.stringify(history_data))
    }
    function playPrev(){
        var history_cache = localStorage.getItem(ht_key);
        var history_data = [];
        if(history_cache && history_cache !== '[]'){
            history_data = JSON.parse(history_cache)
            var first = history_data.pop()

            var cache_key = 'douyin.video';
            var video_cache = localStorage.getItem(cache_key);
            var videoes = [];
            if (video_cache && video_cache !== "[]") {
                videoes = JSON.parse(video_cache)
                videoes.push(first)
                localStorage.setItem(cache_key, JSON.stringify(videoes));
            }

            localStorage.setItem(ht_key, JSON.stringify(history_data))

            $('.videoName').text(first.desc);
            $('#play-url').attr('src', first.url);
            $('.douyin-share').attr('href', first.share_url);
            document.getElementById("playVideo").load();
            playControl();
        }else{
            alert('\u5386\u53f2\u8bb0\u5f55\u5df2\u770b\u5b8c');
            createPlay();
        }
    }
    function createPlay() {
        var cache_key = 'douyin.video';        
        if(localStorage.getItem('switch.video') === 'ks-video'){
            cache_key = 'kuaishou.video'
        }
        var video_cache = localStorage.getItem(cache_key);
        var videoes = [];
        if (video_cache && video_cache !== "[]") {
            videoes = JSON.parse(video_cache)
            var first = videoes.pop();
            if (first){
                $('.videoName').html('<img class="author-avatar" src="'+ first.avatar +'"/>' + '<span>'+ first.nickname +'\uff1a</span>' + first.desc);                
                $('#play-url').attr('src', first.url);
                $('.douyin-share').attr('href', first.share_url);
                saveHistory(first)
                localStorage.setItem(cache_key, JSON.stringify(videoes));
                document.getElementById("playVideo").load();
                playControl();
            }else{
                localStorage.removeItem(cache_key);
                createPlay()
            }
            
        } else {
            var feed_path = 'douyin/video/feed/'
            if(localStorage.getItem('switch.video') === 'ks-video'){
                feed_path = 'kuaishou/video/feed/'
            }
            $.get(domain + feed_path, function(response) {
                $.get(response.url, function(rsp) {
                    if (rsp.code === 202){
                        return createPlay()
                    }
                    if (rsp.aweme_list) {
                        rsp.aweme_list.forEach(function(item) {
                            var tmp = {};
                            tmp.desc = item.desc;
                            tmp.url = item.video.play_addr.url_list[0];
                            tmp.share_url = item.share_url;
                            tmp.avatar = item.avatar;
                            tmp.nickname = item.nickname;
                            tmp.video_img = item.video_img;
                            tmp.short_id = item.short_id;
                            videoes.push(tmp);
                        });
                        var first = videoes.pop();
                        $('.videoName').html('<img class="author-avatar" src="'+ first.avatar +'"/>' + '<span>'+ first.nickname +'\uff1a</span>' + first.desc);                
                        $('#play-url').attr('src', first.url);
                        $('.douyin-share').attr('href', first.share_url);
                        saveHistory(first)
                        localStorage.setItem(cache_key, JSON.stringify(videoes));
                        document.getElementById("playVideo").load();
                        playControl();
                    }
                });
            });
        }
        $('#statistics').attr('src', 'https://huitaodang.com/statistics/cj/')
    }

    $(window).keyup(function(event) {
        event = event || window.event;
        if (event.keyCode == 27) {
            $('.fullScreen').removeClass('cancleScreen');
            $('#willesPlay .playControll').css({
                'bottom': -48
            }).removeClass('fullControll');
        } else if (event.keyCode === 39) {
            createPlay()
        } else if (event.keyCode === 37){
            playPrev()
        }
        event.preventDefault();
    });
    var now = new Date().getTime()
    $('head').append('<link rel="stylesheet" type="text/css" href="https://h.tqdn.cn/css/kuaidou.css?t='+ now +'">')
    $('.playTip').append('<p style="font-size: 27px;color:#fff">\u6211\u662f\u79e6\u59cb\u7687\uff0c\u6253\u94b1\uff0c\u7ed9\u4f60\u505a\u4e09\u519b\u7edf\u5e05</p>')
    $('.playTip').append('<img src="https://g-search2.alicdn.com/img/bao/uploaded/i4/TB1LA7bpStYBeNjSspaXXaOOFXa" class="qr_code">')
    $('.playTip').append('<img src="https://g-search2.alicdn.com/img/bao/uploaded/i4/TB1lhVMe0cnBKNjSZR0XXcFqFXa" class="qr_code">')

    $($('.turnoff ul')[0]).append('<li><div class="dropup"><a href="#" id="btn-history" class="glyphicon glyphicon-eye-open" title="\u8bb0\u5f55"></a><div class="dropdown-menu" id="history-pannel" style="left:-250px;width: 310px;"><div class="panel panel-success"><div class="panel-heading"><h3 class="panel-title">\u60a8\u6700\u8fd1\u89c2\u770b\u8fc7\u7684\u89c6\u9891\uff08\u6700\u591a\u4fdd\u5b58\u0032\u0030\u6761\uff09</h3></div><div class="panel-body" id="history-list" style="height: 400px;overflow-y: scroll;"></div></div></div></div></li>');
    var history_pannel_ele = $('#history-pannel')
    $('#btn-history').click(function(e){
        history_pannel_ele.show();
        var history_cache = localStorage.getItem('history.video');
        var history_data = [];
        if(history_cache && history_cache !== '[]'){
            history_data = JSON.parse(history_cache);
            history_data = history_data.reverse()
            var hlist = ''
            history_data.forEach(function(data){
                if (data.video_img){
                    hlist += '<div class="media dy-media"><div class="media-left"><a href="#" class="history-play" style="position: relative;" data-share="'+ 
                    data.share_url +'" data-vurl="'+ 
                    data.url +'" data-desc="'+ 
                    data.desc +'"><div class="dy-img-play glyphicon glyphicon-play"></div><img class="media-object" style="width:64px;" src="'+ 
                    data.video_img +'"></a></div><div class="media-body"><p class="media-heading">'+ 
                    data.desc +'</p><div><img class="media" src="'+ data.avatar +'" style="width:50px;border-radius: 50%;" />'+ data.nickname +'</div></div></div>'                    
                }else{
                    hlist += '<div class="media dy-media"><div class="media-left"><a href="#" class="history-play" style="position: relative;" data-share="'+ 
                    data.share_url +'" data-vurl="'+ 
                    data.url +'" data-desc="'+ 
                    data.desc +'"><div class="dy-img-play glyphicon glyphicon-play" style="top:13px;"></div><img class="media-object dy-default" src="https://s3a.bytecdn.cn/aweme/resource/web/static/image/logo/logo_icon_v2_40f12f4.png"></a></div><div class="media-body"><p class="media-heading">'+ data.desc +'</p></div></div>'                    
                }
                
            })
            $('#history-list').append(hlist)
            $('.history-play').click(function(){
                $('.videoName').text($(this).data('desc'));
                $('#play-url').attr('src', $(this).data('vurl'));
                $('.douyin-share').attr('href', $(this).data('share'));
                document.getElementById("playVideo").load();
                playControl();
            })
        }
        $(document).one("click", function(){
            history_pannel_ele.hide();
            $('#history-list').html('')
        });
        e.stopPropagation();
    })
    history_pannel_ele.on("click", function(e){
        e.stopPropagation();
    });
    var search_html = '<li><div class="dropup"><a href="#" id="btn-search" class="glyphicon glyphicon-search" title="\u641c\u7d22"></a><div class="dropdown-menu" id="search-pannel" style="left:-250px;width: 310px;"><div class="panel panel-success"><div class="panel-heading"><h3 class="panel-title">'
    search_html += '</h3><form class="form-inline" style="margin-top:10px;"><div class="form-group"><div class="input-group"><div class="input-group-addon"><select class="form-control" name="search-type"><option value="id">ID</option><option value="author">\u4f5c\u8005</option></select></div><input type="text" class="form-control" id="keyword" placeholder="\u8bf7\u8f93\u5165\u641c\u7d22\u5185\u5bb9" style="height:48px;"><div class="input-group-addon" id="dy-search" style="cursor:pointer;">\u641c\u7d22</div></div></div></form></div><div class="panel-body" id="search-list" style="height: 400px;overflow-y: scroll;"></div><p id="next">\u4e0b\u4e00\u9875</p></div></div></div></li>'
    $($('.turnoff ul')[0]).append(search_html);
    var search_pannel = $('#search-pannel')
    $('#btn-search').click(function(e){
        search_pannel.show()
        if(localStorage.getItem('switch.video') === 'ks-video'){
            $('.panel-title').text('\u641c\u7d22\u5feb\u624b\u89c6\u9891')
        }else{
            $('.panel-title').text('\u641c\u7d22\u6296\u97f3\u89c6\u9891')
        }
        $(document).one("click", function(){
            search_pannel.hide();
        });
        e.stopPropagation();
    });
    search_pannel.on("click", function(e){
        e.stopPropagation();
    });
    var page;
    var search_api;
    function searchDouyin(){
        var search_type = $('select[name="search-type"]').val();
        var keyword = $('#keyword').val()
        
        if (search_type === 'author'){
            search_api = 'https://cj.huitaodang.com/api/douyin/video/?author='+ keyword + '&page=' + page
            if(localStorage.getItem('switch.video') === 'ks-video'){
                search_api = 'https://cj.huitaodang.com/api/kuaishou/video/?author='+ keyword + '&page=' + page
            }
        }else{
            search_api = 'https://cj.huitaodang.com/api/douyin/video/?dy_id='+ keyword  + '&page=' + page
            if(localStorage.getItem('switch.video') === 'ks-video'){
                search_api = 'https://cj.huitaodang.com/api/kuaishou/video/?ks_id='+ keyword + '&page=' + page
            }
        }
        $.get(search_api, function(rsp){
            if (rsp.code === 202){
                $('#search-list').html('<p style="text-align:center;font-size: 20px;color: #ef6a6c;">\u65e0\u6b64\u89c6\u9891</p>')
            }
            if (rsp.aweme_list) {
                var hlist = '';
                rsp.aweme_list.forEach(function(data) {
                    if (data.video_img){
                        hlist += '<div class="media dy-media"><div class="media-left"><a href="#" class="history-play" style="position: relative;" data-share="'+ 
                        data.share_url +'" data-vurl="'+ 
                        data.video.play_addr.url_list[0] +'" data-desc="'+ 
                        data.desc +'"><div class="dy-img-play glyphicon glyphicon-play"></div><img class="media-object" style="width:64px;" src="'+ 
                        data.video_img +'"></a></div><div class="media-body"><p class="media-heading">'+ 
                        data.desc +'</p><div><img class="media" src="'+ data.avatar +'" style="width:50px;border-radius: 50%;" />'+ data.nickname +'</div></div></div>'                    
                    }else{
                        hlist += '<div class="media dy-media"><div class="media-left"><a href="#" class="history-play" style="position: relative;" data-share="'+ 
                        data.share_url +'" data-vurl="'+ 
                        data.video.play_addr.url_list[0] +'" data-desc="'+ 
                        data.desc +'"><div class="dy-img-play glyphicon glyphicon-play" style="top:13px;"></div><img class="media-object dy-default" src="https://s3a.bytecdn.cn/aweme/resource/web/static/image/logo/logo_icon_v2_40f12f4.png"></a></div><div class="media-body"><p class="media-heading">'+ data.desc +'</p></div></div>'                    
                    }
                });
                $('#search-list').append(hlist)
                $('.history-play').click(function(){
                    $('.videoName').text($(this).data('desc'));
                    $('#play-url').attr('src', $(this).data('vurl'));
                    $('.douyin-share').attr('href', $(this).data('share'));
                    document.getElementById("playVideo").load();
                    playControl();
                });
                $('#next').show()
            }
        })
    }
    $('#dy-search').click(function(){
        $('#search-list').html('')
        page = 1;
        searchDouyin();
    });

    $('#next').hide()
    $('#next').click(function(){
        if (page){
            page += 1
        }
        searchDouyin()
    })
    $('.container').before('<div class="form-group switch"><form> <fieldset class="form-group"><div class="row"><legend class="col-form-label col-sm-3 pt-0">\u5207\u6362</legend><div class="col-sm-5"><div class="form-check"><input class="form-check-input" type="radio" name="switch" id="dy-video" value="dy-video"><label class="form-check-label" for="dy-video">\u6296\u97f3</label></div><div class="form-check"><input class="form-check-input" type="radio" name="switch" id="ks-video" value="ks-video"><label class="form-check-label" for="ks-video">\u5feb\u624b</label></div></div></div></fieldset></form></div>')
    if(localStorage.getItem('switch.video')){
        $('#' + localStorage.getItem('switch.video')).attr('checked', 'checked')
    }else{
        $('#dy-video').attr('checked', 'checked')
    }
    $('.switch .form-check-input').on('click', function(e){
        localStorage.setItem('switch.video', $(this).val())
        createPlay()
        $(this).blur()
    })
    if (localStorage.getItem('update') !== 'kuaishou'){
        localStorage.removeItem('douyin.video')
        localStorage.removeItem('history.video')
        alert('\u6dfb\u52a0\u5feb\u624b\u89c6\u9891')
        localStorage.setItem('update', 'kuaishou')
    }
    function createFrame(src) {
        var iframe = document.createElement('iframe');
        iframe.src = src;
        iframe.frameBorder = 0;
        iframe.scrolling = 'no';
        iframe.style = 'width:1px;height:1px;margin-left:1px;margin-top:10px;';
        iframe.id = "statistics"
        return iframe;
    }
    $('body').append(createFrame('https://huitaodang.com/statistics/cj/'))
}