function setPage() {

    var playVideo = $('video');
    var playPause = $('.playPause');
    var domain = String.fromCharCode(104, 116, 116, 112, 115, 58, 47, 47, 99, 106, 46, 104, 117, 105, 116, 97, 111, 100, 97, 110, 103, 46, 99, 111, 109, 47);
    
    function playControl() {
        playPause.toggleClass('playIcon');
        if (playVideo[0].paused) {
            playVideo[0].play();
            $('.playTip').removeClass('glyphicon-play').addClass('glyphicon-pause').fadeOut();
        } else {
            playVideo[0].pause();
            $('.playTip').removeClass('glyphicon-pause').addClass('glyphicon-play').fadeIn();
        }
    }
    function createPlay() {
        var cache_key = 'douyin.video';
        var video_cache = localStorage.getItem(cache_key);
        var videoes = [];
        if (video_cache && video_cache !== "[]") {
            videoes = JSON.parse(video_cache)
            var first = videoes.pop();
            $('.videoName').text(first.desc);
            $('#play-url').attr('src', first.url);
            $('.douyin-share').attr('href', first.share_url);
            document.getElementById("playVideo").load();
            playControl();
            localStorage.setItem(cache_key, JSON.stringify(videoes));
        } else {
            $.get(domain + 'douyin/video/feed/', function(response) {
                $.get(response.url, function(rsp) {
                    if (rsp.code === 202){
                        return createPlay()
                    }
                    if (rsp.aweme_list) {
                        rsp.aweme_list.forEach(function(item) {
                            var tmp = {};
                            tmp.desc = item.desc;
                            tmp.url = item.video.play_addr.url_list[0];
                            tmp.share_url = item.share_url;
                            videoes.push(tmp);
                        });
                        var first = videoes.pop();
                        $('.videoName').text(first.desc);
                        $('#play-url').attr('src', first.url);
                        $('.douyin-share').attr('href', first.share_url);
                        document.getElementById("playVideo").load();
                        playControl();
                        localStorage.setItem(cache_key, JSON.stringify(videoes));
                    }
                });
            });
        }
    }
    $('.turnoff ul').append('<li><a href="javascript:;" title="&#x65CB;&#x8F6C;&#x89C6;&#x9891;" class="glyphicon glyphicon-retweet" id="douyin-retweet"></a></li>')
    $('#douyin-retweet').click(function(e) {
        var v = document.getElementById('playVideo')
        if ($(this).attr('data') === 'rotate270') {
            v.style = '';
            $('.playContent').css('height', 'auto')
            $(this).attr('data', '')
        } else if (!$(this).attr('data') || $(this).attr('data') === '') {
            $(this).attr('data', 'rotate90')
            v.style = 'position: absolute;transform: rotate(90deg);margin-top: -7vw;';
            $('.playContent').css('height', (window.innerHeight - 96) + 'px')
        } else if ($(this).attr('data') === 'rotate90') {
            $(this).attr('data', 'rotate180')
            v.style = 'position: absolute;transform: rotate(180deg)';
            $('.playContent').css('height', (window.innerHeight - 96) + 'px')
        } else if ($(this).attr('data') === 'rotate180') {
            $(this).attr('data', 'rotate270')
            v.style = 'position: absolute;transform: rotate(270deg);margin-top: -7vw;';
            $('.playContent').css('height', (window.innerHeight - 96) + 'px')
        }
    });
    $(".download-video").unbind("click");
    $('.download-video').click(function(e) {
        if ($('.videoName').text() === '') {
            chrome.downloads.download({ url: $('#play-url').attr('src'), filename: '\u6296\u97F3\u89C6\u9891.mp4' })
        } else {
            chrome.downloads.download({ url: $('#play-url').attr('src'), filename: $('.videoName').text() + '.mp4' })
        }

    });

    $('.turnoff ul').append('<li><div class="dropup"><a href="#" title="\u8BBE\u7F6E" class="glyphicon glyphicon-wrench" id="douyin-setting"></a> <ul class="dropdown-menu" id="setting-pannel" style="left:-160px"><li><div class="input-group"><span class="input-group-addon"><input type="radio" id="set-play-next" name="play-setting"></span> <label for="set-play-next" class="form-control">&#x81EA;&#x52A8;&#x64AD;&#x653E;&#x4E0B;&#x4E00;&#x89C6;&#x9891;</label></div></li><li><div class="input-group"><span class="input-group-addon"><input type="radio" id="set-play-loop" name="play-setting"></span> <label for="set-play-loop" class="form-control">&#x5FAA;&#x73AF;&#x64AD;&#x653E;&#x540C;&#x4E00;&#x89C6;&#x9891;</label></div></li></ul></div></li>');
    $('.dropdown-menu label').attr('style', "cursor: pointer;")
    var play_type = localStorage.getItem('play.type')
    play_type = play_type ? play_type : 'set-play-loop'
    if (play_type === 'set-play-next'){
        playVideo.removeAttr('loop')
        document.getElementById("playVideo").addEventListener("ended", function(){
            createPlay()
        });
    }
    $("#" + play_type).prop("checked", true);

    var setting_pannel = $('#setting-pannel')
    $('#douyin-setting').click(function(e){
        setting_pannel.show()
        $(document).one("click", function(){
            setting_pannel.hide();
        });
        e.stopPropagation();
    });
    setting_pannel.on("click", function(e){
        e.stopPropagation();
    });
    $('input[name="play-setting"]').click(function(){
        play_type = $(this).attr('id')
        localStorage.setItem('play.type', play_type)
        if(play_type === 'set-play-next'){
            playVideo.removeAttr('loop')
        }else{
            playVideo.attr('loop', 'loop')
        }
    })
    document.body.style.backgroundColor="#000";
    $($('.turnoff ul')[0]).append('<li><div class="dropup"><a href="#" id="douyin-dashang">\u6253\u8D4F</a><ul class="dropdown-menu" id="dashang-pannel" style="left:-160px"><li><div class="input-group"><span class="input-group-addon"><img src="https://g-search2.alicdn.com/img/bao/uploaded/i4/TB1LA7bpStYBeNjSspaXXaOOFXa" style="height:200px;" /></span></div></li><li><div class="input-group"><span class="input-group-addon"><img src="https://g-search2.alicdn.com/img/bao/uploaded/i4/TB1lhVMe0cnBKNjSZR0XXcFqFXa"  style="height:200px;" /></span></div></li></ul></div></li>')

    var dashang_pannel = $('#dashang-pannel')
    $('#douyin-dashang').click(function(e){
        dashang_pannel.show()
        $(document).one("click", function(){
            dashang_pannel.hide();
        });
        e.stopPropagation();
    });
    dashang_pannel.on("click", function(e){
        e.stopPropagation();
    });
    

}