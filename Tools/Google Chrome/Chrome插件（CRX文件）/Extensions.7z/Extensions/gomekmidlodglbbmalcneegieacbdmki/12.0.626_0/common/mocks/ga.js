/* GA event mock functions for DNT compatability */

var _gaq  = {};
var _gat = {};
_gaq.push = _gaq._trackEvent = _gaq._createAsyncTracker = _gaq._getAsyncTracker = _gaq.getPlugin = _gat._gasoCPath = _gat.gasoDomain = _gat._createTracker = _gat._anonymizeId = _gat.forceSSL = _gat._getPlugin = _gat.getTracker = _gat.getTrackerByName = _gat._getTrackers = _gat.aa = _gat.ab = _gat.la = _gat.oa = _gat.pa = _gat.r = _gat.u = function(){};
