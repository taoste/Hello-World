# 安装 Docker 版 Plex 媒体服务器

**注册账户并登陆 https://www.plex.tv 网站**
**在主目录新建 plex/database 文件夹用于存储 Plex 数据库**
**在主目录新建 plex/transcode 文件夹用于存储 Plex 临时转码文件**
**在主目录新建 plex/media 文件夹用于存储 Plex 临时媒体文件**
**获得索取码 https://www.plex.tv/zh/claim/ 网站**
**命令方式安装Docker版Plex**

docker run \
-d \
--name plex \
--network=host \
--restart=always \
-e TZ="Asia/Shanghai" \
-e PLEX_CLAIM="claim-索取码" \
-e PUID=1000 \
-e PGID=1000 \
-v /home/用户名/plex/database:/config \
-v /home/用户名/plex/transcode:/transcode \
-v /home/用户名/plex/media:/data \
-v /home/用户名/home/video:/video \
-v /home/用户名/home/photo:/photo \
--device=/dev/dri:/dev/dri \
plexinc/pms-docker

**如果你不知道要分享文件夹的位置，可以在文件夹上右键属性，复制上级目录，在地址后加上斜杠（/）和本文件夹的名称，就是文件夹的位置**
