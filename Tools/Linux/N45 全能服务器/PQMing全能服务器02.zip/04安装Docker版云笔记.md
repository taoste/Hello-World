# 免费使用为知笔记

**访问用户主目录文件夹**

cd ~

**在主目录新建 wizdata 文件夹用于存储笔记数据**

mkdir wizdata

**命令方式安装 Docker 版为知笔记**

docker run \
-it \
-d \
--name wiz \
--restart=always \
-v ~/wizdata:/wiz/storage \
-v /etc/localtime:/etc/localtime \
-p 8080:80 \
-p 9269:9269/udp \
wiznote/wizserver
