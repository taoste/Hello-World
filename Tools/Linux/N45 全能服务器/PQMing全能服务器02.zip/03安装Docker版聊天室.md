# 搭建 Mattermost 私人聊天室

**命令方式安装 Docker 版 Mattermost**

docker run \
-d \
--name mattermost-preview \
--restart=always \
--publish 8065:8065 \
--add-host dockerhost:127.0.0.1 \
mattermost/mattermost-preview

#设置 Mattermost 私人聊天室

**访问 127.0.0.1:8065 网址，输入邮箱用户名及密码进行初始账户注册**
**选择第二项进入控制台，进入SITE CONFIGURATION - Localization更改语言为中文**
**保存返回上一步，新建群组PQMing（可以自行改名），点击Finish完成**
**新页面输入用户名，上传头像（可选）并保存，保存团队，不起用通知**
**复制邀请链接，之后可以分享给朋友，稍等一会就完成设置**
**默认的管理员账户仍然是英文，点击右上角设置，Display里改成中文即可**
**新用户入群后会自动进入公共和闲聊这两个频道，用户之间可以选择群聊或私信**
