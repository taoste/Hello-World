# NAS 存储服务器

**为共享文件夹设定用户名 ming 和密码（共享用户可自行替换，但必须为系统已存在的用户名）**

sudo smbpasswd -a ming

**为共享文件夹设定用户名 hei 和密码（共享用户可自行替换，但必须为系统已存在的用户名）**

sudo smbpasswd -a hei

#共享文件夹权限设置教程

**复制 /etc/samba/smb.conf 到桌面**
**粘贴到 smb.conf 文件末尾并保存（需自行替换用户名）**

[document]
	path = /home/document
	valid user = ming
	guest ok = no
	read only = no
	write list = ming
	browsable = no

[photo]
	path = /home/photo
	valid user = ming,hei
	public = yes
	read only = yes
	write list = ming

[video]
	path = /home/video
	valid user = ming,hei,bai
	available = yes
	public = yes
	writable = yes
	create mask = 777
	directory mask = 777


**用修改后的配置替换默认配置**
sudo cp ~/桌面/smb.conf /etc/samba/smb.conf

**给予其他用户访问 video 文件夹的权限**
sudo chmod -R 777 /home/video

**给予其他用户访问 photo 文件夹的权限**
sudo chmod -R 777 /home/photo

**禁止用户 bai 访问 photo 文件夹（需自行替换用户名）**
setfacl -m u:bai:- /home/photo

**重启文件共享服务**
sudo service smbd restart
