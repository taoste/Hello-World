#! /bin/bash

date "+%Y年%m月%d日 周%w %H:%M:%S"
echo '为 Docker 更换官方国内源加速下载'
cat > /etc/docker/daemon.json << EOF
{
 "registry-mirrors": ["https://registry.docker-cn.com"]
}
EOF
service docker restart
docker info|grep "Registry Mirrors" -A 1
echo '显示 registry.docker-cn.com 即换源成功'
