// ==UserScript==
// @name         CC163FullScreen
// @namespace    https://greasyfork.org/zh-CN/users/135090
// @version      1.3.0
// @description:en-US  Please use HLS Playback Extension in Google Webstore
// @description  获取M3U8地址,请配合Chrome浏览器扩展HLS Playback使用
// @author       ZWB
// @match        https://cc.163.com/1*/
// @match        https://cc.163.com/2*/
// @match        https://cc.163.com/3*/
// @match        https://cc.163.com/4*/
// @match        https://cc.163.com/5*/
// @match        https://cc.163.com/6*/
// @match        https://cc.163.com/7*/
// @match        https://cc.163.com/8*/
// @match        https://cc.163.com/9*/
// @match        *://cc.163.com/live/channel/*
// @grant        unsafeWindow
// @license      CC
// @run-at       document-idle
// @noframes
// @description 获取M3U8地址,请配合Chrome浏览器扩展HLS Playback使用
// ==/UserScript==
setTimeout(function(){
    var cid=0;
    var title=document.title;
    if ((typeof unsafeWindow.__NEXT_DATA__) =="undefined" || location.pathname.includes("live")){
        cid=-1;
    }else if(unsafeWindow.__NEXT_DATA__.props.pageProps.roomInfoInitData.live.gametype == 95599){
        cid=-95599;
        alert("语音直播在WEB端无法观看");
    }else{
        var ND=unsafeWindow.__NEXT_DATA__;
        cid = (typeof ND.query.subcId)=="undefined"?ND.props.pageProps.roomInfoInitData.live.channel_id:ND.query.subcId;
    }
    if (cid>0){
        var liveurl="//cc.163.com/live/channel/?channelids="+cid;
        var link = unsafeWindow.document.createElement("span");
        var container = document.body;
        var coverhtml= "查看直播".link("javascript:void(0)");
        link.innerHTML = coverhtml;
        link.querySelector("a").addEventListener("click",function(){
            void(window.open(liveurl));
        });
        link.style="position:fixed;top:64px;left:160px;z-index: 999";
        link.style.display = "block";
        link.style.color = "#00ade5";
        container.append(link);
    }else if(cid==0){
        alert("直播未开始");
    }else if (cid==-1){
        if (location.href.includes("https")){location="http://cc.163.com/live/channel/"+location.search;}
        var data=JSON.parse(document.body.innerText).data[0];
        var m3u=data.m3u8;
        var nickname=data.nickname;
        var cover=data.cover;
        var sf=data.sharefile;
        var startat=data.startat;
        var isaudio=data.is_audiolive;
        var ccid=data.ccid;
        setTimeout(function(){
            void(document.body.remove());
            document.writeln("<head><script type='text/javascript' src='https://cdn.bootcdn.net/ajax/libs/dplayer/1.26.0/DPlayer.min.js'></script>");
            document.writeln("<script type='text/javascript' src='https://cdn.bootcdn.net/ajax/libs/hls.js/1.1.5/hls.min.js'></script></head>");
            document.writeln("<body><hr /></body>");
            document.title=nickname;
            document.writeln("<div id=\"dplayer\" width=\"80%\" height=\"80%\" align=center></div>");
            document.writeln("<hr />");
            document.writeln("<span>"+startat+"开播</span>");
            document.writeln("<p>直播间地址：<a target=_blank href=\"https://cc.163.com/"+ccid+"/\">"+ccid+"</a></p>");
            document.close();
        },500);
        setTimeout(function(){
            if(isaudio==1){
                document.body.innerHTML="<h1>音频直播，暂不支持</h1>";
            }else{
                var dp=new DPlayer({
                    container: document.getElementById('dplayer'),
                    live: true,
                    volume: 1.0,
                    video: {
                        quality: [{name: 'M3U8',url: m3u,type: 'hls',},{name: 'ShareFile',url: sf,type: 'hls',},],
                        defaultQuality: 0,
                        pic: cover,
                    },
                });
            }
        },2500);
    }
},500);