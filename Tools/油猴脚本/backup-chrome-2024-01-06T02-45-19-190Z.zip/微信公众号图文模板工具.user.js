// ==UserScript==
// @name         微信公众号图文模板工具
// @version      20231205
// @description  为庞门正道微信公众号提供的快速编辑图文底部尾巴的工具。
// @author       XHXIAIEIN
// @namespace    https://greasyfork.org/zh-CN/scripts/406755
// @match        https://mp.weixin.qq.com/cgi-bin/*
// @icon         https://mp.weixin.qq.com/favicon.ico
// @run-at       document-start
// @grant        GM_addStyle
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/406755/%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7%E5%9B%BE%E6%96%87%E6%A8%A1%E6%9D%BF%E5%B7%A5%E5%85%B7.user.js
// @updateURL https://update.greasyfork.org/scripts/406755/%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7%E5%9B%BE%E6%96%87%E6%A8%A1%E6%9D%BF%E5%B7%A5%E5%85%B7.meta.js
// ==/UserScript==
/**
 * =============================================================================================
 * - 可能存在的问题：
 *    1. 输入公众号文章链接后，标题显示undefined. [解决方案] 清空输入框，重新填写一次文章链接即可。
 * =============================================================================================
 */


// 提取当前页面链接的参数。
function get_url_params(name) {
  const reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
  const r = window.location.search.substr(1).match(reg);
  if (r != null) return unescape(r[2]);
  return null;
}

// 获取今天的日期, 如 0520
function getTodayDate(fmt) {
  var dateTime=new Date();
  var o = { "M+": dateTime.getMonth() + 1,"d+": dateTime.getDate()};
  for (var k in o){ if (new RegExp("(" + k + ")").test(fmt))  { fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length))); }}
  return fmt;
};

// 等待执行
function sleep (time) {
  return new Promise((resolve) => setTimeout(resolve, time));
}

// 提取svg背景属性的图片地址
function getBackgroundUrl(str){
  const regUrl = /[\(^].*[\)$]/g;
  const regBracket = /\(|\)/g
  return str.match(regUrl)[0].replace(regBracket,'')
}

function getArticleUrl(str) {
  const anchorElement = str.querySelector('a[name="XHXIAIEIN-url"]');
  if (anchorElement) {
    const hrefAttribute = anchorElement.getAttribute('href');
    return hrefAttribute;
  }
  return null;
}

//-------------------------------------------------------------------------------------
// 模板变量

const IMG_WIDTH = 800;
const IMG_HEIGH = 350;

let template_1 = {
  'text': '还没填写文章链接',
  'url': '',
  'img': 'https://mmbiz.qpic.cn/mmbiz_png/I3KJh29KMaQfkJIY6BPweepaQFk8NQ3uiahoHIP6RUQnBibkOEpkMu01ACA0zw0hRkUUqRBO4ediceoYBP58dibjGg/0?wx_fmt=png',
  'width': IMG_WIDTH,
  'height': IMG_HEIGH,
  'scrollx': '100%',
  'scrolly': '100%',
  'scale': 100,
}

let template_2 = {
  'text': '还没填写文章链接',
  'url': '',
  'img': 'https://mmbiz.qpic.cn/mmbiz_png/I3KJh29KMaQfkJIY6BPweepaQFk8NQ3uiahoHIP6RUQnBibkOEpkMu01ACA0zw0hRkUUqRBO4ediceoYBP58dibjGg/0?wx_fmt=png',
  'width': IMG_WIDTH,
  'height': IMG_HEIGH,
  'scrollx': '100%',
  'scrolly': '100%',
  'scale': 100,
}

let template_3 = {
  'text': '还没填写文章链接',
  'url': '',
  'img': 'https://mmbiz.qpic.cn/mmbiz_png/I3KJh29KMaQfkJIY6BPweepaQFk8NQ3uiahoHIP6RUQnBibkOEpkMu01ACA0zw0hRkUUqRBO4ediceoYBP58dibjGg/0?wx_fmt=png',
  'width': IMG_WIDTH,
  'height': IMG_HEIGH,
  'scrollx': '100%',
  'scrolly': '100%',
  'scale': 100,
}


// 图文模板编辑器右侧的浮窗工具。用于填写文章链接。
const XHXIAIEIN_layout = `
  <div class="XHXIAIEIN-layout">
  <!-- menu -->
  <div class="frm_control_group" style="display: block;"><label id="status-1" class="weui-desktop-tips">第一篇文章链接</label><div><input type="text" class="weui-desktop-form__input" id="input-1" name="input-1" placeholder="填写文章链接"></div></div>
  <div class="frm_control_group" style="display: block;"><label id="status-2" class="weui-desktop-tips">第二篇文章链接</label><div><input type="text" class="weui-desktop-form__input" id="input-2" name="input-2" placeholder="填写文章链接"></div></div>
  <div class="frm_control_group" style="display: block;"><label id="status-3" class="weui-desktop-tips">第三篇文章链接</label><div><input type="text" class="weui-desktop-form__input" id="input-3" name="input-3" placeholder="填写文章链接"></div></div>
  <!-- img -->
  <div class="frm_control_group" style="display: block;"><label class="weui-desktop-tips">当前文章的图片</label><pre class="XHXIAIEIN-viewcode" id="viewcode-img"><code></code></pre></div>
  <!-- img-new -->
  <div class="frm_control_group" style="display: block;">
    <label id="status-img1" class="weui-desktop-tips">第一张封面地址</label><div>
    <input type="text" class="weui-desktop-form__input" id="input-img1" placeholder="填写图片地址"><div class="size-inputs">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img1-width" placeholder="宽度">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img1-height" placeholder="高度">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img1-offsetX" placeholder="图片X">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img1-offsetY" placeholder="图片Y">
  </div></div></div>
  <div class="frm_control_group" style="display: block;">
    <label id="status-img2" class="weui-desktop-tips">第二张封面地址</label><div>
    <input type="text" class="weui-desktop-form__input" id="input-img2" placeholder="填写图片地址"><div class="size-inputs">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img2-width" placeholder="宽度">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img2-height" placeholder="高度">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img2-offsetX" placeholder="图片X">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img2-offsetY" placeholder="图片Y">
  </div></div></div>
  <div class="frm_control_group" style="display: block;">
    <label id="status-img3" class="weui-desktop-tips">第三张封面地址</label><div>
    <input type="text" class="weui-desktop-form__input" id="input-img3" placeholder="填写图片地址"><div class="size-inputs">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img3-width" placeholder="宽度">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img3-height" placeholder="高度">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img3-offsetX" placeholder="图片X">
    <input type="number" class="weui-desktop-form__input small-input" id="input-img3-offsetY" placeholder="图片Y">
  </div></div></div>
  <!-- html -->
  <div class="frm_control_group" style="display: block;"><label class="weui-desktop-tips">当前源码</label><pre class="XHXIAIEIN-viewcode" id="viewcode-html"><code></code></pre></div>
  <!-- overwrite -->
  <div class="frm_control_group" style="display: block;"><label id="status-overwrite" class="weui-desktop-tips">新的源码</label><div><input type="text" class="weui-desktop-form__input" id="input-overwrite" name="input-overwrite" placeholder="新的正文源码"></div></div>
  <!-- iframe -->
  <iframe class="XHXIAIEIN-iframe" id="iframe-1"></iframe><iframe class="XHXIAIEIN-iframe" id="iframe-2"></iframe><iframe class="XHXIAIEIN-iframe" id="iframe-3"></iframe>
  <!-- style -->
  <style type="text/css">
  .XHXIAIEIN-layout{ width: 300px; height: auto; padding: 16px; display: block; background-color: #fff;position: absolute; top: 200px; right: 48px; z-index:1;}
  .XHXIAIEIN-iframe{ width: 0; height: 0; border:0; position: absolute; left: -1000px; top: -1000px; display: none;}
  .XHXIAIEIN-viewcode{ overflow-x:auto;}
  .small-input { width: 71px; margin-right: 5px;}
  .size-inputs { display: flex; justify-content: space-between; margin-top: 5px; }
  </style>
  </div>
  `



//-------------------------------------------------------------------------------------
// 在首页

// 在左侧导航菜单，创作管理分类下添加'图文尾巴'的入口。点击后快速进入图文模板。
const added_menu = function () {
    const weixin_token = get_url_params('token')
    const dom = $(`<li class="weui-desktop-sub-menu__item"><a href="/cgi-bin/appmsgtemplate?action=list&lang=zh_CN&token=${weixin_token}" title="文章尾巴" class="weui-desktop-menu__link"><span class="weui-desktop-menu__link__inner"><span class="weui-desktop-menu__name">文章尾巴</span></span></a></li>`)[0]
    $('.weui-desktop-sub-menu')[1].append(dom);
}

// 图文模板编辑器
function show_editor() {

  //修改标题
  $('#title')[0].value = "尾巴" +'\xa0'+ getTodayDate('MMdd')


  // 加入快捷工具浮窗
  $('body').append(XHXIAIEIN_layout);

  // 监听输入框事件
  $("#input-1")[0].addEventListener('input', function(e){ set_ifame_contents(e.target.value, e.target.id)});
  $("#input-2")[0].addEventListener('input', function(e){ set_ifame_contents(e.target.value, e.target.id)});
  $("#input-3")[0].addEventListener('input', function(e){ set_ifame_contents(e.target.value, e.target.id)});

  // svg宽度
  $("#input-img1-width")[0].addEventListener('input', function(e){ set_article_canvas_width(e.target.value, e.target.id)});
  $("#input-img2-width")[0].addEventListener('input', function(e){ set_article_canvas_width(e.target.value, e.target.id)});
  $("#input-img3-width")[0].addEventListener('input', function(e){ set_article_canvas_width(e.target.value, e.target.id)});

  // svg高度
  $("#input-img1-height")[0].addEventListener('input', function(e){ set_article_canvas_height(e.target.value, e.target.id)});
  $("#input-img2-height")[0].addEventListener('input', function(e){ set_article_canvas_height(e.target.value, e.target.id)});
  $("#input-img3-height")[0].addEventListener('input', function(e){ set_article_canvas_height(e.target.value, e.target.id)});

  // 覆盖文章图片
  $("#input-img1")[0].addEventListener('input', function(e){ set_article_img(e.target.value, e.target.id)});
  $("#input-img2")[0].addEventListener('input', function(e){ set_article_img(e.target.value, e.target.id)});
  $("#input-img3")[0].addEventListener('input', function(e){ set_article_img(e.target.value, e.target.id)});

  // 封面滚动X
  $("#input-img1-offsetX")[0].addEventListener('input', function(e){ set_article_img_scrollx(e.target.value, e.target.id)});
  $("#input-img2-offsetX")[0].addEventListener('input', function(e){ set_article_img_scrollx(e.target.value, e.target.id)});
  $("#input-img3-offsetX")[0].addEventListener('input', function(e){ set_article_img_scrollx(e.target.value, e.target.id)});

  // 封面滚动Y
  $("#input-img1-offsetY")[0].addEventListener('input', function(e){ set_article_img_scrolly(e.target.value, e.target.id)});
  $("#input-img2-offsetY")[0].addEventListener('input', function(e){ set_article_img_scrolly(e.target.value, e.target.id)});
  $("#input-img3-offsetY")[0].addEventListener('input', function(e){ set_article_img_scrolly(e.target.value, e.target.id)});

  // 覆盖文章内容
  $("#input-overwrite")[0].addEventListener('input', function(e){ overwrite_contents(e.target.value, e.target.id)});
  $("#input-overwrite")[0].addEventListener('click', function(e){ refresh_information()});

  refresh_information()
}

//-------------------------------------------------------------------------------------
// 页面

function set_ifame_contents(value, id){

  const str = value.replace(/(^\s*)|(\s*$)/g, '');

  if (str == '' || str === null || str === undefined ) return;

  switch(id){
    case 'input-1':
      $("#iframe-1")[0].setAttribute("src", str);
      $("#input-img1")[0].value = str;
      template_1['url'] = str;
      break;
    case 'input-2':
      $("#iframe-2")[0].setAttribute("src", str);
      $("#input-img2")[0].value = str;
      template_2['url'] = str;
      break;
    case 'input-3':
      $("#iframe-3")[0].setAttribute("src", str);
      $("#input-img3")[0].value = str;
      template_3['url'] = str;
      break;
    default:
      return;
  }

 // 加载文章数据
  sleep(400).then(() => { get_iframe_contents(id);});
}


function get_iframe_contents(id){
  switch(id){
    case 'input-1':
      template_1['text'] = $("#iframe-1")[0].contentWindow.frames['msg_title'];
      template_1['img']  = $("#iframe-1")[0].contentWindow.frames['cdn_url_235_1'];
      break;
    case 'input-2':
      template_2['text'] = $("#iframe-2")[0].contentWindow.frames['msg_title'];
      template_2['img']  = $("#iframe-2")[0].contentWindow.frames['cdn_url_235_1'];
      break;
    case 'input-3':
      template_3['text'] = $("#iframe-3")[0].contentWindow.frames['msg_title'];
      template_3['img']  = $("#iframe-3")[0].contentWindow.frames['cdn_url_235_1'];
      break;
    default: return;
  }

  // 修改文章内容
  sleep(160).then(() => { set_contents() });
  set_labal_status(id)
}


// 设置工具栏的标签，更换
function set_labal_status(id){
  switch(id){
    case 'input-1':
      $('#status-1')[0].innerHTML = `${template_1['text']}`;
      $("#input-img1-width")[0].value = `${template_1['width']}`;
      $("#input-img1-height")[0].value =`${template_1['height']}`;
      $("#input-img1-offsetX")[0].value = '100%';
      $("#input-img1-offsetY")[0].value = '100%';
      break;
    case 'input-2':
      $('#status-2')[0].innerHTML = `${template_2['text']}`;
      $("#input-img2-width")[0].value = `${template_2['width']}`;
      $("#input-img2-height")[0].value =`${template_2['height']}`;
      $("#input-img2-offsetX")[0].value = '100%';
      $("#input-img2-offsetY")[0].value = '100%';
      break;
    case 'input-3':
      $('#status-3')[0].innerHTML = `${template_3['text']}`;
      $("#input-img3-width")[0].value = `${template_3['width']}`;
      $("#input-img3-height")[0].value =`${template_3['height']}`;
      $("#input-img3-offsetX")[0].value = '100%';
      $("#input-img3-offsetY")[0].value = '100%';
      break;
    default:
      return;
  }
}

//-------------------------------------------------------------------------------------
// 更新属性

function set_article_canvas_width(value, id){
  const article = $('#ueditor_0').contents().find('svg');
  switch(id){
    case 'input-img1-width': template_1['width'] = value; article[0].setAttribute('viewBox', `0 0 ${template_1['width']} ${template_1['height']}`); break;
    case 'input-img2-width': template_2['width'] = value; article[1].setAttribute('viewBox', `0 0 ${template_2['width']} ${template_2['height']}`); break;
    case 'input-img3-width': template_3['width'] = value; article[2].setAttribute('viewBox', `0 0 ${template_3['width']} ${template_3['height']}`); break;
    default: return;
  }
}

function set_article_canvas_height(value, id){
  const article = $('#ueditor_0').contents().find('svg');
  switch(id){
    case 'input-img1-height': template_1['height'] = value; article[0].setAttribute('viewBox', `0 0 ${template_1['width']} ${template_1['height']}`); break;
    case 'input-img2-height': template_2['height'] = value; article[1].setAttribute('viewBox', `0 0 ${template_2['width']} ${template_2['height']}`); break;
    case 'input-img3-height': template_3['height'] = value; article[2].setAttribute('viewBox', `0 0 ${template_3['width']} ${template_3['height']}`); break;
    default: return;
  }
}

// 更换文章封面
function set_article_img(value, id){
  const article = $('#ueditor_0').contents().find('svg');
  switch(id){
    case 'input-img1': template_1['img'] = value; article[0].style.backgroundImage = `url(${value})`; break;
    case 'input-img2': template_2['img'] = value; article[1].style.backgroundImage = `url(${value})`; break;
    case 'input-img3': template_3['img'] = value; article[2].style.backgroundImage = `url(${value})`; break;
    default: return;
  }
}

function set_article_img_scrollx(value, id){
  const article = $('#ueditor_0').contents().find('svg');
  switch(id){
    case 'input-img1-offsetX': template_1['scrollx'] = value; article[0].style.backgroundPosition = `${template_1['scrollx']} ${template_1['scrolly']}`; break;
    case 'input-img2-offsetX': template_2['scrollx'] = value; article[1].style.backgroundPosition = `${template_2['scrollx']} ${template_2['scrolly']}`; break;
    case 'input-img3-offsetX': template_3['scrollx'] = value; article[2].style.backgroundPosition = `${template_3['scrollx']} ${template_3['scrolly']}`; break;
    default: return;
  }
}

function set_article_img_scrolly(value, id){
  const article = $('#ueditor_0').contents().find('svg');
  console.log(`${template_1['scrollx']} ${template_1['scrolly']}`)
  switch(id){
    case 'input-img1-offsetY': template_1['scrolly'] = value; article[0].style.backgroundPosition = `${template_1['scrollx']} ${template_1['scrolly']}`; break;
    case 'input-img2-offsetY': template_2['scrolly'] = value; article[1].style.backgroundPosition = `${template_2['scrollx']} ${template_2['scrolly']}`; break;
    case 'input-img3-offsetY': template_3['scrolly'] = value; article[2].style.backgroundPosition = `${template_3['scrollx']} ${template_3['scrolly']}`; break;
    default: return;
  }
}

//-------------------------------------------------------------------------------------
// 文章内容

function set_contents(){

  // 模板内容
  const template_contents = `
  <section name="pangmenzhengdao">
  <section style="width: 98.5% !important;max-width: 800px !important;margin: 0px auto !important;box-sizing: border-box !important;"><section><p style="margin: 0px 2px;text-align: left;font-size: 12px;">-------------------------</p>
  <p style="margin: 0px 2px;text-align: left;font-size: 12px;">往期精华文章导读：<br></p>
  <article name="artman_design"><section style="background-color: rgba(255, 255, 255, 0.05);box-sizing: border-box !important;margin: 12px auto !important;border-radius: 6px !important;box-shadow: rgba(162, 169, 182, 0.255) 0px 4px 4px !important;"><svg name="XHXIAIEIN-bg" style="background-image: url(${template_1['img']});background-position: ${template_1['scrollx']} ${template_1['scrolly']};background-size: 100%;background-attachment: scroll;background-repeat: no-repeat;border-top-left-radius: 6px;border-top-right-radius: 6px;-webkit-tap-highlight-color: transparent;" viewBox="0 0 ${template_1['width']} ${template_1['height']}" xmlns="http://www.w3.org/2000/svg"><a name="XHXIAIEIN-url" href="${template_1['url']}" target="_blank" data-linktype="2" _href="${template_1['url']}"><rect width="100%" height="100%" fill="#000" x="0" y="0" opacity="0"></rect></a></svg> <p name="name-text" style="padding: 6px 10px 20px;line-height: 1.5em !important;font-size: 15px !important;font-variant-numeric: normal !important;letter-spacing: 0.5px !important;text-align: left !important;">${template_1['text']}</p></section></article>
  <article name="artman_design"><section style="background-color: rgba(255, 255, 255, 0.05);box-sizing: border-box !important;margin: 12px auto !important;border-radius: 6px !important;box-shadow: rgba(162, 169, 182, 0.255) 0px 4px 4px !important;"><svg name="XHXIAIEIN-bg" style="background-image: url(${template_2['img']});background-position: ${template_2['scrollx']} ${template_2['scrolly']};background-size: 100%;background-attachment: scroll;background-repeat: no-repeat;border-top-left-radius: 6px;border-top-right-radius: 6px;-webkit-tap-highlight-color: transparent;" viewBox="0 0 ${template_2['width']} ${template_2['height']}" xmlns="http://www.w3.org/2000/svg"><a name="XHXIAIEIN-url" href="${template_2['url']}" target="_blank" data-linktype="2" _href="${template_2['url']}"><rect width="100%" height="100%" fill="#000" x="0" y="0" opacity="0"></rect></a></svg> <p name="name-text" style="padding: 6px 10px 20px;line-height: 1.5em !important;font-size: 15px !important;font-variant-numeric: normal !important;letter-spacing: 0.5px !important;text-align: left !important;">${template_2['text']}</p></section></article>
  <article name="artman_design"><section style="background-color: rgba(255, 255, 255, 0.05);box-sizing: border-box !important;margin: 12px auto !important;border-radius: 6px !important;box-shadow: rgba(162, 169, 182, 0.255) 0px 4px 4px !important;"><svg name="XHXIAIEIN-bg" style="background-image: url(${template_3['img']});background-position: ${template_3['scrollx']} ${template_3['scrolly']};background-size: 100%;background-attachment: scroll;background-repeat: no-repeat;border-top-left-radius: 6px;border-top-right-radius: 6px;-webkit-tap-highlight-color: transparent;" viewBox="0 0 ${template_3['width']} ${template_3['height']}" xmlns="http://www.w3.org/2000/svg"><a name="XHXIAIEIN-url" href="${template_3['url']}" target="_blank" data-linktype="2" _href="${template_3['url']}"><rect width="100%" height="100%" fill="#000" x="0" y="0" opacity="0"></rect></a></svg> <p name="name-text" style="padding: 6px 10px 20px;line-height: 1.5em !important;font-size: 15px !important;font-variant-numeric: normal !important;letter-spacing: 0.5px !important;text-align: left !important;">${template_3['text']}</p></section></article>
<section><p><br></p><p style="box-sizing: border-box !important;text-align: center !important;font-size: 14px !important;color: rgb(178, 178, 178) !important;">-END-</p><p><br></p></section>
<p style="display: none !important;font-size: 0px !important;color: transparent !important;line-height: 0px !important;padding: 0px !important;margin: 0px !important;">本文章转载自微信公众号：庞门正道</p>
<section class="wx-profile-card-cover" style="overflow: hidden;line-height: 0;box-sizing: border-box;"><svg viewBox="0 0 800 354" xmlns="http://www.w3.org/2000/svg" style="box-sizing: border-box;"><foreignObject width="100%" height="100%" style="box-sizing: border-box;"><svg style="background-repeat: no-repeat;background-size: 100%;pointer-events: none;background-image: url(&quot;https://mmbiz.qpic.cn/sz_mmbiz_jpg/I3KJh29KMaTodOa9NiahjQxib6qHK50xZIVaERp7QdfetI86QVbOk6nN6B53w6WInQhuxgYvjwKkdTVMeFfwqQAA/640?wx_fmt=jpeg&quot;);box-sizing: border-box;" viewBox="0 0 800 354"></svg></foreignObject><foreignObject width="100%" height="100%" style="box-sizing: border-box;"><section style="overflow: hidden;opacity: 0;transform: scale(80);-webkit-transform: scale(80);-moz-transform: scale(80);-o-transform: scale(80);box-sizing: border-box;" class="mp_profile_iframe_wrp custom_select_card_wrp"><mpchecktext contenteditable="false" id="1701761888994_0.29576563308299897"></mpchecktext><mp-common-profile class="js_uneditable custom_select_card mp_profile_iframe mp_common_widget" data-id="MzA5NjIzNjgxNw==" data-pluginname="mpprofile" data-headimg="http://mmbiz.qpic.cn/mmbiz_png/Rhh4hWLlib1b8rI9CMYz2Cvl3Ge06Ltr7Rb94SlGeTiaUYc2F8FZqic68Oo8QXuw9agwNhvnKngFBpw6vrnp3unzw/0?wx_fmt=png" data-nickname="庞门正道" data-alias="" data-signature="播主：阿门-前腾讯视觉设计师、站酷排名前10的自由职业设计师。  每天早上与你一起分享一点设计&amp;摄影小知识小技巧。 欢迎回复或咨询探讨相关话题。" data-from="0" data-is_biz_ban="0" contenteditable="false"></mp-common-profile></section></foreignObject></svg></section><section style="margin-top: 8px; max-width: 100% !important; min-height: 1em !important; font-variant-numeric: normal !important; letter-spacing: 0.544px !important; line-height: 27.2px !important; white-space: normal !important; text-align: center !important; background-color: rgb(255, 255, 255) !important; box-sizing: border-box !important; overflow-wrap: break-word !important;"><span style="max-width: 100% !important;color: rgb(255, 255, 255) !important;font-size: 18px !important;background-color: rgb(49, 133, 155) !important;box-sizing: border-box !important;overflow-wrap: break-word !important;"><strong style="max-width: 100% !important;box-sizing: border-box !important;overflow-wrap: break-word !important;padding-left: 6px !important;">越努力，越幸运。</strong></span></section><p style="max-width: 100% !important;min-height: 1em !important;font-variant-numeric: normal !important;letter-spacing: 0.544px !important;line-height: 27.2px !important;white-space: normal !important;text-align: center !important;background-color: rgb(255, 255, 255) !important;box-sizing: border-box !important;overflow-wrap: break-word !important;"><span style="max-width: 100% !important;color: rgb(255, 255, 255) !important;font-size: 18px !important;background-color: rgb(49, 133, 155) !important;box-sizing: border-box !important;overflow-wrap: break-word !important;"><strong style="max-width: 100% !important;box-sizing: border-box !important;overflow-wrap: break-word !important;padding-left: 6px !important;">这里是庞门正道。</strong></span></p>
</section>
    `

  // 修改正文
  $('#ueditor_0').contents().find('.view')[0].innerHTML = template_contents

  $('#viewcode-html')[0].textContent = ''
  $('#viewcode-img')[0].innerHTML = ''

   refresh_information()
}

// 覆盖文章内容
function overwrite_contents(value){
  $('#ueditor_0').contents().find('.view')[0].innerHTML = value
  refresh_information()
}


function refresh_information(){

  // 清空原本的数据
  $('#viewcode-html')[0].innerHTML = ''
  $('#viewcode-img')[0].innerHTML = ''

  // 获取当前HTML内容
  get_contents_html()
  get_contents_img()
  get_contents_url()
}


// 获取文章的HTML内容
function get_contents_html(){
   $('#viewcode-html')[0].textContent = $('#ueditor_0').contents().find('.view')[0].innerHTML;
}


// 获取文章的URL内容
function get_contents_url(){
  const articles = document.querySelectorAll('[name="pangmenzhengdao"] article');
  articles.forEach((article, index) => {
    const svgElement = article.querySelector('svg');
    const hrefValue = getArticleUrl(svgElement);
    document.querySelector(`#input-${index + 1}`).value = hrefValue;
  });
}


// 获取文章的HTML背景图片
function get_contents_img(){

    // 编辑器正文
    const article = $('#ueditor_0').contents();

    // 检测是否存在模板，如果不存在则获取图片地址
    if (article.find('section').length > 0){
      article.find('svg').each(function(i, s){
         let node = document.createElement('pre');
         node.innerHTML = getBackgroundUrl(s.outerHTML);
         $('#viewcode-img')[0].appendChild(node);
      });
    } else {
      article.find('img').each(function(i, s){
        let node = document.createElement('pre');
        node.innerHTML = s.src;
        $('#viewcode-img')[0].appendChild(node);
      });
    }

}

//-------------------------------------------------------------------------------------
// Main

function main(){
    const page = String(window.location.href).split('/')[4].split('?')[0];

    if (document.querySelectorAll('.weui-desktop-sub-menu').length > 0) {
      added_menu();
    }

    // 在模板编辑注入'编辑器'
    if (page == 'appmsgtemplate' && get_url_params('action') == "edit") {
        show_editor();
    }
}


window.onload = main