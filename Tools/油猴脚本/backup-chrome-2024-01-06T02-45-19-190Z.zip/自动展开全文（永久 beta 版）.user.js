// ==UserScript==
// @name        自动展开全文（永久 beta 版）
// @namespace   Expand the article for meow.
// @match       *://*/*
// @grant       GM_info
// @grant       GM_addStyle
// @grant       GM_getValue
// @grant       GM_setValue
// @grant       GM_deleteValue
// @grant       GM_registerMenuCommand
// @grant       GM_unregisterMenuCommand
// @grant       GM_openInTab
// @run-at      document-end
// @version     1.2.0.1
// @supportURL  https://docs.qq.com/form/page/DYVFEd3ZaQm5pZ1ZR
// @homepageURL https://script.izyx.xyz/expand-the-article/
// @inject-into content
// @noframes
// @author      稻米鼠
// @created     2020-07-24 07:04:35
// @updated     2020-09-05 13:48:34
// @description This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// ==/UserScript==
