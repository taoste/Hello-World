// ==UserScript==
// @name 编程随想的博客评论区修复
// @namespace http://tampermonkey.net/
// @version 0.1
// @description 编程随想博客评论区修复
// @author 热心网友
// @match https://program-think.blogspot.com/*
// @icon https://www.google.com/s2/favicons?sz=64&domain=blogspot.com
// @run-at document-body
// @grant none
// @license The Unlicense
// ==/UserScript==

(function() {
'use strict';
$(document).ready(function() {
let str = $('a#comment-editor-src').attr('href');
if (str) {
let postID = str.match(/po=(\d+)/)[1]
$('a#comment-editor-src').attr('href', `${str}&postID=${postID}`);
}
});
})();