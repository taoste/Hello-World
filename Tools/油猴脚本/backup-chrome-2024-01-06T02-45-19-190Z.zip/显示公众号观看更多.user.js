// ==UserScript==
// @name         显示公众号观看更多
// @namespace    https://console.tebieshuang.xyz
// @supportURL   https://console.tebieshuang.xyz
// @version      1.0
// @description  元初芸提供标准化的零售行业标准SAAS，为您便捷、快速地完成微信相关公众号、小程序的快速部署！！ https://console.tebieshuang.xyz
// @author       Leo
// @match        https://mp.weixin.qq.com/cgi-bin/appmsg?t=media/appmsg_edit&action=edit*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    setTimeout(function(){
       var obj = document.querySelector('#js_related_video_area');
       if( obj !== null ){
            obj.removeAttribute('style');
       }
    }, 2000);
})();