// ==UserScript==
// @name         壹伴排版 Plus
// @namespace    http://tampermonkey.net/
// @version      0.4
// @description  壹伴排版 Plus，免开 vip，欢迎关注 前端公众号：JS酷
// @author       #前端公众号：JS酷
// @match        https://yiban.io/*
// @match        https://mp.weixin.qq.com/*
// @icon         https://assets.yiban.io/assets/imgs/favicon-new-8615028296.ico
// @grant        none
// @license MIT
// ==/UserScript==

(function() {
    'use strict';
    if (window.location.host == 'mp.weixin.qq.com') {
    $(function() {

function history_article() {
  const root = document.querySelector(
    '.history-article-recommend-dialog'
  ).shadowRoot

  root.querySelector('.mpa-btn-primary').addEventListener('click', () => {
    const con = root.querySelector('.selected-article-content')
    const div = document.createElement('div')
    div.innerHTML = con.innerHTML

    Array.from(div.querySelectorAll('div')).forEach((item) => {
      item.remove()
    })
    Array.from(div.querySelectorAll('a')).forEach((item) => {
        item.href=$(item).attr('data-href')
    })
    const html = div.innerHTML
    window.UE.getEditor('js_editor').execCommand('insertHTML', html)

    root.querySelector('footer .mpa-btn').click()
  })
}
        setTimeout(() => {
            const style = document.createElement('style');
            const heads = document.querySelector('head');
            style.setAttribute('type', 'text/css');
            style.innerHTML = `.buy-vip-dialog-v3{display:none !important;}.mpa-dialog-parent-no-scroll {
      overflow: auto !important;
    }`;
            heads.append(style);

const root0 = document.querySelector('.mpa-plugin-edit-enhance')
  .shadowRoot
root0.querySelectorAll('.tools li')[13].addEventListener('click', () => {
  history_article()
})

        }, 1000);
    })

    $(document)
        .off('click', '.material-item .cover')
        .on('click', '.material-item .cover', e => {
            e.stopPropagation();
            const html = $(e.target)
                .parent()
                .find('.html-container')
                .html();
            window.UE.getEditor('js_editor').execCommand('insertHTML', html);
        });

}

if (window.location.host == 'yiban.io') {
    $(document)
        .off('click', '.copy')
        .on('click', '.copy', function(e) {
            e.stopImmediatePropagation();
            const text = $(this)
                .parents('.style-waterfall-inner')
                .find('.detail')
                .html();

            console.log(text);
            // 复制触发
            if (text) {
                
                document.addEventListener('copy', function copyCall(e) {
                    e.preventDefault();
                    e.clipboardData.setData('text/html', text);
                    e.clipboardData.setData('text/plain', text);
                    document.removeEventListener('copy', copyCall);
                });
                document.execCommand('copy');
                alert('复制成功');
            } else {
                alert('复制失败');
            }
            $('.pay-tips-dialog').hide();
        });
}
})();