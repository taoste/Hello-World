// ==UserScript==
// @name         微信地址精简
// @namespace    http://domain.com/directory
// @version      0.2
// @description  去掉微信公众号文章地址的多余部分，减小长度。
// @author       幸福的赢得
// @include      https://mp.weixin.qq.com/s?*
// @grant        none
// ==/UserScript==


if (/chksm/.test (location.href) ) {
    var plainPath =
    location.href.replace (/&chksm=[\S]*/, "")

location.replace(plainPath)
}