<?php
@ ini_set('display_errors', false);

@ header("content-type: text/html; charset=utf-8");


function city_err_journal($city) {
  global $web;
  $city_err_file = $GLOBALS['WEATHER_DATA'].'writable/__temp__/weather/'.$web['weather_from'].'/img/city_err_journal.txt';
  if ($f = file_get_contents($city_err_file)) {
    if (preg_match("/".preg_quote($city, "/")."[\n\r]+/", $f)) {
      return false;
    }
  }
  if ($fp = @fopen($city_err_file, 'ab')) {
    @fwrite($fp, "".$city."\n");
    @fclose($fp);
  }
}

function get_w_img($img) {
  global $web;
  $img = preg_replace('/\?.*$/', '', $img);
  $img = 'https://'.preg_replace('/^(https?)?\/\//', '', $img);
  $img_ = basename($img);
  $img_file = 'writable/__temp__/weather/'.$web['weather_from'].'/img/'.$img_.'';
  if (file_exists($GLOBALS['WEATHER_DATA'].$img_file)) {
    return $img_file;
  } else {
    if ($img_file_ = read_file($img)) {
      write_file($GLOBALS['WEATHER_DATA'].$img_file, $img_file_);
    } else {
      return $img;
    }
  }
  return $img_file;
}

function get_w_img_($matches) {
  global $web;
  $matches[2] = preg_replace('/\?.*$/', '', $matches[2]);
  $matches[2] = 'https://'.preg_replace('/^(https?\:)?\/\//', '', $matches[2]);
  $img_ = basename($matches[2]);
  $img_file = 'writable/__temp__/weather/'.$web['weather_from'].'/img/'.$img_.'';
  if (file_exists($GLOBALS['WEATHER_DATA'].$img_file)) {
    return $matches[1].'src="'.$img_file.'"';
  } else {
    if ($img_file_ = read_file($matches[2])) {
      write_file($GLOBALS['WEATHER_DATA'].$img_file, $img_file_);
    } else {
      return $matches[1].'src="'.$matches[2].'"';
    }
  }
  return $matches[1].'src="'.$img_file.'"';
}

function get_w_a_($matches) {
  global $web;
  $matches[3] = preg_replace('/天气$/', '', $matches[3]);
  return '<a href="weather.php?city='.urlencode($matches[3]).'&city2='.$matches[1].'"'.$matches[2].'><h'.$matches[4].'>'.$matches[3].'</h'.$matches[4].'>';
}


if (isset($_GET['type']) && $_GET['type'] == 2) :

$t = '2';
//得到天气 完善的 国内
function getWEATHER($city, $city2) {
  global $tmp;
  if (is_numeric($city2)) {
    return getWEATHER_world($city, $city2);
  }
  $weatherurl = 'https://www.tianqi.com/'.$city2.'/';
  $weather = $weather2 = '';
  if ($W_FR = read_file($weatherurl)) {
    if (preg_match('/(<div class="weatherbox">.+)<div class="wrap1100 zhishubox">/isU', $W_FR, $matches)) {
      $weather = preg_replace('/<i><a href="\/chinacity\.html">\[切换城市\]<\/a><\/i>/isU', '', $matches[1]);
      $weather = preg_replace('/(<[^\>]+ src=")(https?\:)?\/\//isU', '$1https://', $weather);
      $weather = preg_replace('/src="https?\:\/\/static\.tianqistatic\.com\/static\/js\/canvas\.js"/isU', 'src="readonly/weather/www.tianqi.com/canvas.js"', $weather);
      $weather = preg_replace_callback('/(<img [^\>]*)src="(.+)"/isU', 'get_w_img_', $weather);
      $weather = preg_replace('/<a href="\/'.$city2.'\/(15|30)\/">/isU', '<a href="https://www.tianqi.com/'.$city2.'/$1/" target="_blank">', $weather);
      unset($matches);
    }
    if (preg_match('/<div\s+class="wrap1100\s+mainbox">.*<div\s+class="left">(.+)<div\s+class="hhxCulture\s+clearfix">/isU', $W_FR, $matches)) {
      $weather2 = $matches[1];
      $weather2 = preg_replace_callback('/(<img [^\>]*)src="(.+)"/isU', 'get_w_img_', $weather2);
      $weather2 = preg_replace('/<a [^>]*href="(\/[\w-]+\/15\/"[^>]*>)/isU', '<a href="https://www.tianqi.com$1', $weather2);
      $weather2 = preg_replace_callback('/<a [^>]*href="\/([\w-]+)\/"([^>]*)>.*<h\d+>(.+)<\/h(\d+)>/isU', 'get_w_a_', $weather2);
      $weather2 = preg_replace('/<div\s*class="banner760[^>]*>[\s\n\r]*<script.+\/script>[\s\n\r]*<\/div>/isU', '', $weather2);
      unset($matches);
    }
  }
  if (!empty($weather)) {
    $GLOBALS['WEATHER_BORN'] = 1;
    $weather = '
<link href="readonly/weather/www.tianqi.com/1.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="readonly/weather/www.tianqi.com/jQuery.1.8.2.min.js"></script>
<style>
.weatherbox { z-index:0; }
.day7 { height:320px !important; }
.day7 ul, .day7 li, .day7 dd, .day7 dt, .day7 dl, .day7 p { list-style:none; margin:0; padding:0; }
</style>
<script type="text/javascript" language="javaScript">
if (par != null) {
  var bodyW = 500;
  var bodyH = 450;
  document.write(\'<style> body { width:500px!important; height:450px!important; overflow:hidden!important; margin:0!important; }</style>\');
}
</script>
'.$weather.$weather2;
    write_file($tmp, $weather);
  } else {
    @ setcookie('weathercity', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
    @ setcookie('weathercity2', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
    @unlink($tmp);
	$GLOBALS['WEATHER_BORN'] = 0;
    $weather .= '<span style="background-color:#FFFFFF;">天气预报获取失败！请稍候再试。<br />
可能采集源：天气网www.tianqi.com出错[<a href="weather.php?err='.urlencode($weatherurl).'" target="_blank" style="color:blue;">去解决</a>]</span>';
  }
  return $weather;
}
//得到天气 完善的 国际
function getWEATHER_world($city, $city2) {
  global $tmp;
  $weatherurl = 'https://www.tianqi.com/worldcity/'.$city2.'.html';
  $weather = $weather2 = '';
  if ($W_FR = read_file($weatherurl)) {
    if (preg_match('/(<div\s+class="w_1100">.+)<div\s+class="blank20">/isU', $W_FR, $matches)) {
      $weather = $matches[1];
      $weather = preg_replace_callback('/(<img [^\>]*)src="(.+)"/isU', 'get_w_img_', $weather);
      $weather = preg_replace('/<a [^>]*href="(\/worldcity\/[\w-]+\/(15|10)\/)"[^>]*>/isU', '<a href="https://www.tianqi.com$1" target="_blank">', $weather);
      unset($matches);
    }
    if (preg_match('/<div\s+class="national_w">.*<div\s+class="open_button">/isU', $W_FR, $matches)) {
      $weather2 = '<div class="w_1100">'.$matches[0].'</li></ul></div></div></div>';
      $weather2 = preg_replace_callback('/(<img [^\>]*)src="(.+)"/isU', 'get_w_img_', $weather2);
      $weather2 = preg_replace_callback('/<a [^>]*href="\/[\w-]+\/(\d+)\.html"([^>]*)>.*<h\d+>(.+)<\/h(\d+)>/isU', 'get_w_a_', $weather2);
      $weather2 = preg_replace('/<div\s*class="banner760[^>]*>[\s\n\r]*<script.+\/script>[\s\n\r]*<\/div>/isU', '', $weather2);
      $weather2 = preg_replace('/<a [^>]*class="more" [^>]*href="(\/[\w-]+\/"[^>]*>)/isU', '<a class="more" href="https://www.tianqi.com$1', $weather2);
      unset($matches);
    }
  }
  if (!empty($weather)) {
    $GLOBALS['WEATHER_BORN'] = 1;
    $weather = '
<link href="readonly/weather/www.tianqi.com/2.css"  rel="stylesheet" type="text/css">
<script type="text/javascript" language="javaScript">
if (par != null) {
  var bodyW = 438;
  var bodyH = 322;
  document.write(\'<style> body { width:438px!important; height:322px!important; overflow:hidden!important; margin:0!important; }</style>\');
}
</script>
<script type="text/javascript" language="javaScript">
if (par !=null){
var oDiv = document.getElementById("body");
oDiv.style.cursor="pointer";
oDiv.addEventListener("click", function(){
    window.open("weather.php", "_blank");
});
}
</script>
'.$weather.$weather2;
    write_file($tmp, $weather);
  } else {
    @ setcookie('weathercity', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
    @ setcookie('weathercity2', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
    @unlink($tmp);
	$GLOBALS['WEATHER_BORN'] = 0;
    $weather .= '<span style="background-color:#FFFFFF;">天气预报获取失败！请稍候再试。<br />
可能采集源：天气网www.tianqi.com出错[<a href="weather.php?err='.urlencode($weatherurl).'" target="_blank" style="color:blue;">去解决</a>]</span>';
  }
  return $weather;
}

else :

$t = '';
//得到天气 简单的 国内
function getWEATHER($city, $city2) {
  global $tmp;
  if (is_numeric($city2)) {
    return getWEATHER_world($city, $city2);
  }
  $weatherurl = 'https://www.tianqi.com/'.$city2.'';
  $weather = '';
  if ($W_FR = read_file($weatherurl)) {
    $weather .= '
<span class="weather">
  <span id="city_where" onmouseover="ct=window.setInterval(function(){showWD($(\'city_where\'), \'weather.php?area=china\', \'500px\', \'auto\');}, 100);" onmouseout="window.clearInterval(ct);">
    <!--a href="weather.php?area=china" id="weather_where"><img src="readonly/images/po.png" /></a-->
    <a href="weather.php" id="weather_city" title="切换城市">'.$city.'</a>
  </span>
  <a href="weather.php" id="weather_show">
';

    preg_match('/<dd class="weather">.+<canvas id="canvas">/isU', $W_FR, $m);
    $W_FR = $m[0];
    unset($m);

    $runget0 = false;
    //if (preg_match('/<dd class="weather">(.*)<img [^>]*src="([^\"\'\>]+)"[^\>]*>.*<p class="now"><b>(\-?\d+)<\/b><i>℃<\/i><\/p>.*<span><b>(.+)<\/b>/isU', $W_FR, $matches_kq)) {
    if (preg_match('/<dd class="weather">.*<img [^>]*src="([^\"\'\>]+)"[^\>]*>.*<p class="now"><b>(\-?\d+)<\/b><i>℃<\/i><\/p>.*<span><b>(.+)<\/b>/isU', $W_FR, $m)) {
	  $weather .= '<span id="w_today" title="当前" onmouseover="sSD(this,event);"><span class="w_img"><img src="'.get_w_img($m[1]).'" style="width:34px;height:34px;" /></span> <span class="w_qingkuang">'.$m[3].'</span> <span class="w_wendu'.(floatval($m[2])>0 ? ' w_wendu_ls':' w_wendu_lx').'">'.$m[2].'</span>℃</span> ';
      unset($m);
      if (preg_match('/<dd class="kongqi"[^\>]*><h5 style="background\-color\:(.+)\;">空气质量：(.+)<\/h5>/isU', $W_FR, $m)) {
        $weather .= '<span id="w_kq" title="空气质量" onmouseover="sSD(this,event);" style="background-color:'.$m[1].';color:#FFFFFF;font-size:12px !important;">'.$m[2].'</span>';
      }
      unset($m);
      $runget0 = true;
    }
    $runget1 = false;
    if (preg_match('/<ul class="week">.*<img src="([^\"\'\>]+)"[^\>]*>/isU', $W_FR, $matches_today_tubiao)) {
	  preg_match('/<ul class="txt txt2">.+<li>(.+)<\/li>/isU', $W_FR, $matches_today_qingkuang);
	  preg_match('/<div class="zxt\_shuju"[^>]*>.*<ul>.*<li><span>(\-?\d+)<\/span><b>(\-?\d+)<\/b><\/li>/isU', $W_FR, $matches_today_wendu);

      $weather .= ' | ';
      $weather .= '<span id="w_today" title="今天" onmouseover="sSD(this,event);"><span class="w_img2"><img src="'.get_w_img($matches_today_tubiao[1]).'" style="width:24px;height:24px;" /> </span> <span class="w_qingkuang">'.$matches_today_qingkuang[1].' </span> <span class="w_wendu'.(floatval($matches_today_wendu[2])>0 ? ' w_wendu_ls':' w_wendu_lx').'">'.$matches_today_wendu[2].'</span>~<span class="w_wendu'.(floatval($matches_today_wendu[1])>0 ? ' w_wendu_ls':' w_wendu_lx').'">'.$matches_today_wendu[1].'</span>℃</span>';
      $weather .= '</span>';
      $weather .= '<!--span class="w_xiangqing" title="未来详情">︾</span-->';

      $runget1 = true;
      unset($atches_today_tubiao, $matches_today_qingkuang, $matches_today_wendu);
    }
    $weather .= '</a>
</span>';
    unset($W_FR);
  }
  if ($runget0 || $runget1) {
	$GLOBALS['WEATHER_BORN'] = 1;
    write_file($tmp, $weather);
  } else {
  	$GLOBALS['WEATHER_BORN'] = 0;
    @ setcookie('weathercity', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
    @ setcookie('weathercity2', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
    @unlink($tmp);
    $weather .= '天气预报获取失败！</a>[<a href="weather.php?err='.urlencode($weatherurl).'" target="_blank" style="color:blue;">去解决</a>]</span>';
  }
  return $weather;
}
//得到天气 简单的 国际
function getWEATHER_world($city, $city2) {
  global $tmp;
  $weatherurl = 'https://www.tianqi.com/worldcity/'.$city2.'.html';
  $weather = '';
  if ($W_FR = read_file($weatherurl)) {
    $weather .= '
<span class="weather">
  <span id="city_where" onmouseover="ct=window.setInterval(function(){showWD($(\'city_where\'), \'weather.php?area=china\', \'500px\', \'auto\');}, 100);" onmouseout="window.clearInterval(ct);">
    <!--a href="weather.php?area=china" id="weather_where"><img src="readonly/images/po.png" /></a-->
    <a href="weather.php" id="weather_city" title="切换城市">'.$city.'</a>
  </span>
  <a href="weather.php" id="weather_show">
';

    preg_match('/<div\s+class="fl\s+zuoce">.+<\/li>/isU', $W_FR, $m);
    $W_FR = $m[0];
    unset($m);

    $runget0 = false;
    if (preg_match('/<div class="img">.*<img [^>]*src="([^\"\'\>]+)"[^\>]*>.*<strong>(\-?\d+)<\/strong>.*<span>(.+)<\/span>/isU', $W_FR, $m)) {
	
	  $weather .= '<span id="w_today" title="当前" onmouseover="sSD(this,event);"><span class="w_img"><img src="'.get_w_img($m[1]).'" style="width:34px;height:34px;" /></span> <span class="w_qingkuang">'.$m[3].'</span> <span class="w_wendu'.(floatval($m[2])>0 ? ' w_wendu_ls':' w_wendu_lx').'">'.$m[2].'</span>℃</span> ';
      unset($m);
      $runget0 = true;
    }
    $runget1 = false;
    if (preg_match('/<ul\s+class="clearfix\s+tianshu">.*<img [^>]*src="([^\"\'\>]+)"[^\>]*>.*<div class="duoyun">(.+)<\/div>.*<div class="du">(.+)<\/div>/isU', $W_FR, $m)) {

      $weather .= ' | ';
      $weather .= '<span id="w_today" title="今天" onmouseover="sSD(this,event);"><span class="w_img2"><img src="'.get_w_img($m[1]).'" style="width:24px;height:24px;" /> </span> <span class="w_qingkuang">'.$m[2].' </span> <span class="w_wendu">'.$m[3].'</span></span>';
      $weather .= '</span>';
      $weather .= '<!--span class="w_xiangqing" title="未来详情">︾</span-->';

      unset($m);
      $runget1 = true;
    }
    $weather .= '</a>
</span>';
    unset($W_FR);
  }
  if ($runget0 || $runget1) {
	$GLOBALS['WEATHER_BORN'] = 1;
    write_file($tmp, $weather);
  } else {
  	$GLOBALS['WEATHER_BORN'] = 0;
    @ setcookie('weathercity', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
    @ setcookie('weathercity2', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
    @unlink($tmp);
    $weather .= '天气预报获取失败！</a>[<a href="weather.php?err='.urlencode($weatherurl).'" target="_blank" style="color:blue;">去解决</a>]</span>';
  }
  return $weather;
}

endif;


//得到城市
function getCITY($str) {
  if (!empty($str)) {

    $str = preg_replace('/^.*(新疆|广西|内蒙古|宁夏|西藏)(.*自治区)?/', '', $str);
    $str = preg_replace('/^.*(台湾|广东|江苏|浙江|山东|福建|辽宁|黑龙江|河北|湖北|湖南|安徽|吉林|海南|四川|陕西|山西|河南|云南|甘肃|江西|青海|贵州)(省)?/', '', $str);
    //镇
    $str = preg_replace('/^.*(固|清|景德|丰|天|辛贾尔|圣洛伦佐|黄刀|东玫瑰|阿莱马纳|帕斯夸谷|埃斯蒂加里维亚元帅|艾丽斯|克拉仑斯|刚果|邓肯|莫斯|黑|皇后)镇.*$/', '$1镇', $str);
    //区
    $str = preg_replace('/^.*(北京朝阳|城|北林|袁州|长春朝阳|溪湖|银州|矿|城|郊|攀枝花东|攀枝花西|这|斯奈德岩石|威廉姆斯|洪加达污染)区.*$/', '$1区', $str);
    //县
    $str = preg_replace('/^(.*市)?(芜湖|承德|新乡|长沙|衡阳|邵阳|湘潭|岳阳|株洲|吉安|九江|南昌|上饶|通化|朝阳|抚顺|辽阳|铁岭|大同|宜宾|和田|乌鲁木齐|伊宁|开|忠|和|黟|歙|寿|泗|萧|泾|沙|漳|岷|成|文|康|礼|徽|环|宁|梅|横|藤|盘|唐|易|蠡|雄|青|献|沧|涉|磁|邱|魏|景|赵|滦|威|任|蔚|宾|滑|浚|淇|温|杞|嵩|郏|叶|范|陕|睢|辉|息|新|房|随|澧|南|道|攸|丰|沛|赣|义|托|多|曹|单|冠|莘|费|莒|沁|祁|隰|吉|蒲|古|临|兴|岚|应|代|盂|绛|夏|眉|凤|陇|勉|洋|耀|华|户|乾|彬|富|佳|理|茂|郫|渠|达|泸|安|高|珙|荣|朗|索|云|班斯瓦拉|纳高尔|白龙尾|静冈|腾|莫莱|坎迪|良乌)县.*$/', '$2xian', $str);
    //县转回
    $str = preg_replace('/^(.*市)?(.+)县.*$/', '$2', $str);
    $str = preg_replace('/^(.+)xian$/', '$1县', $str);
    //盟
    //$str = preg_replace('/^(兴安|阿拉善|西)盟$/', '$1盟', $str);
    $str = preg_replace('/^(.*市)?(.+)盟.*$/', '$2盟', $str);
    //旗
    $str = preg_replace('/^(.*市)?(.+)旗.*$/', '$2旗', $str);
    //市
    $str = preg_replace('/^.*(北|南|沙|津|西|呼|新|芒|胡志明|衙庄|藩切|三口洋|横滨|津|人吉|吴|纹别|名护|牛深|銚子|御前崎|井邑|沙缴|柔佛州新山|达沃|宿务|奎松|三投斯将军|斯里巴加湾|吕勒奥|阿尔耶普卢格|直布罗陀|奥克拉荷马|甘露|圣皮埃尔|伯利兹|伊萨山|卡萨布兰卡|布瓦凯)市$/', '$1市', $str);
    $str = preg_replace('/^(.*市)?(.+)市.*$/', '$2', $str);

  }
  $city = (!empty($str) && !strstr($str,'本机地址') && !strstr($str,'局域网') && !strstr($str,'IANA保留地址')) ? $str : '北京';
  //@ setcookie('weathercity', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
  //@ setcookie('weathercity', $city, time() + 365 * 24 * 60 * 60, '/'); //+8*3600
  //unset($str);
  return $city;
}

function getCITY2($city) {
  global $web;
  @ setcookie('weathercity2', '', -(time() + 365 * 24 * 60 * 60), '/'); //+8*3600
  if ($city_arr_file = file_get_contents($GLOBALS['WEATHER_DATA'].'readonly/weather/'.$web['weather_from'].'/getweather_seek.php')) {
    if (preg_match('/\''.preg_quote($city, '/').'\|([\w\-]+)\'/', $city_arr_file, $m)) {
      return $m[1];
    } else {
      city_err_journal($city);
    }
  } else {
    city_err_journal($city);
  }
  return '';
}


if (!$city = $_GET['city']) {
  if (!$city = $_COOKIE['weathercity']) {
    require($GLOBALS['WEATHER_DATA'].'readonly/weather/getip.php');
    $myobj = new ipLocation();
    $ip = $myobj->getIP();
    $address = $myobj->getaddress($ip);
    $myobj = NULL;
    $city = getCITY(iconv("gbk", "utf-8", $address["area1"]));
    //$city = getCITY($address["area1"]);
  }
} else {
  $get = 1;
}

if (empty($city)) {
  $city = '北京';
}

if (!$city2 = $_GET['city2']) {
  if (isset($get)) {
    if (!$city2 = getCITY2($city)) {
      $city = '北京';
      $city2 = 'beijing';
    }
  } else {
    if (!$city2 = $_COOKIE['weathercity2']) {
      if (!$city2 = getCITY2($city)) {
        $city = '北京';
        $city2 = 'beijing';
     }
    }
  }
}

unset($get);

@ setcookie('weathercity', $city, time() + 365 * 24 * 60 * 60, '/'); //+8*3600
@ setcookie('weathercity2', $city2, time() + 365 * 24 * 60 * 60, '/'); //+8*3600







$weather = '';
$tmp = $GLOBALS['WEATHER_DATA'].'writable/__temp__/weather/'.$web['weather_from'].'/'.urlencode($city).''.$t.'.txt';
$time = time();
$filemtime = @file_exists($tmp) ? @filemtime($tmp) : 0;
/*
$time = time();
$pass = date('G') * 3600 + date('i') * 60 + date('s');
$time_0000 = $time - $pass;
$step_1710 = 17 * 3600 + 30 * 60;
$step_0810 = 8 * 3600 + 20 * 60;

if ($pass >= $step_1710) {
  if ($filemtime != 0 && $filemtime >= $time_0000 + $step_1710) {
    $weather = @file_get_contents($tmp);
  }
  //缓存到第二天08:10
  $diff_s = $step_0810 - $pass + 86400;
} else {
  if ($pass >= $step_0810) {
    if ($filemtime != 0 && $filemtime >= $time_0000 + $step_0810) {
      $weather = @file_get_contents($tmp);
    }
    //缓存到17:10 新浪17:00更新一次
    $diff_s = $step_1710 - $pass;
  } else {
    if ($filemtime != 0 && $filemtime >= $time_0000 + $step_1710 - 86400) {
      $weather = @file_get_contents($tmp);
    }
    //缓存到08:10 新浪8:00更新一次
    $diff_s = $step_0810 - $pass;
  }
}
*/

$step = (isset($web['weather_step']) && is_numeric($web['weather_step']) && $web['weather_step'] > 0) ? $web['weather_step'] * 3600 : 7200; //缓存2小时

//有效期截止时刻
$ekey = $filemtime - (gmdate('i', $filemtime + floatval($web['time_pos']) * 3600) * 60 + gmdate('s', $filemtime + floatval($web['time_pos']) * 3600)) + $step;
//下一个有效期截止时刻
$next = $time - (gmdate('i', $time + floatval($web['time_pos']) * 3600) * 60 + gmdate('s', $time + floatval($web['time_pos']) * 3600)) + $step;


if ($time >= $ekey) {
  $weather = getWEATHER($city, $city2);
  if ($GLOBALS['WEATHER_BORN'] == 1) {
    header("Cache-Control: max-age = ".($next - $time)."");
    $expires = gmdate("D, d M Y H:i:s", $next + floatval($web['time_pos']) * 3600).' GMT';
    header('Expires: '.$expires.'');
  }
} else {
  header("Cache-Control: max-age = ".($ekey - $time)."");
  $expires = gmdate("D, d M Y H:i:s", $ekey + floatval($web['time_pos']) * 3600).' GMT';
  header('Expires: '.$expires.'');
  //include($tmp);
  $weather = @file_get_contents($tmp);
}

//ob_end_flush();



echo $weather;





















?>