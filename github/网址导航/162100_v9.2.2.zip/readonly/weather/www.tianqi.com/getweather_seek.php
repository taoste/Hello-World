
<?php



$seek['china'] = array (

  '北京'=>array(
      '北京|beijing'=>array('海淀|haidian','北京朝阳区|chaoyang','顺义|shunyi','怀柔|huairou','通州|tongzhou','昌平|changping','延庆|yanqing','丰台|fengtai','石景山|shijingshan','大兴|daxing','房山|fangshan','密云|miyun','门头沟|mentougou','平谷|pinggu','东城|dongchengqu','西城|xichengqu',),
  ),

  '重庆'=>array(
      '重庆|chongqing'=>array('江北|jiangbei','渝中|yuzhongqu','大渡口|dadukou','沙坪坝|shapingba','九龙坡|jiulongpo','南岸|nananqu','开州|kaizhou','永川|yongchuan','合川|hechuan','南川|nanchuan','江津|jiangjin','万盛|wansheng','渝北|yubei','北碚|beibei','巴南|banan','长寿|changshou','黔江|qianjiang','万州|wanzhou','涪陵|fuling','开县|kaixian','城口|chengkou','云阳|yunyang','巫溪|wuxi','奉节|fengjie','巫山|wushan','潼南|tongnan','垫江|dianjiang','梁平|liangping','忠县|zhongxian','石柱|shizhu','大足|dazu','荣昌|rongchang','铜梁|tongliang','璧山|bishan','丰都|fengdu','武隆|wulong','彭水|pengshui','綦江|qijiang','酉阳|youyang','秀山|xiushan',),
  ),

  '上海'=>array(
      '上海|shanghai'=>array('徐汇|xuhui','静安|jinganqu','杨浦|yangpuqu','闵行|minhang','宝山|baoshan','嘉定|jiading','南汇|nanhui','金山|jinshan','青浦|qingpu','松江|songjiang','奉贤|fengxian','崇明|chongming','徐家汇|xujiahui','浦东|pudong','长宁|changningqu','虹口|hongkou1','黄浦|huangpu1',),
  ),

  '天津'=>array(
      '天津|tianjin'=>array('武清|wuqing','宝坻|baodi','东丽|dongli','西青|xiqing','北辰|beichen','宁河|ninghe','汉沽|hangu','静海|jinghai','津南|jinnan','塘沽|tanggu','大港|dagang','蓟州|tianjinjizhou','红桥|hongqiaoqu','河西|hexiqu','河东|hedongqu','河北|hebeiqu','和平|hepingqu','南开|nankaiqu','滨海|binhaixinqu',),
  ),

  '安徽'=>array(
      '合肥|hefei'=>array('长丰|changfeng','肥东|feidong','肥西|feixi','庐阳|luyang','居巢|juchaoqu','瑶海|yaohai','包河|baohequ','蜀山|shushanqu',),
      '安庆|anqing'=>array('枞阳|zongyang','太湖|taihu','潜山|qianshan','怀宁|huaining','宿松|susong','望江|wangjiang','岳西|yuexi','桐城|tongcheng1','迎江|yingjiangqu','宜秀|yixiuqu','大观|daguanqu',),
      '蚌埠|bengbu'=>array('怀远|huaiyuan','固镇|guzhen','五河|wuhe','龙子湖|longzihu','禹会|yuhuiqu','淮上|huaishangqu','蚌山|bengshanqu',),
      '亳州|bozhou2'=>array('涡阳|guoyang','利辛|lixin','蒙城|mengcheng','谯城|qiaochengqu',),
      '巢湖|chaohu'=>array('庐江|lujiang','无为|wuwei1','含山|hanshan','和县|hexian',),
      '池州|chizhou'=>array('东至|dongzhi','青阳|qingyang1','九华山|jiuhuashan','石台|shitai','贵池|guichiqu',),
      '滁州|chuzhou1'=>array('凤阳|fengyang','明光|mingguang','定远|dingyuan','全椒|quanjiao','来安|laian','天长|tianchang','琅琊|langyaqu','南谯|nanqiaoqu',),
      '阜阳|fuyang1'=>array('阜南|funan','颍上|yingshang','临泉|linquan','界首|jieshou','太和|taihe','颍州|yingzhouqu','颍泉|yingquanqu','颍东|yingdongqu',),
      '淮北|huaibei'=>array('濉溪|suixi','烈山|lieshan','杜集|dujiqu','相山|xiangshanqu',),
      '淮南|huainan'=>array('凤台|fengtai1','潘集|panji','大通|datongqu','谢家集|xiejiajiqu','田家庵|tianjiaanqu','八公山|bagong-mountainqu',),
      '黄山|huangshan'=>array('黄山区|huangshanqu','屯溪|tunxi','祁门|qimen','黟县|yixian2','歙县|shexian2','休宁|xiuning','黄山风景|huangshanfengjingqu','徽州|huizhouqu',),
      '六安|luan'=>array('霍邱|huoqiu','寿县|shouxian','叶集|yejiqu','金寨|jinzhai','霍山|huoshan','舒城|shucheng','裕安|yuan','金安|jinanqu',),
      '马鞍山|maanshan'=>array('当涂|dangtu','雨山|yushanqu','金家庄|jinjiazhuangqu','花山|huashanqu','博望|bowang',),
      '宿州|suzhou1'=>array('砀山|dangshan','灵璧|lingbi','泗县|sixian','萧县|xiaoxian','埇桥|yongqiaoqu',),
      '铜陵|tongling'=>array('铜官山|tongguanshanqu','狮子山|shizishanqu','铜陵|tonglingjiaoqu','铜官|tongguanqu','义安|yianqu',),
      '芜湖|wuhu'=>array('繁昌|fanchang','芜湖县|wuhuxian','南陵|nanling','鸠江|jiujiangqu','镜湖|jinghuqu','弋江|yijiangqu','三山|sanshanqu',),
      '宣城|xuancheng'=>array('泾县|jingxian1','旌德|jingde','宁国|ningguo','绩溪|jixi1','广德|guangde','郎溪|langxi','宣州|xuanzhouqu',),
  ),

  '福建'=>array(
      '福州|fuzhou'=>array('闽清|minqing','闽侯|minhou','罗源|luoyuan','连江|lianjiang','永泰|yongtai','平潭|pingtan','长乐|changle1','福清|fuqing','晋安|jinan1','仓山|cangshanqu','台江区|taijiangqu','马尾|maweiqu',),
      '钓鱼岛|diaoyudao'=>array(),
      '龙岩|longyan'=>array('长汀|changting','连城|liancheng','武平|wuping','上杭|shanghang','永定|yongding','漳平|zhangping','新罗|xinluoqu',),
      '南平|nanping'=>array('顺昌|shunchang','光泽|guangze','邵武|shaowu','武夷山|wuyishan','浦城|pucheng1','建阳|jianyang','松溪|songxi','政和|zhenghe','建瓯|jianou','延平|yanping',),
      '宁德|ningde'=>array('古田|gutian','霞浦|xiapu','寿宁|shouning','周宁|zhouning','福安|fuan','柘荣|zherong','福鼎|fuding','屏南|pingnan','蕉城|jiaochengqu',),
      '莆田|putian'=>array('仙游|xianyou','秀屿港|xiuyugang','涵江|hanjiang','秀屿|xiuyu','荔城|licheng1','城厢|chengxiang',),
      '泉州|quanzhou'=>array('安溪|anxi','永春|yongchun','德化|dehua','南安|nanan','崇武|chongwu','惠安|huian','晋江|jinjiang','石狮|shishi','鲤城|lichengqu','丰泽|fengzequ','泉港|quangangqu','洛江|luojiangqu1','金门|jinmen',),
      '三明|sanming'=>array('宁化|ninghua','清流|qingliu','泰宁|taining','将乐|jiangle','建宁|jianning','明溪|mingxi','沙县|shaxian1','尤溪|youxi','永安|yongan','大田|datian','三元|sanyuanqu','梅列|meiliequ',),
      '厦门|xiamen'=>array('同安|tongan','集美|jimeiqu','湖里|huli','海沧|haicangqu','思明|simingqu','翔安|xianganqu',),
      '漳州|zhangzhou'=>array('长泰|changtai','南靖|nanjing2','平和|pinghe','龙海|longhai','漳浦|zhangpu','诏安|zhaoan','东山|dongshan','云霄|yunxiao','华安|huaan','龙文|longwen','芗城|zhangzhouxiangcheng',),
  ),

  '甘肃'=>array(
      '兰州|lanzhou'=>array('皋兰|gaolan','永登|yongdeng','榆中|yuzhong','城关|chengguan','七里河|qilihe','西固|xiguqu','安宁|anningqu','红古|honggu',),
      '白银|baiyin'=>array('靖远|jingyuan','会宁|huining','平川|pingchuan','景泰|jingtai','白银|baiyinqu',),
      '定西|dingxi'=>array('通渭|tongwei','陇西|longxi','渭源|weiyuan','临洮|lintao','漳县|zhangxian','岷县|minxian','安定|anding',),
      '甘南州|gannan'=>array('合作|hezuo','临潭|lintan','卓尼|zhuoni','舟曲|zhouqu','迭部|diebu','玛曲|maqu','碌曲|luqu','夏河|xiahe',),
      '嘉峪关|jiayuguan'=>array(),
      '金昌|jinchang'=>array('永昌|yongchang','金川|jinchuanqu',),
      '酒泉|jiuquan'=>array('金塔|jinta','阿克塞|akesai','瓜州|guazhou','肃北|subei','玉门|yumen','敦煌|dunhuang','肃州|suzhouqu',),
      '临夏州|linxia'=>array('康乐|kangle','永靖|yongjing','广河|guanghe','和政|hezheng','东乡|dongxiang','积石山|jishishan','临夏|linxiaxian',),
      '陇南|longnan1'=>array('武都|wudu','成县|chengxian','文县|wenxian','宕昌|dangchang','康县|kangxian','西和|xihe','礼县|lixian1','徽县|huixian','两当|liangdang',),
      '平凉|pingliang'=>array('泾川|jingchuan','灵台|lingtai','崇信|chongxin','华亭|huating','庄浪|zhuanglang','静宁|jingning','崆峒|kongtong',),
      '庆阳|qingyang'=>array('西峰|xifeng1','环县|huanxian','华池|huachi','合水|heshui','正宁|zhengning','宁县|ningxian','镇原|zhenyuan','庆城|qingcheng',),
      '天水|tianshui'=>array('清水|qingshui','秦安|qinan','甘谷|gangu','武山|wushan1','张家川|zhangjiachuan','麦积|maiji','秦州|qinzhouqu',),
      '武威|wuwei'=>array('民勤|minqin','古浪|gulang','天祝|tianzhu','凉州|liangzhouqu',),
      '张掖|zhangye'=>array('肃南|sunan','民乐|minle','临泽|linze','高台|gaotai','山丹|shandan','甘州|ganzhouqu',),
  ),

  '广东'=>array(
      '广州|guangzhou'=>array('番禺|panyu','从化|conghua','增城|zengcheng','花都|huadu','萝岗|luogang','荔湾|liwan','越秀|yuexiuqu','黄埔|huangpuqu','海珠|haizhuqu','天河|tianhequ','南沙|nanshaqu','贵阳白云|guiyangbaiyun',),
      '潮州|chaozhou'=>array('饶平|raoping','潮安|chaoan','湘桥|xiangqiaoqu',),
      '东莞|dongguan'=>array(),
      '佛山|foshan'=>array('顺德|shunde','三水|sanshui','南海|nanhai','高明|gaoming','禅城|chanchengqu',),
      '河源|heyuan'=>array('紫金|zijin','连平|lianping','和平|heping','龙川|longchuan','东源|dongyuan','源城|yuanchengqu',),
      '惠州|huizhou'=>array('博罗|boluo','惠阳|huiyang','惠东|huidongxian','龙门|longmen','惠城|huichengqu',),
      '江门|jiangmen'=>array('开平|kaiping','新会|xinhui','恩平|enping','台山|taishan','蓬江|pengjiang','鹤山|heshan','江海|jianghai',),
      '揭阳|jieyang'=>array('揭西|jiexi','普宁|puning','惠来|huilai','揭东|jiedong','榕城|rongchengqu',),
      '茂名|maoming'=>array('高州|gaozhou','化州|huazhou','电白|dianbai','信宜|xinyishi','茂港|maogang','茂南|maonanqu',),
      '梅州|meizhou'=>array('兴宁|xingningshi','蕉岭|jiaoling','大埔|dabu','丰顺|fengshun','平远|pingyuanxian','五华|wuhua','梅县|meixian1','梅江|meijiangqu',),
      '清远|qingyuan3'=>array('连南|liannan','连州|lianzhou','连山|lianshan','阳山|yangshan','佛冈|fogang','英德|yingde','清新|qingxin','清城|qingchengqu',),
      '汕头|shantou'=>array('潮阳|chaoyang2','澄海|chenghai','南澳|nanao','龙湖|longhu','金平|jinpingqu','濠江|haojiangqu','潮南|chaonanqu',),
      '汕尾|shanwei'=>array('海丰|haifeng','陆丰|lufeng','陆河|luhe','城区|chengqu',),
      '韶关|shaoguan'=>array('乳源|ruyuan','始兴|shixing','翁源|wengyuan','乐昌|lechang','仁化|renhua','南雄|nanxiong','新丰|xinfengxian','曲江|qujiang','浈江|zhenjiang1','武江|wujiang1',),
      '深圳|shenzhen'=>array('罗湖|luohu','龙岗|longgang','盐田|yantianqu','南山|nanshanqu','福田|futianqu','宝安|baoanqu',),
      '阳江|yangjiang'=>array('阳春|yangchun','阳东|yangdong','阳西|yangxi','江城|jiangchengqu',),
      '云浮|yunfu'=>array('罗定|luoding','新兴|xinxing','郁南|yunan','云安|yunan1','云城|yunchengqu',),
      '湛江|zhanjiang'=>array('吴川|wuchuanshi','雷州|leizhou','徐闻|xuwen','廉江|lianjiangshi','赤坎|chikan','遂溪|suixixian','坡头|potou','霞山|xiashan','麻章|mazhang',),
      '肇庆|zhaoqing'=>array('广宁|guangning','四会|sihui','德庆|deqingxian','怀集|huaiji','封开|fengkai','高要|gaoyao','端州|duanzhouqu','鼎湖|dinghuqu',),
      '中山|zhongshan'=>array(),
      '珠海|zhuhai'=>array('斗门|doumen','金湾|jinwan','香洲|xiangzhouqu',),
  ),

  '广西'=>array(
      '南宁|nanning'=>array('兴宁|xingning','邕宁|yongningqu','横县|hengxian','隆安|longanxian','马山|mashan','上林|shanglinxian','武鸣|wumingqu','宾阳|binyangxian','青秀|qingxiu','西乡塘|xixiangtang','良庆|liangqing','江南|jiangnan',),
      '百色|baise'=>array('那坡|napoxian','田阳|tianyangxian','德保|debaoxian','靖西|jingxishi','田东|tiandongxian','平果|pingguoxian','隆林|longlin','西林|xilinxian','乐业|leyexian','凌云|lingyunxian','田林|tianlinxian','右江|youjiang','隆林各族|longlinqu',),
      '北海|beihai'=>array('合浦|hepu','涠洲岛|weizhoudao','银海|yinhai','铁山港|tieshangang',),
      '崇左|chongzuo'=>array('天等|tiandengxian','龙州|longzhouxian','凭祥|pingxiangshi','大新|daxinxian','扶绥|fusuixian','宁明|ningmingxian','江州|jiangzhou','江州|jaingzhou',),
      '防城港|fangchenggang'=>array('上思|shangsixian','东兴|dongxingshi','防城|fangchengqu','港口|gangkou',),
      '贵港|guigang'=>array('桂平|guipingshi','平南|pingnanxian','港北|gangbei','港南|gangnan','覃塘|tantangqu',),
      '桂林|guilin'=>array('龙胜|longsheng','永福|yongfu','临桂|linguiqu','兴安|xinganxian','灵川|lingchuanxian','全州|quanzhouxian','灌阳|guanyangxian','阳朔|yangshuoxian','恭城|gongcheng','平乐|pinglexian','荔浦|lipuxian','资源|ziyuanxian','秀峰|xiufeng','叠彩|diecai','七星|qixing','雁山|yanshanqu','龙胜各族|longshenggezuzizhixian','恭城瑶族|gongchengqu','桂林象山|guilinxiangshan',),
      '河池|hechi'=>array('天峨|tianexian','东兰|donglanxian','巴马|bama','环江|huanjiang','罗城|luocheng','宜州|yizhoushi','凤山|fengshanxian','南丹|nandanxian','都安|andu','大化|dahua','金城江|jinchengjiang',),
      '贺州|hezhou'=>array('昭平|zhaopingxian','富川|fuchuan','钟山|zhongshanxian','八步|babu','平桂区|pingguiqu','昭平区|zhaopingqu','都安瑶族|duan','平桂|pinggui',),
      '来宾|laibin'=>array('忻城|xichengxian','金秀|jinxiuxian','象州|xiangzhouxian','武宣|wuxuanxian','合山|heshanshi','兴宾|xingbin',),
      '柳州|liuzhou'=>array('柳城|liuchengxian','鹿寨|luzhaixian','柳江|liujiangqu','融安|ronganxian','融水|rongshuixian','三江|sanjiang','城中|chengzhongqu','鱼峰|yufengqu','柳南|liunanqu','柳北|liubeiqu',),
      '钦州|qinzhou'=>array('浦北|pubeixian','灵山|lingshanxian','钦南|qinnan','钦北|qinbei','浦北|pubei',),
      '梧州|wuzhou'=>array('藤县|tengxian','苍梧|cangwuxian','蒙山|mengshanxian','岑溪|cenxishi','长洲|changzhouqu','万秀|wanxiuqu','龙圩|longweiqu',),
      '玉林|yulin1'=>array('博白|bobaixian','北流|beiliushi','陆川|luchuanxian','兴业|xingyexian','玉州|yuzhouqu','福绵|fumian',),
  ),

  '贵州'=>array(
      '贵阳|guiyang1'=>array('白云|baiyun','花溪|huaxi','乌当|wudang','息烽|xifeng2','开阳|kaiyang','修文|xiuwen','清镇|qingzhen','小河|xiaohe','云岩|yunyan','南明|nanming','观山湖|guanshanhu',),
      '安顺|anshun'=>array('普定|puding','镇宁|zhenning','平坝|pingba','紫云|ziyun','关岭|guanling','西秀|xixiuqu',),
      '毕节|bijie'=>array('赫章|hezhang','金沙|jinsha','威宁|weining','大方|dafang','纳雍|nayong','织金|zhijin','黔西|qianxi1','七星关|qixingguan',),
      '六盘水|liupanshui'=>array('水城|shuicheng','六枝|liuzhi','盘县|panxian','钟山区|zhongshanqu',),
      '黔东南|qiandongnan'=>array('凯里|kaili','岑巩|cengong','施秉|shibing','镇远|zhenyuan1','黄平|huangping','麻江|majiang','丹寨|danzhai','三穗|sansui','台江|taijiang','剑河|jianhe','雷山|leishan','黎平|liping','天柱|tianzhu1','锦屏|jinping','榕江|rongjiang','从江|congjiang',),
      '黔南州|qiannan'=>array('都匀|duyun','贵定|guiding','瓮安|wengan','长顺|changshun','福泉|fuquan','惠水|huishui','龙里|longli','罗甸|luodian','平塘|pingtang','独山|dushan','三都|sandu','荔波|libo',),
      '黔西南|qianxinan'=>array('兴义|xingyi1','晴隆|qinglong1','兴仁|xingren','贞丰|zhenfeng','望谟|wangmo','安龙|anlong','册亨|ceheng','普安|puan',),
      '铜仁|tongren'=>array('江口|jiangkou','玉屏|yuping','万山|wanshan','思南|sinan','印江|yinjiang','石阡|shiqian','沿河|yanhe','德江|dejiang','松桃|songtao',),
      '遵义|zunyi'=>array('碧江|bijiangqu','仁怀|renhuai','绥阳|suiyang','湄潭|meitan','凤冈|fenggang','桐梓|tongzi','赤水|chishui','习水|xishui1','道真|daozhen','正安|zhengan','务川|wuchuan1','余庆|yuqing','汇川|huichuan','红花岗|honghuagang','播州|bozhouqu',),
  ),

  '海南'=>array(
      '海口|haikou'=>array('琼山|qiongshan','龙华|longhua1','秀英|xiuying','美兰|meilan','乐东黎族|ledong','临高|lingao','陵水|lingshui',),
      '白沙|baisha'=>array('保亭黎族苗族|baotinglizumiaozu','昌江|changjiang',),
      '澄迈|chengmai'=>array(),
      '儋州|danzhou'=>array('洋浦|yangpu',),
      '定安|dingan'=>array(),
      '东方|dongfang'=>array(),
      '南沙岛|nanshadao'=>array(),
      '琼海|qionghai'=>array('琼中|qiongzhong','三沙|sansha',),
      '三亚|sanya'=>array('海棠|haitangqu','吉阳|jiyangqu','天涯|tianyaqu','崖州|yazhouqu','屯昌|tunchang',),
      '万宁|wanning'=>array(),
      '文昌|wenchang'=>array(),
      '五指山|wuzhishan'=>array(),
      '西沙|xisha'=>array(),
  ),

  '河北'=>array(
      '石家庄|shijiazhuang'=>array('井陉|jingxing','正定|zhengding','栾城|luancheng','行唐|xingtang','灵寿|lingshou','高邑|gaoyi','深泽|shenze','赞皇|zanhuang','无极|wuji','平山|pingshan','元氏|yuanshi','赵县|zhaoxian','辛集|xinji','藁城|gaocheng','晋州|jinzhou2','新乐|xinle','鹿泉|luquan1','长安|changanqu','石家庄桥东|shijiazhuangqiaodongqu','桥西|qiaoxiqu','新华|xinhuaqu','井陉矿|jingxingkuangqu','裕华|yuhuaqu',),
      '保定|baoding'=>array('满城|mancheng','阜平|fuping','徐水|xushui','唐县|tangxian','高阳|gaoyang','容城|rongcheng','莲池|lianchi','涞源|laiyuan','望都|wangdu','安新|anxin','易县|yixian1','曲阳|quyang','蠡县|lixian','顺平|shunping','雄县|xiongxian','涿州|zhuozhou','定州|dingzhou','安国|anguo','高碑店|gaobeidian','涞水|laishui','定兴|dingxing','清苑|qingyuan1','博野|boye','竞秀|jingxiu','北市|beishiqu','南市|nanshiqu',),
      '沧州|cangzhou'=>array('青县|qingxian','东光|dongguang','海兴|haixing','盐山|yanshan','肃宁|suning','南皮|nanpi','吴桥|wuqiao','献县|xianxian','孟村|mengcun','泊头|botou','任丘|renqiu','黄骅|huanghua','河间|hejian','沧县|cangxian','沧州新华|cangzhouxinhuaqu','运河|yunhequ',),
      '承德|chengde'=>array('承德县|chengdexian','兴隆|xinglong','平泉|pingquan','滦平|luanping','隆化|longhua','丰宁|fengning','宽城满族|kuanchengmanzu','围场|weichang','双桥|shuangqiaoqu','双滦|shuangluanqu','鹰手营子矿|yingshouying',),
      '邯郸|handan'=>array('峰峰|fengfeng','临漳|linzhang','成安|chengan','大名|daming','涉县|shexian','磁县|cixian','肥乡|feixiang','永年|yongnian','邱县|qiuxian','鸡泽|jize','广平|guangping','馆陶|guantao','魏县|weixian','曲周|quzhou','武安|wuan','邯山|hanshanqu','丛台|congtaiqu','复兴|fuxingqu',),
      '衡水|hengshui'=>array('枣强|zaoqiang','武邑|wuyi','武强|wuqiang','饶阳|raoyang','安平|anping','故城|gucheng','景县|jingxian','阜城|fucheng','冀州|jizhou','深州|shenzhou','桃城|taochengqu',),
      '廊坊|langfang'=>array('固安|guan','永清|yongqing','香河|xianghe','大城|dacheng','文安|wenan','大厂|dachang','霸州|bazhou','三河|sanhe',),
      '秦皇岛|qinhuangdao'=>array('青龙|qinglong','昌黎|changli','抚宁|funing','卢龙|lulong','北戴河|beidaihe','海港|haigangqu','山海关|shanhaiguanqu',),
      '唐山|tangshan'=>array('丰南|fengnan','丰润|fengrun','滦县|luanxian','滦南|luannan','乐亭|laoting','迁西|qianxi','玉田|yutian','唐海|tanghai','遵化|zunhua','迁安|qianan1','曹妃甸|caofeidian','京唐港|jingtanggang','路南|lunan','古冶|guyequ','开平|kaipingqu','路北|lubei',),
      '邢台|xingtai'=>array('临城|lincheng','内丘|neiqiu','柏乡|baixiang','隆尧|longyao','南和|nanhe','宁晋|ningjin','巨鹿|julu','新河|xinhe','广宗|guangzong','平乡|pingxiang','威县|weixian1','清河|qinghe','临西|linxi1','南宫|nangong','沙河|shahe','任县|renxian','桥东|qiaodongqu','邢台桥西|xingtaiqiaoxiqu',),
      '张家口|zhangjiakou'=>array('宣化|xuanhua','张北|zhangbei','康保|kangbao','沽源|guyuan','尚义|shangyi','蔚县|yuxian1','阳原|yangyuan','怀安|huaian','万全|wanquan','怀来|huailai','涿鹿|zhuolu','赤城|chicheng','崇礼|chongli','张家口桥东|zhangjiakouqiaodong','张家口桥西|zhangjiakouqiaoxiqu','下花园|xiahuayuanqu',),
  ),

  '黑龙江'=>array(
      '哈尔滨|haerbin'=>array('双城|shuangcheng','呼兰|hulan','阿城|acheng','宾县|binxian','依兰|yilan','巴彦|bayan','通河|tonghe','方正|fangzheng','延寿|yanshou','尚志|shangzhi','五常|wuchang','木兰|mulan','道外|daowaiqu','道里|daoliqu','香坊|xiangfangqu','松北|songbeiqu','平房|pingfangqu','南岗|nangangqu',),
      '大庆|daqing'=>array('林甸|lindian','肇州|zhaozhou','肇源|zhaoyuan','杜尔伯特|duerbote','萨尔图|saertuqu','龙凤|longfengqu','让胡路|ranghuluqu','红岗|honggangqu','大庆大同|daqingdatong',),
      '大兴安岭|daxinganling'=>array('塔河|tahe','漠河|mohe','呼玛|huma','新林|xinlin','加格达奇|jiagedaqi',),
      '鹤岗|hegang'=>array('绥滨|suibin','萝北|luobei','南山|hegangnansanqu','向阳|hegangxiangyang','东山|dongshanqu','兴山|xingshanqu','兴安|xinganqu','工农|gongnongqu',),
      '黑河|heihe'=>array('嫩江|nenjiang','孙吴|sunwu','逊克|xunke','五大连池|wudalianchi','北安|beian','爱辉|aihui',),
      '佳木斯|jiamusi'=>array('汤原|tangyuan','抚远|fuyuan','桦川|huachuan','桦南|huanan','同江|tongjiang','富锦|fujin','向阳|xiangyangqu','前进|qianjinqu','东风|dongfengqu',),
      '鸡西|jixi'=>array('虎林|hulin','密山|mishan','鸡东|jidong','鸡冠|jiguanqu','恒山|hengshanqu','滴道|didaoqu','城子河|chengzihequ','麻山|mashanqu','梨树|lishuqu',),
      '牡丹江|mudanjiang'=>array('海林|hailin','穆棱|muling','林口|linkou','绥芬河|suifenhe','宁安|ningan','东宁|dongning','阳明|yangmingqu','爱民|aiminqu','东安|donganqu',),
      '齐齐哈尔|qiqihaer'=>array('讷河|nehe','龙江|longjiang','甘南|gannan1','富裕|fuyu','依安|yian','拜泉|baiquan','克山|keshan','克东|kedong','泰来|tailai','建华|jianhuaqu','富拉尔基|fularjiqu','昂昂溪|angangxiqu','铁锋|tiefengqu','碾子山|nianzishanqu','梅里斯达斡尔族|meilisidawoerzuqu','龙沙|longshaqv',),
      '七台河|qitaihe'=>array('勃利|boli','桃山|taoshanqu','新兴|xinxingqu','茄子河|qiezihequ',),
      '双鸭山|shuangyashan'=>array('集贤|jixian1','宝清|baoqing','饶河|raohe','友谊|youyi','尖山|jianshanqu','岭东|lingdongqu','四方台|sifangtaiqu',),
      '绥化|suihua'=>array('肇东|zhaodong','安达|anda','海伦|hailun','明水|mingshui','望奎|wangkui','兰西|lanxi','青冈|qinggang','庆安|qingan','绥棱|suiling','北林区|beilinqu',),
      '伊春|yichun'=>array('乌伊岭|wuyiling','五营|wuying','铁力|tieli','嘉荫|jiayin','南岔|nanchaqu','友好|youhaoqu','西林|xilinqu','翠峦|cuiluanqu','新青|xinqingqu','美溪|meixiqu','金山屯|jinshantunqu','乌马河|wumahequ','汤旺河|tangwanghequ','带岭|dailingqu','红星|hongxingqu','上甘岭|shangganlingqu','伊春区|yichunqu',),
  ),

  '河南'=>array(
      '郑州|zhengzhou'=>array('巩义|gongyi','荥阳|xingyang','登封|dengfeng','新密|xinmi','新郑|xinzheng','中牟|zhongmou','上街|shangjie','中原|zhongyuanqu','二七|erqiqu','管城回族|guanchengqu','金水|jinshuiqu','惠济|huijiqu',),
      '安阳|anyang'=>array('汤阴|tangyin','滑县|huaxian1','内黄|neihuang','林州|linzhou','文峰|wenfengqu','北关|beiguanqu','殷都|yinduqu','龙安|longanqu','安阳|anyangxian',),
      '鹤壁|hebi'=>array('浚县|xunxian','淇县|qixian2','鹤山|heshanqu1','山城|shanchengqu','淇滨|qibinqu',),
      '焦作|jiaozuo'=>array('修武|xiuwu','武陟|wuzhi','沁阳|qinyang','博爱|boai','温县|wenxian1','孟州|mengzhou','解放|jiefangqu','中站|zhongzhanqu','山阳|shanyangqu','马村|macunqu',),
      '济源|jiyuan'=>array(),
      '开封|kaifeng'=>array('杞县|qixian1','尉氏|weishi','通许|tongxu','兰考|lankao','龙亭|longting','顺河回族|shunhehuizu','开封鼓楼|kaifenggulouqu','禹王台|yuwangtaiqu','金明|jinmingqu','祥符|xiangfuqu',),
      '漯河|luohe'=>array('临颍|linying','舞阳|wuyang','源汇|yuanhuiqu','郾城|yanchengqu','召陵|shaolingqu',),
      '洛阳|luoyang'=>array('新安|xinan','孟津|mengjin','宜阳|yiyang','洛宁|luoning','伊川|yichuan1','嵩县|songxian','偃师|yanshi1','栾川|luanchuan','汝阳|ruyang','吉利|jili','洛龙|luolongqu','老城|laochengqu','西工|xigongqu','瀍河回族|chanhequ','涧西|jianxiqu',),
      '南阳|nanyang'=>array('南召|nanzhao','方城|fangcheng','社旗|sheqi','西峡|xixia','内乡|neixiang','镇平|zhenping1','淅川|xichuan','新野|xinye','唐河|tanghe','邓州|dengzhou','桐柏|tongbai','宛城|wanchengqu','卧龙|wolongqu',),
      '平顶山|pingdingshan'=>array('郏县|jiaxian1','宝丰|baofeng','汝州|ruzhou','叶县|yexian','舞钢|wugang','鲁山|lushan','石龙|shilong','卫东|weidongqu','湛河|zhanhequ','平顶新华|pingdingxinhua',),
      '濮阳|puyang'=>array('台前|taiqian','南乐|nanle','清丰|qingfeng','范县|fanxian','华龙|hualongqu','濮阳|puyangxian',),
      '三门峡|sanmenxia'=>array('灵宝|lingbao','渑池|mianchi','卢氏|lushi','义马|yima','陕县|shanxian1','湖滨|hubinqu','陕州|xiazhouqu',),
      '商丘|shangqiu'=>array('睢县|suixian','民权|minquan','虞城|yucheng1','柘城|zhecheng','宁陵|ningling','夏邑|xiayi','永城|yongcheng','梁园|liangyuanqu','睢阳|suiyangqo',),
      '新乡|xinxiang'=>array('获嘉|huojia','原阳|yuanyang','辉县|huixian1','卫辉|weihui','延津|yanjin','封丘|fengqiu','长垣|changyuan','红旗|hongqiqu','卫滨|weibinqu','凤泉|fengquanqu','牧野|muyequ','新乡县|xinxiangxian',),
      '信阳|xinyang'=>array('息县|xixian1','罗山|luoshan','光山|guangshan','新县|xinxian1','淮滨|huaibin','潢川|huangchuan','固始|gushi','商城|shangcheng','浉河|shihequ','平桥|pingqiaoqu',),
      '许昌|xuchang'=>array('鄢陵|yanling','襄城|xiangcheng','长葛|changge','禹州|yuzhou1','魏都|weidu','许昌|xuchangxian',),
      '周口|zhoukou'=>array('扶沟|fugou','太康|taikang','淮阳|huaiyang','西华|xihua','商水|shangshui','项城|xiangcheng1','郸城|dancheng','鹿邑|luyi','沈丘|shenqiu','川汇|chuanhuiqu',),
      '驻马店|zhumadian'=>array('西平|xiping','遂平|suiping','上蔡|shangcai','汝南|runan','泌阳|biyang','平舆|pingyu','新蔡|xincai','确山|queshan','正阳|zhengyang','驿城|yichengqu',),
  ),

  '湖北'=>array(
      '武汉|wuhan'=>array('蔡甸|caidian','黄陂|huangpi','新洲|xinzhou1','江夏|jiangxia','东西湖|dongxihu','江汉|jianghanqu','江岸|jianganqu','洪山|hongshan','汉阳|hanyangqu','汉南|hannanqu','武昌|wuchangqu','硚口|qiaokouqu',),
      '恩施州|enshi'=>array('恩施|enshi','利川|lichuan','建始|jianshi','咸丰|xianfeng','宣恩|xuanen','鹤峰|hefeng1','来凤|laifeng','巴东|badong',),
      '鄂州|ezhou'=>array('梁子湖|liangzihu','鄂城|echengqu',),
      '黄冈|huanggang'=>array('红安|hongan','麻城|macheng','罗田|luotian','英山|yingshan','浠水|xishui','蕲春|qichun','黄梅|huangmei','武穴|wuxue','团风|tuanfeng','黄州|huangzhouqu',),
      '黄石|huangshi'=>array('大冶|daye','阳新|yangxin1','铁山|tieshan','下陆|xialu','西塞山|xisaishan','黄石港|huangshigangqu',),
      '荆门|jingmen'=>array('钟祥|zhongxiang','京山|jingshan','掇刀|duodao','沙洋|shayang','东宝|dongbaoqu',),
      '荆州|jingzhou'=>array('江陵|jiangling','公安|gongan','石首|shishou','监利|jianli','洪湖|honghu','松滋|songzi','华容区|huarongqu','沙市|shashi','荆州|jingzhouqu',),
      '潜江|qianjiang1'=>array('潜江|qianjiang1',),
      '神农架|shennongjia'=>array('神农架|shennongjia',),
      '十堰|shiyan'=>array('竹溪|zhuxi','郧西|yunxi','郧阳|yunyangqu','竹山|zhushan','房县|fangxian','丹江口|danjiangkou','茅箭|maojian','张湾|zhangwan',),
      '随州|suizhou'=>array('广水|guangshui','曾都|zengduqu','随县|suizhousuixian',),
      '天门|tianmen'=>array('天门|tianmen',),
      '襄阳|xiangyang'=>array('襄州|xiangzhou1','保康|baokang','南漳|nanzhang','宜城|yicheng2','老河口|laohekou','谷城|gucheng1','枣阳|zaoyang','樊城|fanchengqu','襄阳襄城|xiangyangxiangcheng',),
      '咸宁|xianning'=>array('赤壁|chibi','嘉鱼|jiayu','崇阳|chongyang','通城|tongcheng','通山|tongshan','咸安|xianan',),
      '仙桃|xiantao'=>array('仙桃|xiantao',),
      '孝感|xiaogan'=>array('安陆|anlu','云梦|yunmeng','大悟|dawu','应城|yingcheng','汉川|hanchuan','孝昌|xiaochang','孝南|xiaonanqu',),
      '宜昌|yichang'=>array('远安|yuanan','秭归|zigui','兴山|xingshan','五峰|wufeng','当阳|dangyang','长阳|changyang','宜都|yidu','枝江|zhijiang','三峡|sanxia','夷陵|yiling','点军|dianjunqu','猇亭|xiaoting','西陵|xilingqu','伍家岗|wujiagang',),
  ),

  '湖南'=>array(
      '长沙|changsha'=>array('宁乡|ningxiang','浏阳|liuyang','马坡岭|mapoling','望城|wangcheng','芙蓉|furongqu','天心|tianxinqu','岳麓|yueluqu','开福|kaifuqu','雨花|changshayuhua','长沙县|changshaxian',),
      '常德|changde'=>array('安乡|anxiang','桃源|taoyuan','汉寿|hanshou','澧县|lixian2','临澧|linli','石门|shimen','津市|jinshi','武陵|wulingqu','鼎城|dingchengqu',),
      '郴州|chenzhou'=>array('桂阳|guiyang','嘉禾|jiahe','宜章|yizhang','临武|linwu','资兴|zixing','汝城|rucheng','安仁|anren','永兴|yongxing','桂东|guidong','苏仙|suxian','北湖|beihuqu',),
      '衡阳|hengyang'=>array('衡山|hengshan1','衡东|hengdong','祁东|qidong1','衡阳县|hengyangxian','常宁|changning','衡南|hengnan','耒阳|leiyang','南岳|nanyue','珠晖|zhuhuiqu','雁峰|yanfengqu','石鼓|shiguqu','蒸湘|zhengxiangqu',),
      '怀化|huaihua'=>array('沅陵|yuanling','辰溪|chenxi','靖州|jingzhou1','会同|huitong','通道|tongdao','麻阳|mayang','新晃|xinhuang','芷江|zhijiang1','溆浦|xupu','中方|zhongfang','洪江|hongjiang','鹤城|hecheng',),
      '娄底|loudi'=>array('双峰|shuangfeng','冷水江|lengshuijiang','新化|xinhua','涟源|lianyuan','娄星|louxing',),
      '邵阳|shaoyang'=>array('隆回|longhui','洞口|dongkou','新邵|xinshao','邵东|shaodong','绥宁|suining','新宁|xinning','武冈|wugang1','城步|chengbu','邵阳县|shaoyangxian','双清|shuangqingqu','大祥|daxiangqu','北塔|beitaqu',),
      '湘潭|xiangtan'=>array('韶山|shaoshan','湘乡|xiangxiang','雨湖|yuhuqu','岳塘|yuetangqu','湘潭县|xiangtanxian',),
      '湘西|xiangxi'=>array('吉首|jishou','保靖|baojing','永顺|yongshun','古丈|guzhang','凤凰|fenghuang','泸溪|luxi','龙山|longshan','花垣|huayuan',),
      '益阳|yiyang1'=>array('赫山|heshanqu','南县|nanxian','桃江|taojiang','安化|anhua','沅江|yuanjiang','资阳区|ziyangqu',),
      '永州|yongzhou'=>array('祁阳|qiyang','东安|dongan','双牌|shuangpai','道县|daoxian','宁远|ningyuan','江永|jiangyong','蓝山|lanshan','新田|xintian','江华|jianghua','冷水滩|lengshuitan','零陵|lingling',),
      '岳阳|yueyang'=>array('华容|huarong','湘阴|xiangyin','汨罗|miluo','平江|pingjiang','临湘|linxiang','岳阳楼|yueyanglouqu','云溪|yunxiqu','君山|junshanqu','岳阳县|yueyangxian',),
      '张家界|zhangjiajie'=>array('桑植|sangzhi','慈利|cili','武陵源|wulingyuan','张家界永定|yongdingqu',),
      '株洲|zhuzhou'=>array('攸县|youxian','醴陵|liling','茶陵|chaling','炎陵|yanling1','荷塘|hetangqu','芦淞|lusongqu','石峰|shifengqu','天元|tianyuanqu','株洲县|zhuzhouxian',),
  ),

  '江苏'=>array(
      '南京|nanjing'=>array('溧水|lishui2','高淳|gaochun','江宁|jiangning','六合|luhe1','江浦|jiangpu','浦口|pukou','鼓楼|nanjinggulou','栖霞|qixiaqu','玄武|xuanwuqu','白下|baixiaqu','秦淮|qinhuaiqu','建邺|jianyequ','下关|xiaguanqu','雨花台|yuhuataiqu',),
      '常州|changzhou'=>array('溧阳|liyang','金坛|jintan','武进|wujin','天宁|tianningqu','钟楼|zhonglouqu','戚墅堰|qishuyanqu','新北|changzhouxinbeiqu',),
      '淮安|huaian1'=>array('金湖|jinhu','盱眙|xuyi','洪泽|hongze','涟水|lianshui','淮阴|huaiyinqu','楚州|chuzhou','清浦|qingpuqu','清江浦|qingjiangpu','淮安区|huaianqu',),
      '连云港|lianyungang'=>array('东海|donghai','赣榆|ganyu','灌云|guanyun','灌南|guannan','连云|lianyun','新浦|xinpu','连云港海州|lianyunganghaizhou',),
      '南通|nantong'=>array('海安|haian','如皋|rugao','如东|rudong','启东|qidong','海门|haimen','通州|tongzhou1','崇川|chongchuanqu','港闸|gangzhaqu',),
      '宿迁|suqian'=>array('沭阳|shuyang','泗阳|siyang','泗洪|sihong','宿豫|suyu','宿城|suchengqu',),
      '苏州|suzhou'=>array('常熟|changshu','张家港|zhangjiagang','昆山|kunshan','吴中|wuzhong1','吴江|wujiang','太仓|taicang','沧浪|canglangqu','平江|pingjiangqu','金阊|jinchangqu','虎丘|huqiuqu','相城|xiangchengqu','姑苏|gusuqu',),
      '泰州|taizhou2'=>array('兴化|xinghua','泰兴|taixing','姜堰|jiangyan','靖江|jingjiang','海陵|hailingqu','高港|gaogangqu',),
      '无锡|wuxi'=>array('江阴|jiangyin','宜兴|yixing','锡山|xishan','崇安|chonganqu','南长|nanchangqu','北塘|beitangqu','惠山|huishanqu','滨湖|binhuqu','梁溪|liangxiqu','新吴|xinwuqu',),
      '徐州|xuzhou'=>array('铜山|tongshan1','丰县|fengxian2','沛县|peixian','邳州|pizhou','睢宁|suining2','新沂|xinyi','徐州鼓楼|gulouqu','云龙|yunlongqu','贾汪|jiawangqu','泉山|quanshanqu',),
      '盐城|yancheng'=>array('响水|xiangshui','滨海|binhai','阜宁|funing1','射阳|sheyang','建湖|jianhu','东台|dongtai','大丰|dafeng','盐都|yandu','亭湖|tinghuqu',),
      '扬州|yangzhou'=>array('宝应|baoying','仪征|yizheng','高邮|gaoyou','江都|jiangdu','邗江|hanjiang1','广陵|guanglingqu','维扬|weiyang',),
      '镇江|zhenjiang'=>array('丹阳|danyang','扬中|yangzhong','句容|jurong','丹徒|dantu','京口|jingkou','润州|runzhouqu',),
  ),

  '江西'=>array(
      '南昌|nanchang'=>array('新建|xinjian','南昌县|nanchangxian','安义|anyi','进贤|jinxian','东湖|donghuqu','青云谱|qingyunpuqu','湾里|wanliqu','青山湖|qingshanhuqu',),
      '抚州|fuzhou1'=>array('广昌|guangchang','乐安|lean','崇仁|chongren','金溪|jinxi','资溪|zixi','宜黄|yihuang','南城|nancheng','南丰|nanfeng','黎川|lichuan1','东乡族|dongxiang1','临川|linchuanqu',),
      '赣州|ganzhou'=>array('崇义|chongyi','上犹|shangyou','南康|nankang','大余|dayu','信丰|xinfeng','宁都|ningdu','石城|shicheng','瑞金|ruijin','于都|yudu','会昌|huichang','安远|anyuan','全南|quannan','龙南|longnan','定南|dingnan','寻乌|xunwu','兴国|xingguo','赣县|ganxian','章贡|zhanggongqu',),
      '吉安|jian1'=>array('吉安县|jianxian','吉水|jishui','新干|xingan','峡江|xiajiang','永丰|yongfeng','永新|yongxin','井冈山|jinggangshan','万安|wanan','遂川|suichuan','泰和|taihe1','安福|anfu','青原|qingyuanqu','吉州|jizhouqu',),
      '景德镇|jingdezhen'=>array('乐平|leping','浮梁|fuliang','昌江区|changjiangqu','珠山|zhushanqu',),
      '九江|jiujiang'=>array('瑞昌|ruichang','庐山|lushan1','武宁|wuning','德安|dean','永修|yongxiu','湖口|hukou','彭泽|pengze','星子|xingzi','都昌|duchang','修水|xiushui','共青城|gongqingcheng','浔阳|xunyangqu','九江县|jiujiangxian','濂溪|lianxi',),
      '萍乡|pingxiang1'=>array('莲花|lianhua','上栗|shangli','安源|anyuanqu','芦溪|luxi3','湘东|xiangdong',),
      '上饶|shangrao'=>array('鄱阳|poyang','婺源|wuyuan1','余干|yugan','万年|wannian','德兴|dexing','上饶县|shangraoxian','弋阳|yiyang2','横峰|hengfeng','铅山|yanshan2','玉山|yushan','广丰|guangfeng','信州|xinzhouqu',),
      '新余|xinyu'=>array('分宜|fenyi','渝水|yushuiqu',),
      '宜春|yichun1'=>array('铜鼓|tonggu','宜丰|yifeng','万载|wanzai','上高|shanggao','靖安|jingan','奉新|fengxin','高安|gaoan','樟树|zhangshu','丰城|fengcheng1','袁州区|yuanzhouqu',),
      '鹰潭|yingtan'=>array('余江|yujiang','贵溪|guixi','月湖|yuehuqu',),
  ),

  '吉林'=>array(
      '长春|changchun'=>array('农安|nongan','德惠|dehui','九台|jiutai','榆树|yushu','双阳|shuangyang','宽城|kuanchengqu','二道|erdaoqu','南关|nanguanqu','绿园|luyuanqu','长春朝阳区|chaoyangqu',),
      '白城|baicheng'=>array('洮南|taonan','大安|daan','镇赉|zhenlai','通榆|tongyu','洮北|taobeiqu',),
      '白山|baishan'=>array('靖宇|jingyu','临江|linjiang','东岗|donggang','长白|changbai','抚松|fusong','江源|jiangyuan','八道江|baishanqu','浑江|hunjiangqu',),
      '吉林|jilin'=>array('舒兰|shulan','永吉|yongji','蛟河|jiaohe','磐石|panshi','桦甸|huadian','龙潭|longtan','丰满|fengmanqu','船营|chuanyingqu','昌邑|changyiqu',),
      '辽源|liaoyuan'=>array('东丰|dongfeng','东辽|dongliao','西安区|xianqu','龙山|longshanqu',),
      '四平|siping'=>array('双辽|shuangliao','梨树|lishu','公主岭|gongzhuling','伊通|yitong','铁西|tiexiqu','铁东|tiedong',),
      '松原|songyuan'=>array('乾安|qianan','前郭|qianguo','长岭|changling','扶余|fuyu1','宁江|ningjiangqu',),
      '通化|tonghua'=>array('梅河口|meihekou','柳河|liuhe','辉南|huinan','集安|jian','通化县|tonghuaxian','东昌|dongchangqu','二道江|erdaojiang',),
      '延边朝鲜族|yanbian'=>array('延吉|yanji','敦化|dunhua','安图|antu','汪清|wangqing','和龙|helong','龙井|longjing','珲春|hunchun','图们|tumen',),
  ),

  '辽宁'=>array(
      '沈阳|shenyang'=>array('辽中|liaozhong','康平|kangping','法库|faku','新民|xinmin','沈阳铁西|shenyangtiexiqu','沈河|shenhequ','大东|dadongqu','皇姑|huangguqu','苏家屯|sujiatunqu','浑南|hunnan','沈北|shenbeixinqu','于洪|yuhongqu',),
      '鞍山|anshan'=>array('台安|taian','岫岩|xiuyan','铁东|anshantiedong','鞍山铁西|anshantiexiqu','立山|lishanqu','千山|qianshanqu',),
      '本溪|benxi'=>array('明山|mingshanqu','桓仁|huanren','平山|pingshanqu','溪湖区|xihuqu','南芬|nanfenqu','本溪满族|benximanzu',),
      '朝阳|chaoyang1'=>array('建平|jianpingxian','双塔|shuangtaqu','龙城|longchengqu','朝阳县|chaoyangxian','喀喇沁左翼|kazuo',),
      '大连|dalian'=>array('金州|jinzhou','普兰店|pulandian','旅顺|lvshun','长海|changhai','中山区|zhongshanqu1','西岗|xigangqu','沙河口|shahekouqu','甘井子|ganjingziqu','旅顺口|lushunkouqu',),
      '丹东|dandong'=>array('宽甸|kuandian','元宝|yuanbaoqu','振兴|zhenxingqu','振安|zhenanqu',),
      '抚顺|fushun'=>array('新宾|xinbin','清原|qingyuan','抚顺县|fushunxian','新抚|xinfuqu1','望花|wanghuaqu','顺城|shunchengqu',),
      '阜新|fuxin'=>array('彰武|zhangwu','海州|haizhouqu','新邱|xinqiuqu','太平|taipingqu','清河门|qinghemenqu','细河|xihequ','东洲|dongzhouqu','阜新蒙古族|fuxinmengguzu',),
      '葫芦岛|huludao'=>array('建昌|jianchang','绥中|suizhong','连山|lianshanqu','龙港|longgangqu','南票|nanpiaoqu',),
      '锦州|jinzhou1'=>array('义县|yixian','黑山|heishan','古塔|gutaqu','凌河|linghe','太和|taihequ',),
      '辽阳|liaoyang'=>array('辽阳县|liaoyangxian','弓长岭|gongchangling','白塔|baita','文圣|wensheng','宏伟|hongwei','太子河|taizihe',),
      '盘锦|panjin'=>array('大洼|dawa','盘山|panshan','双台子|shuangtaiziqu','兴隆台|xinglongtaiqu',),
      '铁岭|tieling'=>array('昌图|changtu','西丰|xifeng','银州区|yinzhouqu','清河|qinghequ','铁岭县|tielingxian',),
      '营口|yingkou'=>array('站前|zhanqianqu','西市|xishiqu','鲅鱼圈|bayuquanqu','老边|laobianqu',),
  ),

  '内蒙古'=>array(
      '呼和浩特|huhehaote'=>array('回民|huiminqv','托县|tuoxian','和林格尔|helin','清水河|qingshuihe','呼市|hushijiaoqu','武川|wuchuan','新城|huhehaotexincheng','玉泉|yuquanqu','赛罕|saihanqu','土左旗|tumotezuoqi','托克托|tuoketuo',),
      '阿拉善|alashanmeng'=>array('阿拉善左旗|alashanzuoqi','阿拉善右旗|alashanyouqi','额济纳|ejina','拐子湖|guanzihu','吉兰泰|jilantai','锡林高勒|xilingaole','头道湖|toudaohu','中泉子|zhongquanzi','诺尔贡|nuoergong','雅布赖|yabulai','乌斯太|wusitai','孪井滩|luanjingtan',),
      '包头|baotou'=>array('白云鄂博|baiyunebo','满都拉|mandula','固阳|guyang','希拉穆|xilamuren','东河|donghequ','昆都仑|kundulunqu','青山|qingshanqu','石拐|shiguaiqu','九原|jiuyuanqu','土右旗|tumoteyouqi','达茂旗|daerhanmaomingan',),
      '巴彦淖尔|bayanzhuoer'=>array('临河|linhe','五原|wuyuan','磴口|dengkou','乌兰特前旗|wulateqianqi','乌兰特中旗|wulatezhongqi','乌兰特后旗|wulatehouqi','乌后旗|wuhouqi','海力素|hailisu','那仁宝力格|narenbaolige','杭锦后旗|hangjinhouqi',),
      '赤峰|chifeng'=>array('阿旗|aluqi','浩尔吐|haoertu','巴林左旗|balinzuoqi','巴林右旗|balinyouqi','林西|linxi','克什克腾|keshiketeng','翁牛特|wengniute','岗子|gangzi','喀喇沁|kalaqin','八里罕|balihan','宁城|ningcheng','敖汉|aohan','宝国吐|baoguotu','红山|hongshanqu','元宝山|yuanbaoshanqu','松山|songshanqu','阿鲁科尔沁旗|alukeer',),
      '鄂尔多斯|eerduosi'=>array('达拉特|dalate','准格尔|zhungeer','伊克乌素|yikewusu','鄂托克前|etuoke','杭锦旗|hangjinqi','乌审|wushenqi','伊金霍洛|yijinhuoluo','康巴什|kangbashen','东胜|dongsheng','鄂托克|etuokeqi',),
      '呼伦贝尔|hulunbeier'=>array('海拉尔|hailaer','小二沟|xiaoergou','阿荣旗|arongqi','莫力达瓦|molidawa','鄂伦春旗|elunchunqi','鄂温克旗|ewenkeqi','陈旗|chenqi','新左旗|xinbaerhuzuoqi','新右旗|xinyouqi','满洲里|manzhouli','牙克石|yakeshi','扎兰屯|zhalantun','额尔古纳|eerguna','根河|genhe','扎赉诺尔|zhalainuoer','鄂伦春|elunchun','鄂温克|ewenke','陈巴尔虎旗|chenbaerhu',),
      '通辽|tongliao'=>array('舍伯吐|shebotu','科左中旗|kezuozhongqi','科左后旗|kezuohouqi','开鲁|kailu','库伦|kulun','奈曼|naiman','扎鲁特|zhalute','高力板|gaoliban','巴雅尔吐胡硕|bayaertuhushuo','科尔沁|horqinqu','霍林郭勒|huolinguole','科尔沁左翼中旗|keerxinzuoyizhongqi','科尔沁左翼后旗|keerxinzuoyihouqi',),
      '乌海|wuhai'=>array('海勃湾|haibowanqu','海南|hainanqu','乌达|wudaqu',),
      '乌兰察布|wulanchabu'=>array('集宁|jining','卓资|zhuozi','化德|huade','商都|shangdu','兴和|xinghe','凉城|liangcheng','察右前旗|cahaeryouqian','察右中旗|chahaeryouzhong','察右后旗|chahaeryouhou','四子王旗|siziwangqi','丰镇|fengzhen',),
      '锡林郭勒|xilingguole'=>array('锡林浩特|xilinhaote','二连浩特|erlianhaote','阿巴嘎|abaga','苏左旗|sunitezuoqi','苏右旗|suniteyouqi','东乌珠穆沁旗|dongwuzhumuqinqi','西乌珠穆沁旗|xiwuzhumuqinqi','东乌旗|dongwuqi','西乌旗|xiwuqi','太仆寺|taibusiqi','镶黄旗|xianghuang','正镶白旗|zhengxiangbaiqi','正蓝旗|zhenglanqi','多伦|duolun','博克图|boketu','乌拉盖|wulagai',),
      '兴安|xinganmeng'=>array('乌兰浩特|wulanhaote','阿尔山|aershan','科右中旗|keyouzhongqi','胡尔勒|huerle','扎赉特|zhalaite','科右前旗|keermiyouqian','突泉|tuquan','科右中旗|keermiyouzhong',),
  ),

  '宁夏'=>array(
      '银川|yinchuan'=>array('永宁|yongning','灵武|lingwu','贺兰|helan','兴庆|xingqingqu','西夏|xixiaqu','金凤|jinfengqu',),
      '固原|guyuan1'=>array('西吉|xiji','隆德|longde','泾源|jinyuan1','彭阳|pengyang','原州|yuanzhou',),
      '石嘴山|shizuishan'=>array('惠农|huinong','平罗|pingluo','陶乐|taole','大武口|dawukouqu',),
      '吴忠|wuzhong'=>array('同心|tongxin','盐池|yanchi','青铜峡|qingtongxia','利通|litongqu','红寺堡|hongsipuqu',),
      '中卫|zhongwei'=>array('中宁|zhongning','海原|haiyuan','沙坡头|shapotouqu',),
  ),

  '青海'=>array(
      '西宁|xining'=>array('大通回族|datonghuizu','湟源|huangyuan','湟中|huangzhong','城东|chengdongqu','城西|chengxiqu','城北|chengbeiqu','西宁城中|xiningchengzhongqu',),
      '格尔木|geermu'=>array('都兰|dulan','天峻|tianjun','乌兰|wulan','德令哈|delingha',),
      '果洛|guoluo'=>array('班玛|banma','甘德|gande','达日|dari','久治|jiuzhi','玛多|madu','多县|duoxian1','玛沁|maqin',),
      '海北|haibei'=>array('门源|menyuan','祁连|qilian','海晏|haiman','刚察|gangcha',),
      '海东|haidong'=>array('乐都|ledu','民和|minhe','互助|huzhu','化隆|hualong','循化|xunhua','冷湖|lenghu','平安|pingan',),
      '海南州|hainanzhou'=>array('海南|hainan','贵德|guide','兴海|xinghai','贵南|guinan','同德|tongde','共和|gonghe',),
      '海西|haixi'=>array('茫崖|mangai','大柴旦|dachaidan',),
      '黄南|huangnan'=>array('尖扎|jianzha','泽库|zeku','河南|henan1','同仁|tongren1','河南蒙古族|henanmengguzu',),
      '玉树|yushu1'=>array('称多|chenduo','治多|zhiduo','杂多|zaduo','囊谦|nangqian','曲麻莱|qumacai',),
  ),

  '山东'=>array(
      '济南|jinan'=>array('长清|changqing','商河|shanghe','章丘|zhangqiu','平阴|pingyin','济阳|jiyang','济南市中|jinanshizhong','历下|lixiaqu','槐荫 |kuaiyinqu','天桥|tianqiaoqu','历城|jinanlicheng','槐荫|jinanhuaiyin',),
      '滨州|binzhou'=>array('博兴|boxing','无棣|wudi','阳信|yangxin','惠民|huimin','沾化|zhanhua','邹平|zouping','滨城|binxianqu',),
      '德州|dezhou'=>array('武城|wucheng','临邑|linyi1','陵城|lingxian','齐河|qihe','乐陵|leling','庆云|qingyun','平原|pingyuan','宁津|ningjin1','夏津|xiajin','禹城|yucheng','德城|decheng',),
      '东营|dongying'=>array('河口|hekou','垦利|kenli','利津|lijin','广饶|guangrao','东营区|dongyingqu',),
      '菏泽|heze'=>array('鄄城|juancheng','郓城|yuncheng1','东明|dongming','定陶|dingtao','巨野|juye','曹县|caoxian','成武|chengwu','单县|shanxian','牡丹|mudanqu',),
      '济宁|jining1'=>array('嘉祥|jiaxiang','微山|weishan','鱼台|yutai','兖州|yanzhou','金乡|jinxiang','汶上|wenshang','泗水|sishui','梁山|liangshan','曲阜|qufu','邹城|zoucheng','任城|renchengqu',),
      '莱芜|laiwu'=>array('莱城|laicheng','钢城|gangchengqu',),
      '聊城|liaocheng'=>array('冠县|guanxian','阳谷|yanggu','高唐|gaotang','茌平|chiping','东阿|donge','临清|linqing','莘县|shenxian','东昌府|dongchangfu',),
      '临沂|linyi2'=>array('莒南|junan','沂南|yinan','临沭|linshu','郯城|tancheng','蒙阴|mengyin','平邑|pingyi','费县|feixian','沂水|yishui','兰山|lanshanqu','罗庄|luozhuangqu','临沂河东|lingyihedong','兰陵|lanlingxian',),
      '青岛|qingdao'=>array('崂山|laoshan','即墨|jimo','胶州|jiaozhou','胶南|jiaonan','莱西|laixi','平度|pingdu','黄岛|huangdao','市北|shibeiqu','市南|shinan','李沧|licangqu','城阳|chengyangqu',),
      '日照|rizhao'=>array('五莲|wulian','莒县|juxian','东港|donggangqu','岚山|rizhaolanshan',),
      '泰安|taian1'=>array('新泰|xintai','肥城|feicheng','东平|dongping','宁阳|ningyang','泰山|taishanqu','岱岳|daiyuequ',),
      '潍坊|weifang'=>array('青州|qingzhou','寿光|shouguang','临朐|linqu','昌乐|changle','昌邑|changyi','安丘|anqiu','高密|gaomi','诸城|zhucheng','安次|anciqu','广阳|guangyangqu','潍城|weichengqu','寒亭|hantingququ','坊子|fangziqu','奎文|kuiwenqu',),
      '威海|weihai'=>array('文登|wendeng','荣成|rongcheng2','乳山|rushan','环翠|huancuiqu',),
      '烟台|yantai'=>array('莱州|laizhou','长岛|changdao','蓬莱|penglai','龙口|longkou','招远|zhaoyuan1','栖霞|qixia','福山|fushan1','牟平|muping','莱阳|laiyang','海阳|haiyang','芝罘|zhifuqu','莱山|laishanqu',),
      '枣庄|zaozhuang'=>array('薛城|xuecheng','峄城|yicheng1','台儿庄|taierzhuang','滕州|tengzhou','枣庄市中|shizhongqu','山亭|shantingququ',),
      '淄博|zibo'=>array('淄川|zichuan','博山|boshan','高青|gaoqing','周村|zhoucun','沂源|yiyuan','桓台|huantai','临淄|linzi','张店|zhangdianqu',),
  ),

  '山西'=>array(
      '太原|taiyuan'=>array('清徐|qingxu','阳曲|yangqu','娄烦|loufan','古交|gujiao','尖草坪|jiancaopingqu','小店|xiaodianqu','迎泽|yingzequ','杏花岭|xinghualing','万柏林|wanbolinqu','晋源|jinyuanqu',),
      '长治|changzhi'=>array('黎城|licheng','屯留|tunliu','潞城|lucheng','襄垣|xiangyuan','平顺|pingshun','武乡|wuxiang','沁县|qinxian','长子|zhangzi','沁源|qinyuan','壶关|huguan','长治郊|changzhijiaoqu','长治|changzhixian',),
      '大同|datong'=>array('阳高|yanggao','大同县|datongxian','天镇|tianzhen','广灵|guangling','灵丘|lingqiu','浑源|hunyuan','左云|zuoyun','新荣|xinrongqu','南郊|nanjiaoqu',),
      '晋城|jincheng'=>array('沁水|qinshui','阳城|yangcheng','陵川|lingchuan','高平|gaoping','泽州|zezhou',),
      '晋中|jinzhong'=>array('榆次|yuci','榆社|yushe','左权|zuoquan','和顺|heshun','昔阳|xiyang','寿阳|shouyang','太谷|taigu','祁县|qixian','平遥|pingyao','灵石|lingshi','介休|jiexiu',),
      '临汾|linfen'=>array('曲沃|quwo','永和|yonghe','隰县|xixian','大宁|daning','吉县|jixian','襄汾|xiangfen','蒲县|puxian','汾西|fenxi','洪洞|hongtong','霍州|huozhou','乡宁|xiangning','翼城|yicheng','侯马|houma','浮山|fushan','安泽|anze','古县|guxian','尧都|yaodu',),
      '吕梁|lvliang'=>array('吕梁离石|lvlianglishi','临县|linxian','兴县|xingxian','岚县|lanxian','柳林|liulin','石楼|shilou','方山|fangshan1','交口|jiaokou','中阳|zhongyang','孝义|xiaoyi','汾阳|fenyang','文水|wenshui','交城|jiaocheng',),
      '朔州|shuozhou'=>array('平鲁|pinglu1','山阴|shanyin','右玉|youyu','应县|yingxian','怀仁|huairen','朔城|shuocheng',),
      '忻州|xinzhou'=>array('定襄|dingxiang','五台|wutaixian','河曲|hequ','偏关|pianguan','神池|shenchi','宁武|ningwu','代县|daixian','繁峙|fanshi','保德|bode','静乐|jingle','岢岚|kelan','五寨|wuzhai','原平|yuanping','忻府|xinfuqu',),
      '阳泉|yangquan'=>array('盂县|yuxian','平定|pingding','矿区|kuangqu','城区|yangquanjiaoqu','郊区|jiaoqu',),
      '运城|yuncheng'=>array('临猗|linyi','稷山|jishan','万荣|wanrong','河津|hejin','新绛|xinjiang','绛县|jiangxian','闻喜|wenxi','垣曲|yuanqu','永济|yongji1','芮城|ruicheng','夏县|xiaxian','平陆|pinglu','盐湖|yanhuqu',),
  ),

  '陕西'=>array(
      '西安|xian'=>array('长安|changan','临潼|lintong','蓝田|lantian','周至|zhouzhi','户县|huxian','高陵|gaoling','新城|xincheng','碑林|beilin','莲湖|lianhuqu','灞桥|baqiaoqu','未央|weiyangqu','雁塔|yantaqu','阎良|yanliangqu',),
      '安康|ankang'=>array('紫阳|ziyang','石泉|shiquan','汉阴|hanyin','旬阳|xunyang','岚皋|langao','平利|pingli','白河|baihe','镇坪|zhenping','宁陕|ningshan','汉滨|hanbinqu',),
      '宝鸡|baoji'=>array('千阳|qianyang','麟游|linyou','岐山|qishan','凤翔|fengxiang','扶风|fufeng','眉县|meixian','太白|taibai','凤县|fengxian1','陇县|longxian','陈仓|chencang','渭滨|weibin','金台|jintaiqu',),
      '汉中|hanzhong'=>array('略阳|lueyang','勉县|mianxian','留坝|liuba','洋县|yangxian','城固|chenggu','西乡|xixiang','佛坪|fuoping','宁强|ningqiang','南郑|nanzheng','镇巴|zhenba','汉台|hantaiqu',),
      '商洛|shangluo'=>array('洛南|luonan','柞水|zhashui','商州|shangzhou','镇安|zhenan','丹凤|danfeng','商南|shangnan','山阳|shanyang',),
      '铜川|tongchuan'=>array('耀县|yaoxian','宜君|yijun','耀州|yaozhou','王益|wangyiqu','印台|yintaiqu',),
      '渭南|weinan'=>array('华县|huaxian','潼关|tongguan','大荔|dali','白水|baishui','富平|fuping1','蒲城|pucheng','澄城|chengcheng','合阳|heyang','韩城|hancheng','华阴|huayin','临渭|linweiqu','华州|huazhouqu',),
      '咸阳|xianyang'=>array('三原|sanyuan','礼泉|liquan','永寿|yongshou','淳化|chunhua','泾阳|jingyang','武功|wugong','乾县|qianxian','彬县|binxian1','长武|changwu','旬邑|xunyi','兴平|xingping','秦都|qinduqu','杨陵|yangling','渭城|weicheng',),
      '延安|yanan'=>array('延长|yanchang','延川|yanchuan','子长|zichang','宜川|yichuan','富县|fuxian','志丹|zhidan','安塞|ansai','甘泉|ganquan','洛川|luochuan','黄陵|huangling','黄龙|huanglong','吴起|wuqi','宝塔|baotaqu',),
      '榆林|yulin'=>array('府谷|fugu','神木|shenmu','佳县|jiaxian','定边|dingbian','靖边|jingbian','横山|hengshan','米脂|mizhi','子洲|zizhou','绥德|suide','吴堡|wubu','清涧|qingjian','榆阳|yuyang','榆阳区|yuyangqu',),
  ),

  '四川'=>array(
      '成都|chengdu'=>array('龙泉驿|longquanyi','新都|xindu','温江|wenjiang','金堂|jintang','双流|shuangliu','郫县|pixian','大邑|dayi','蒲江|pujiang1','新津|xinjin','锦江|jinjiangqu','金牛|jinniuqu','成华|chenghuaqu','武侯|wuhouqu','青羊|qingyangqu','青白江|qingbaijiangqu',),
      '阿坝州|aba'=>array('阿坝|aba','汶川|wenchuan','理县|lixian3','茂县|maoxian','松潘|songpan','九寨沟|jiuzhaigou','金川|jinchuan','小金|xiaojin','黑水|heishui','马尔康|maerkang','壤塘|rangtang','若尔盖|nuoergai','红原|hongyuan',),
      '巴中|bazhong'=>array('通江|tongjiang1','南江|nanjiang','平昌|pingchang','恩阳|enyang',),
      '达州|dazhou'=>array('宣汉|xuanhan','开江|kaijiang','大竹|dazhu','渠县|quxian','万源|wanyuan','达川|dachuan','达县|daxian','通川|tongchuanqu',),
      '德阳|deyang'=>array('中江|zhongjiang','广汉|guanghan','什邡|shifang','绵竹|mianzhu','罗江|luojiang','旌阳|jingyangqu',),
      '甘孜州|ganzi'=>array('康定|kangding','泸定|luding','丹巴|danba','九龙|jiulong','雅江|yajiang','道孚|daofu','炉霍|luhuo','新龙|xinlong','德格|dege','白玉|baiyu','石渠|shiqu','色达|seda','理塘|litang','巴塘|batang','乡城|xiangchengxian','稻城|daocheng','得荣|derong',),
      '广安|guangan'=>array('岳池|yuechi','武胜|wusheng','邻水|linshui','广安区|guanganqu','前锋|qianfeng',),
      '广元|guangyuan'=>array('旺苍|wangcang','青川|qingchuan','剑阁|jiange','苍溪|cangxi','利州|lizhou','元坝|yuanbaqu','朝天|chaotianqu','昭化|zhaohuaqu',),
      '乐山|leshan'=>array('犍为|qianwei','井研|jingyan','夹江|jiajiang','沐川|muchuan','峨边|ebian','马边|mabian','峨眉|emei','峨眉山|emeishan','金口河|jinkouhequ','五通桥|wutongqiaoqu','沙湾|shawanqu',),
      '凉山|liangshan1'=>array('木里|muli','盐源|yanyuan','德昌|dechang','会理|huili','会东|huidong','宁南|ningnan','普格|puge','西昌|xichang','金阳|jinyang','昭觉|zhaojue','喜德|xide','冕宁|mianning','越西|yuexizian','甘洛|ganluo','雷波|leibo','美姑|meigu','布拖|butuo',),
      '泸州|luzhou'=>array('泸县|luxian','合江|hejiang','叙永|xuyong','古蔺|gulin','纳溪|naxi','龙马潭|longmatan','江阳|jiangyangqu',),
      '眉山|meishan'=>array('仁寿|renshou','彭山|pengshan','洪雅|hongya','丹棱|danleng','青神|qingshen','东坡|dongpoqu',),
      '绵阳|mianyang'=>array('三台|santai','盐亭|yanting','安县|anxian','梓潼|zitong','北川|beichuan','平武|pingwu','江油|jiangyou','涪城|fuchengqu','游仙|youxianqu','安州|anzhouqu',),
      '南充|nanchong'=>array('南部|nanbu','营山|yingshanxian','蓬安|pengan','仪陇|yilong','西充|xichong','阆中|langzhong','嘉陵|jialingqu','高坪|gaopingqu','顺庆|shunqing',),
      '内江|neijiang'=>array('东兴|dongxing','威远|weiyuanxian','资中|zizhong','隆昌|longchang',),
      '攀枝花|panzhihua'=>array('仁和|renhe','米易|miyi','盐边|yanbian1','攀枝花东区|panzhihuadongqu','攀枝花西区|panzhihuaxiqu',),
      '遂宁|suining1'=>array('蓬溪|pengxi','射洪|shehong','大英|dayinqu','船山|chuanshanqu','安居|anjuqu',),
      '雅安|yaan'=>array('名山|mingshan','荥经|yingjing','汉源|hanyuan','石棉|shimian','天全|tianquan','芦山|lushanxian','宝兴|baoxing','雨城|yuchengqu',),
      '宜宾|yibin'=>array('宜宾县|yibinxian','南溪|nanxi','江安|jiangan','高县|gaoxian','珙县|gongxian','筠连|junlian','兴文|xingwen','屏山|pingshanxian','翠屏|cuipingqu',),
      '自贡|zigong'=>array('荣县|rongxian','贡井|gongjingqu','自流井|ziliujingqu','沿滩|yantanqu','大安|daanqu',),
      '资阳|ziyang1'=>array('安岳|anyue','乐至|lezhi','简阳|jianyang1','雁江|yanjiangqu',),
  ),

  '西藏'=>array(
      '拉萨|lasa'=>array('当雄|dangxiong','尼木|nimu','林周|linzhou1','堆龙德庆|duilongdeqing','曲水|qushui','达孜|dazi','墨竹工卡|mozhugongka','拉萨城关|lasachengguanqu','那曲地|nagqu',),
      '阿里|ali'=>array('改则|gaize','申扎|shenzha','普兰|pulan','札达|zhada','噶尔|gaer','日土|ritu','革吉|geji','措勤|cuoqin',),
      '昌都|changdu'=>array('丁青|dingqing','边坝|bianba','洛隆|luolong','左贡|zuogong','芒康|mangkang','类乌齐|leiwuqi','八宿|basu','江达|jiangda','察雅|chaya','贡觉|gongjue','卡若|keruoqu',),
      '林芝|linzhi'=>array('波密|bomi','米林|milin','察隅|chayu','工布江达|gongbujiangda','朗县|langxian','墨脱|motuo','巴宜|bayiqu',),
      '那曲|naqu'=>array('尼玛|nima','嘉黎|jiali','班戈|bange','安多|anduo','索县|suoxian','聂荣|nierong','巴青|baqing','比如|biru','双湖|shuanghu',),
      '日喀则|rikaze'=>array('拉孜|lazi','南木林|nanmulin','聂拉木|nielamu','定日|dingri','江孜|jiangzi','帕里|pali','仲巴|zhongba','萨嘎|saga','吉隆|jilong','昂仁|angren','定结|dingjie','萨迦|sajia','谢通门|xietongmen','岗巴|gangba','白朗|bailang','亚东|yadong','康马|kangma','仁布|renbu','日喀则地|shigatsequ','桑珠孜|sangzhuzi',),
      '山南|shannan'=>array('贡嘎|gongga','扎囊|zhanang','加查|jiacha','浪卡子|langkazi','错那|cuona','隆子|longzi','泽当|zedang','乃东|naidong','桑日|sangri','洛扎|luozha','措美|cuomei','琼结|qiongjie','曲松|qusong',),
  ),

  '新疆'=>array(
      '乌鲁木齐|wulumuqi'=>array('达坂城|dabancheng','乌市牧试站|wulumuqimushizhan','新市|xinshiqu','天山|tianshan','沙依巴克|saybaghqu','水磨沟|shuimogouqu','头屯河|toutunhequ','米东|midongqu','乌鲁木齐县|wulumuqixian','伊宁|yining','察布查尔|chabuchaer','尼勒克|nileke','伊宁县|yiningxian','巩留|gongliu','新源|xinyuan','昭苏|zhaosu','特克斯|tekesi','霍城|huocheng','霍尔果斯|huoerguosi','奎屯|kuitunshi',),
      '阿克苏|akesu'=>array('乌什|wushi','温宿|wensu','拜城|baicheng1','新和|xinhe1','沙雅|shaya','库车|kuche','柯坪|keping','阿瓦提|awati','阿瓦提|awat',),
      '阿拉尔|alaer'=>array('阿拉尔|alaer',),
      '阿勒泰|aletai'=>array('哈巴河|habahe','吉木乃|jimunai','布尔津|buerjin','福海|fuhai','富蕴|fuyun','青河|qinghe1',),
      '巴音郭楞|bazhou1'=>array('库尔勒|kuerle','轮台|luntai','尉犁|yuli','若羌|ruoqiang','且末|qiemo','和静|hejing','焉耆|yanqi','和硕|heshuo','巴音布鲁克|bayinbuluke','铁干里克|tieganlike','博湖|bohu','塔中|tazhong','巴仑台|baluntai',),
      '博州|bozhou'=>array('博乐|bole','温泉|wenquan','精河|jinghe','阿拉山口|alashankou',),
      '昌吉回族|changji'=>array('昌吉|changji','呼图壁|hutubi','米泉|miquan','阜康|fukang','吉木萨尔|jimusaer','奇台|qitai','玛纳斯|manasi','木垒|mulei','蔡家湖|caijiahu',),
      '哈密|hami'=>array('伊州|hamiyizhou','巴里坤|balikun','伊吾|yiwu',),
      '和田|hetian'=>array('皮山|pishan','策勒|cele','墨玉|moyu','洛浦|luopu','民丰|mingfeng','于田|yutian1','和田县|ketianxian',),
      '喀什|kashi'=>array('英吉沙|yingjisha','塔什库尔干|tashikuergan','麦盖提|maigaiti','莎车|shache','叶城|yecheng','泽普|zepu','巴楚|bachu','岳普湖|yuepuhu','伽师|jiashi','疏附|shufu','疏勒|shule','喀什|tashishi',),
      '克拉玛依|kelamayi'=>array('乌尔禾|wuerhe','白碱滩|baijiantan','独山子|dushanziqu','克拉玛依区|kelamayiqu',),
      '克州|kezhou'=>array('阿图什|atushi','乌恰|wuqia','阿克陶|aketao','阿合奇|aheqi',),
      '石河子|shihezi'=>array('炮台|paotai','莫索湾|mosuowan',),
      '塔城|tacheng'=>array('裕民|yumin','额敏|emin','和布克赛尔|hebukesaier','托里|tuoli','乌苏|wusu','沙湾|shawan',),
      '铁门关|tiemenguan'=>array('铁门关|tiemenguan',),
      '吐鲁番|tulufan'=>array('托克逊|tuokexun','鄯善|shanshan','高昌|gaochang',),
      '图木舒克|tumushuke'=>array('图木舒克|tumushuke',),
      '五家渠|wujiaqu'=>array('五家渠|wujiaqu',),
  ),

  '云南'=>array(
      '昆明|kunming'=>array('五华|wuhuaqu','东川|dongchuan','寻甸|xundian','晋宁|jinning','宜良|yiliang','石林|shilin','呈贡|chenggong','富民|fumin','嵩明|songming','禄劝|luquan','安宁|anning','盘龙|panlong','官渡|guanduqu','西山|xishanqu',),
      '保山|baoshan1'=>array('龙陵|longling','施甸|sidian','昌宁|changningxian','腾冲|tengchong','隆阳|longyangqu',),
      '楚雄州|chuxiong'=>array('楚雄|chuxiong','大姚|dayao','元谋|yuanmou','姚安|yaoan','牟定|mouding','南华|nanhua','武定|wuding','禄丰|lufengxian','双柏|shuangbai','永仁|yongren',),
      '大理州|dali1'=>array('云龙|yunlong','漾濞|yangbi','永平|yongping','宾川|binchuan','弥渡|midu','祥云|xiangyun','巍山|weishanxian','剑川|jianchuan','洱源|eryuan','鹤庆|heqing','南涧|nanjian',),
      '德宏|dehong'=>array('陇川|longchuanxian','盈江|yingjiangxian','瑞丽|ruilishi','梁河|lianghexian','潞西|luxixian','芒市|mangshi','芒市区|mangshiqu',),
      '迪庆|diqing'=>array('香格里拉|xianggelila','德钦|deqin','维西|weixi','中甸|zhongdian',),
      '红河州|honghe'=>array('红河|honghe','石屏|shiping','建水|jianshui','弥勒|mile','元阳|yuanyangxian','绿春|lvchun','开远|kaiyuan1','个旧|gejiu','蒙自|mengzi','屏边|pingbian','金平苗族|jinpingmiaozu',),
      '丽江|lijiang'=>array('永胜|yongsheng','华坪|huaping','宁蒗|ninglang','玉龙|yulongnaxi',),
      '临沧|lincang'=>array('沧源|cangyuan','耿马|gengma','双江|shuangjiang','凤庆|fengqing','永德|yongde','云县|yunxian','镇康|zhenkang','临翔|linxiangqu',),
      '怒江州|nujiang'=>array('福贡|fugong','兰坪|lanping','泸水|lushui','六库|liuku','贡山|gongshan',),
      '普洱|puer'=>array('景谷|jinggu','景东|jingdong','澜沧|lancang','墨江|mojiang','江城|jiangcheng','孟连|menglian','西盟|ximeng','镇沅|zhenyuanxian','宁洱|ninger','思茅|simao','江城哈尼族|jiangchengha',),
      '曲靖|qujing'=>array('沾益|zhanyi','陆良|luliang','富源|fuyuanxian','马龙|malong','师宗|shizong','罗平|luoping','会泽|huize','宣威|xuanwei','麒麟|qilinqu',),
      '文山州|wenshan'=>array('文山|wenshan','西畴|xichou','马关|maguan','麻栗坡|malipo','砚山|yanshanxian','丘北|qiubei','广南|guangnan','富宁|funingxian',),
      '西双版纳|xishuangbanna'=>array('景洪|jinghongshi','勐海|menghaixian','勐腊|menglaxian',),
      '玉溪|yuxi'=>array('澄江|chengjiang','江川|jiangchuan','通海|tonghai','华宁|huaning','新平|xinping','易门|yimen','峨山|eshan','元江|yuanjiangxian','红塔|hongtaqu',),
      '昭通|zhaotong'=>array('鲁甸|ludian','彝良|yiliangxian','镇雄|zhenxiong','威信|weixin','巧家|qiaojia','绥江|suijiang','永善|yongshan','盐津|yanjinxian','大关|daguan','水富|shuifu','昭阳|zhaoyangqu',),
  ),

  '浙江'=>array(
      '杭州|hangzhou'=>array('萧山|xiaoshan','桐庐|tonglu','淳安|chunan','建德|jiande','余杭|yuhang','临安|linan','富阳|fuyang','上城|shangchengqu','下城|xiachengqu','江干|jiangganqu','拱墅|gongshuqu','西湖|xihu','滨江|binjianqu',),
      '湖州|huzhou'=>array('长兴|changxing','安吉|anji','德清|deqing','南浔|nanxun','吴兴|wuxingqu',),
      '嘉兴|jiaxing'=>array('嘉善|jiashan','海宁|haining','桐乡|tongxiang','平湖|pinghu','海盐|haiyan1','南湖|nanhuqu','秀洲|xiuzhouqu',),
      '金华|jinhua'=>array('浦江|pujiang','兰溪|lanxi1','义乌|yiwu1','东阳|dongyang','武义|wuyi1','永康|yongkang','磐安|panan','横店|hengdian','婺城|wuchengqu','金东|jindongqu',),
      '丽水|lishui'=>array('遂昌|suichang','龙泉|longquan','缙云|jinyun','青田|qingtian','云和|yunhe','庆元|qingyuan2','松阳|songyang','景宁|jingning1','莲都|liandu','古城|guchengqu',),
      '宁波|ningbo'=>array('慈溪|cixi','余姚|yuyao','奉化|fenghua','象山|xiangshan','宁海|ninghai','北仑|beilun','鄞州|yinzhou','镇海|zhenhai','海曙|haishuqu','江东|jiangdongqu','宁波江北|ningbojiangbei',),
      '衢州|quzhou1'=>array('常山|changshan','开化|kaihua','龙游|longyou','江山|jiangshan','衢江|qujiang1','柯城|kechengqu',),
      '绍兴|shaoxing'=>array('诸暨|zhuji','上虞|shangyu','新昌|xinchang','嵊州|shengzhou','越城|yuechengqu','柯桥|keqiaoqv',),
      '台州|taizhou'=>array('玉环|yuhuan','三门|sanmen','天台|tiantai','仙居|xianju','温岭|wenling','洪家|hongjia','临海|linhai','椒江|jiaojiang','黄岩|huangyan','路桥|luqiao',),
      '温州|wenzhou'=>array('泰顺|taishun','文成|wencheng','平阳|pingyang','瑞安|ruian','洞头|dongtou','乐清|yueqing','永嘉|yongjia','苍南|cangnan','鹿城|luchengqu','龙湾|longwanqu','瓯海|ouhaiqu',),
      '舟山|zhoushan'=>array('嵊泗|shengsi','岱山|daishan','普陀|putuo','定海|dinghai',),
  ),

);

$seek['international'] = array(
  '亚洲' => array(

    '印度' => array('新德里|1420108','孟买|1420070','斋浦尔|1420119','阿格拉|1420120','班加罗尔|1420014','哲雪铺|1420115','章普尔|1420114','伊塔纳加尔|1420113','因帕尔|1420112','印多尔|1420111','锡瓦卡西|1420110','希萨尔|1420109','西隆|1420107','乌拉斯讷格尔|1420106','乌都皮|1420105','乌代普尔|1420104','温瑙|1420103','维萨卡帕特南|1420102','韦洛尔|1420101','维鲁杜讷格尔|1420100','韦拉沃尔|1420099','维济亚讷格勒姆|1420098','瓦朗加尔|1420097','瓦尔道拉|1420096','提斯浦尔|1420095','特拉凡德伦|1420094','坦巴拉|1420093','塔纳|1420092','索尼帕特|1420091','索拉普|1420090','苏拉特|1420089','斯利那加|1420088','萨特纳|1420087','奇图尔|1420086','钦奈|1420085','浦那|1420084','皮瓦尼|1420083','皮瓦恩迪|1420082','毗底沙|1420081','蓬吉尔|1420080','内洛尔|1420079','讷格尔科伊|1420078','讷迪亚德|1420077','纳西克|1420076','穆扎法尔讷格尔|1420075','默吉利伯德讷|1420074','莫加|1420073','默黑萨纳|1420072','密鲁特|1420071','梅迪尼布尔|1420069','曼迪亚|1420068','马莱冈|1420067','马赫布卜讷格尔|1420066','马都赖|1420065','罗塔克|1420064','鲁得希阿那|1420063','李博伯雷利|1420062','勒克瑙|1420061','兰契|1420060','拉杰巴莱亚姆|1420059','赖格尔|1420058','科泽科德|1420057','科希马|1420056','克塔克|1420055','科钦|1420054','科拉尔|1420053','克久拉霍|1420052','卡塔尔洛|1420051','卡努尔|1420050','坎普尔|1420049','坎曼|1420048','卡基纳达|1420047','吉德勒杜尔加|1420046','加特尼|1420045','贾沙梅尔|1420044','加瑟勒戈德|1420043','焦尔哈德|1420042','加兹阿巴德|1420041','加尔各答|1420040','贾巴尔普尔|1420039','霍纳沃尔|1420038','豪拉|1420037','瓜廖尔|1420036','戈特拉|1420035','格德格|1420034','甘托克|1420033','噶伦堡|1420032','法扎巴德|1420031','多德伯拉布尔|1420030','杜拉哈|1420029','栋格|1420028','迪斯普尔|1420027','丁迪古尔|1420026','蒂鲁帕蒂|1420025','德拉敦|1420024','道恩德|1420023','昌迪加尔|1420022','布巴内斯瓦尔|1420021','伯西尔哈德|1420020','波帕尔|1420019','博尔本德尔|1420018','比卡内尔|1420017','本地治里|1420016','包纳加尔|1420015','巴多格拉|1420013','阿萨姆邦|1420012','奥赖亚|1420011','阿讷加伯莱|1420010','阿姆利则|1420009','阿姆劳蒂|1420008','阿鲁布戈代|1420007','阿勒皮|1420006','阿科拉|1420005','阿加尔塔拉|1420004','埃塔瓦|1420003','埃拉曼奇利|1420002','阿默达巴德|1420001','德里|1420116','海得拉巴|1420117','那格浦尔|1420118','巴特那|1420121','阿迪拉巴德|1420122','艾哈迈德讷格尔|1420123','阿杰梅尔|1420124','阿里格尔|1420125','阿尔|1420126','安巴拉|1420127','安雷利|1420128','安古尔|1420129','阿努普加尔|1420130','阿里耶卢尔|1420131','奥兰加巴德|1420132','阿扎姆加尔|1420133','巴拉索尔|1420134','巴卢尔加特|1420135','班达|1420136','伯尼哈尔|1420137','班库拉|1420138','班斯瓦拉县|1420139','巴雷利|1420140','巴尔默|1420141','巴斯蒂|1420142','贝尔高姆|1420143','贝拉里|1420144','贝杜尔|1420145','帕戈尔布尔|1420146','珀勒德布尔|1420147','珀丁达|1420148','比尔瓦拉|1420149','平德|1420150','普杰|1420151','比德尔|1420152','比贾普尔|1420153','比拉斯普尔|1420154','本迪|1420155','甘宁|1420156','占城|1420157','德拉布尔|1420158','乞拉朋齐|1420159','钦德瓦拉|1420160','钦塔马尼|1420161','哥印拜陀|1420162','古德伯|1420163','达尔豪斯|1420164','达莫|1420165','达尔彭加|1420166','代赫里|1420167','丹巴德|1420168','达尔|1420169','达尔马布里|1420170','达兰萨拉|1420171','迪格哈|1420172','第乌|1420173','杜卡姆|1420174','敦格布尔|1420175','杜尔格|1420176','德瓦卡|1420177','甘地|1420178','伽耶|1420179','加济布尔|1420180','戈拉加特|1420181','贡达|1420182','贡迪亚|1420183','戈巴尔布尔|1420184','古尔柏加|1420185','库拿|1420186','古尔冈|1420187','哈夫隆格|1420188','霍尔迪亚|1420189','哈尔多|1420190','赫尔奈|1420191','哈桑|1420192','霍申加巴德|1420193','杰格德尔布尔|1420194','杰尔拜古里|1420195','查谟|1420196','贾姆讷格尔|1420197','杰穆伊|1420198','杰什布尔讷格尔|1420199','贾拉瓦尔|1420200','占夕|1420201','焦特布尔|1420202','凯拉沙哈尔|1420203','根尼亚古马里|1420204','卡来卡|1420205','卡尔纳尔|1420206','加尔瓦尔|1420207','卡瓦利|1420208','克肖德|1420209','肯德瓦|1420210','戈代加讷尔|1420211','戈尔哈布尔|1420212','戈拉布德|1420213','戈德亚姆|1420214','迈恩布里|1420215','曼迪|1420216','马泰兰|1420217','马图拉|1420218','梅达克|1420219','莫拉达巴德|1420220','莫蒂哈里|1420221','马苏|1420222','穆扎法尔布尔|1420223','迈索尔|1420224','纳格伯蒂讷姆|1420225','纳高尔县|1420226','纳汉|1420227','纳吉巴巴德|1420228','纳尔贡达|1420229','瑙登瓦|1420230','奥哈|1420231','昂戈尔|1420232','伯拉卡德|1420233','潘纳|1420234','帕西格|1420235','帕蒂亚拉|1420236','彼拉尼|1420237','皮利比特|1420238','普里|1420239','卡齐古恩德|1420240','赖丘尔|1420241','赖布尔|1420242','瑞森|1420243','拉杰果德|1420244','朗吉亚|1420245','勒德拉姆|1420246','拉特纳吉里|1420247','雷瓦|1420248','鲁尔|1420249','森伯尔布尔|1420250','桑格利|1420251','萨达拉|1420252','沙贾汉布尔|1420253','谢奥布尔|1420254','西姆拉|1420255','希莫加|1420256','希沃布里|1420257','西布萨加尔|1420258','苏包尔|1420259','苏仁德拉那加|1420260','特赫里|1420261','坦加布尔|1420262','栋迪|1420263','杜尼|1420264','乌贾因|1420265','乌默里亚|1420266','瓦尔巴赖|1420267','瓦拉纳西|1420268','文古尔拉|1420269','维杰亚瓦达|1420270','沃尔塔|1420271','安德罗特|1420273','阿拉|1420274','巴加尔科特|1420275','贝拉迪拉|1420276','巴利亚|1420277','柏蓝波|1420278','比拉|1420279','布恩塔|1420280','柏德旺|1420281','奇克马加卢尔|1420282','奇特多咖|1420283','康纳|1420284','达顿干吉|1420285','大吉岭|1420286','迪萨|1420287','塔尔瓦德|1420288','多尔浦|1420289','杜布里|1420290','戴蒙德港|1420291','都哈|1420292','贡马|1420293','赫札里巴克|1420294','伊达尔|1420295','贾洛尔|1420296','卡林朋|1420297','孔杜尔岛|1420298','长岛|1420299','马湖华|1420300','马尔达|1420301','马那|1420302','米德纳普尔|1420303','米尼科伊岛|1420304','莫尔穆冈|1420305','阿布山|1420306','奈尼陶|1420307','南考雷|1420308','楠代德|1420309','纳西克城|1420310','新坎德拉|1420311','尼默杰|1420312','班本|1420313','巴拉迪布|1420314','普巴尼|1420315','布莱尔港|1420316','布尔尼亚|1420317','普路赖|1420318','罗尔凯勒|1420319','桑提尼克坦|1420320','希拉利|1420321','肖拉普尔|1420322','斯里古里|1420323','塔东|1420324','唐拉|1420325','特里苏尔|1420326','乌塔卡蒙德|1420327','亚瓦特马尔|1420328',),
    '越南' => array('芽庄|1460018','胡志明市|1460009','河内|1460008','岘港|1460017','潘切|1460013','富国|1460004','头顿|1460016','宋科|1460015','芹苴|1460014','南定省|1460012','老街|1460011','金瓯|1460010','海防|1460007','贵仁|1460006','光荣|1460005','边和|1460003','北江|1460002','安宁|1460001','顺化|1460019','白龙尾县|1460023','康森|1460024','谅山|1460025','衙庄市|1460026','藩切市|1460027',),
    '印度尼西亚' => array('巴厘岛|1430029','雅加达|1430026','登巴萨|1430005','泗水|1430040','直葛|1430028','亚巫兰|1430027','万鸦老|1430025','万隆|1430024','松巴哇岛|1430023','双溪格龙|1430022','诗都文罗|1430021','三马林达|1430020','三宝垄|1430019','日惹|1430018','普哇加达|1430017','帕梅卡桑|1430015','纳塔尔|1430014','纳比尔|1430013','明古鲁省|1430012','棉兰|1430011','茂物|1430010','兰加士勿洞|1430009','巨港|1430008','井里汶|1430007','哥打巴鲁|1430006','丹戒加兰|1430004','槟港|1430003','邦义尔|1430002','阿马哈尔|1430001','巴东|1430030','三口洋市|1430031','马塔普拉|1430032','巴厘巴板|1430033','望加锡|1430034','帕卢|1430035','哥伦打洛|1430036','曼诺瓦里|1430037','安汶|1430038','古邦|1430039','外南梦|1430041','比通|1430042','卡利昂厄特|1430043','马杰内|1430044','瑟朗|1430045','芝拉扎|1430046','埃纳罗塔利|1430047','格斯尔|1430048','楠勒阿|1430049','楠阿皮诺|1430050','巴罗|1430051','那雷尼|1430052','萨拉纳|1430053','新当|1430054','塔纳默拉|1430055','达仁巴|1430056','迪米卡|1430057','瓦梅纳|1430058',),
    '马尔代夫' => array('马累|1190001','哈霓玛阿都|1190002','佳特土|1190003','加途|1190004',),
    '日本' => array('东京|1250017','神户|1250052','名古屋|1250040','大阪|1250010','长崎|1250006','京都|1250033','横滨市|1250070','佐世保|1250069','札幌|1250068','宇都宫|1250067','一宫|1250066','岩国|1250065','旭川|1250064','熊本|1250063','新泻|1250062','行桥|1250061','小樽|1250060','仙台|1250059','相模原|1250058','唐津|1250057','松任|1250056','松户|1250055','四日|1250054','水户|1250053','山口|1250051','上越|1250050','森冈|1250049','日立|1250048','秋田|1250047','青森|1250046','千叶|1250045','尼崎|1250044','能代|1250043','奈良|1250042','米子|1250041','茂木|1250039','鹿儿岛|1250038','铃鹿|1250037','金泽|1250036','津市|1250035','静冈县|1250034','姬路|1250032','江别|1250031','甲府|1250030','和歌山|1250029','鹤冈|1250028','函馆|1250027','广岛|1250026','宫崎|1250025','高松|1250024','冈山|1250023','冈崎|1250022','冈谷|1250021','富山|1250020','福冈|1250019','丰中|1250018','东大阪|1250016','町田|1250015','德山|1250014','大垣|1250013','大牟田|1250012','大宫|1250011','春日井|1250009','冲绳|1250008','长野|1250007','滨松|1250005','北九州|1250004','八王子|1250003','岸和田|1250002','阿久根|1250001','高知|1250071','那霸|1250072','网走|1250073','秩父|1250074','福江|1250075','福井|1250076','福岛|1250077','福山|1250078','八户|1250079','秋港|1250080','彦根|1250081','平户|1250082','日田|1250083','人吉市|1250084','饭田|1250085','饭冢|1250086','石卷|1250087','岩见泽|1250088','胜浦|1250089','熊谷|1250090','吴市|1250091','钏路|1250092','前桥|1250093','舞鹤|1250094','枕崎|1250095','松江|1250096','松本|1250097','松山|1250098','三岛由纪夫|1250099','宫古|1250100','都城|1250101','纹别市|1250102','室兰|1250103','陆奥|1250104','名护市|1250105','根室|1250106','日高|1250107','延冈|1250108','带广|1250109','大船渡|1250110','大分|1250111','尾鹫|1250112','留萌|1250113','佐贺|1250114','坂田|1250115','下关|1250116','晋如|1250117','宿毛|1250118','洲本|1250119','诹访|1250120','多度津|1250121','高山|1250122','立山|1250123','徳岛|1250124','苫小牧|1250125','鸟取|1250126','丰冈|1250127','敦贺|1250128','津山|1250129','牛深市|1250130','宇和岛|1250131','稚内|1250132','山形|1250133','横须贺|1250134','油津|1250135','相川|1250136','网代|1250137','阿苏火山|1250138','父岛|1250139','銚子市|1250140','枝幸郡|1250141','富士山|1250142','深浦|1250143','伏木|1250144','羽幌町|1250145','伊良湖|1250146','西表岛|1250147','石廊崎|1250148','石垣岛|1250149','硫磺岛|1250150','严原|1250151','轻井泽|1250152','河口湖|1250153','北见枝幸|1250154','久米岛|1250155','倶知安町|1250156','南大东村岛|1250157','南鸟岛|1250158','三宅岛|1250159','宫古岛|1250160','冲永良部|1250161','御前崎市|1250162','小名滨|1250163','大岛渚|1250164','料理|1250165','西乡|1250166','清水|1250167','潮岬|1250168','白河|1250169','寿都郡|1250170','高田|1250171','种子岛|1250172','立野|1250173','浦河郡|1250174','轮岛|1250175','若松|1250176','屋久岛|1250177','与那国岛|1250178',),
    '阿拉伯联合酋长国' => array('迪拜|1020003','阿布扎比|1020002','沙迦|1020006','拉斯海玛|1020005','乌姆盖万|1020007','富查伊拉|1020004','阿治曼|1020001',),
    '土耳其' => array('伊斯坦布尔|1310043','安塔利亚|1310011','费特希耶|1310072','宗古尔达克|1310045','伊兹密尔|1310044','伊斯帕尔塔|1310042','伊斯肯德伦|1310041','伊内格尔|1310040','西利夫克|1310039','锡尔特|1310038','乌沙克|1310037','乌拉|1310036','特拉布宗|1310035','泰基尔达|1310034','塔尔苏斯|1310033','萨姆松|1310032','乔鲁姆|1310031','恰纳卡莱|1310030','帕莫卡莱|1310029','内夫谢希尔|1310028','梅尔济丰|1310027','马纳夫加特|1310026','拉普塞基|1310025','库沙达瑟|1310024','科尼亚|1310023','克鲁兹卡雷|1310022','克尔谢希尔|1310021','杰伊汉|1310020','加济安泰普|1310019','菲尼克|1310018','迪亚巴克尔|1310017','布尔萨|1310016','比斯米尔|1310015','贝加盟|1310014','班德尔玛|1310013','巴勒克希尔|1310012','安卡拉|1310010','阿纳穆尔|1310009','埃斯基谢希尔|1310008','埃拉泽|1310007','埃尔祖鲁姆|1310006','埃尔津詹|1310005','埃迪尔内|1310004','艾登|1310003','阿菲永|1310002','阿达纳|1310001','阿达帕扎勒|1310046','阿德亚曼省|1310047','Agri|1310048','阿克希萨|1310049','阿克萨赖|1310050','阿克谢希尔|1310051','阿拉尼亚|1310052','阿尔达汉|1310053','阿尔特温|1310054','艾瓦勒克|1310055','巴坦|1310056','巴伊布尔特|1310057','比莱吉克|1310058','宾戈尔|1310059','博德鲁姆|1310060','博卢|1310061','博兹贾阿达|1310062','布尔杜尔|1310063','切什梅|1310064','乔尔卢|1310065','达拉曼|1310066','达特恰|1310067','代尼兹利|1310068','迪基利|1310069','迪兹杰|1310070','密特|1310071','吉雷松|1310073','格克切岛|1310074','哈卡里省|1310075','霍帕|1310076','伊迪尔|1310077','伊内博卢|1310078','卡拉比克|1310079','卡拉曼|1310080','卡尔斯|1310081','卡斯|1310082','卡斯塔莫努|1310083','基利斯|1310084','克尔克拉雷利|1310085','屈塔希亚|1310086','马尼萨|1310087','马尔丁|1310088','马尔马里斯|1310089','穆拉|1310090','尼代|1310091','奥尔杜|1310092','奥斯曼尼耶省|1310093','里泽|1310094','尚勒乌尔法|1310095','锡诺普|1310096','锡瓦斯|1310097','塔特万|1310098','托卡特|1310099','通杰利|1310100','亚洛瓦|1310101','阿达纳·因斯里克|1310102','阿辛奇|1310103','阿克罗蒂里|1310104','博德鲁姆米拉斯|1310105','昌克勒|1310106','埃雷利·科尼亚|1310107','埃森博阿|1310108','伊特梅斯格|1310109','格尔居克|1310110','居米什哈|1310111','鸽子谷|1310112','伊斯坦布尔·阿塔图尔克|1310113','开塞利|1310114','库姆克依|1310115','马拉蒂亚|1310116','梅尔辛|1310117','萨勒耶尔|1310118',),
    '以色列' => array('耶路撒冷|1410022','霍隆|1410011','海法|1410010','巴特亚姆|1410004','特拉维夫|1410020','约特瓦塔|1410023','亚姆村|1410021','佩塔提克瓦|1410019','内谢尔|1410018','内坦亚|1410017','纳哈里亚|1410016','莫茨金村|1410015','里雄来锡安|1410014','雷霍沃特|1410013','拉马特甘|1410012','海尔兹利亚|1410009','措瓦|1410008','比亚利克村|1410007','贝内贝拉克|1410006','贝尔谢巴|1410005','阿塔村|1410003','阿克里|1410002','埃拉特|1410001','北阿什杜德|1410024','贝尔谢巴市|1410025','奥华特|1410026',),
    '新加坡' => array('新加坡|1350005','武吉知马|1350004','武吉班让|1350003','实龙岗|1350002','巴耶利|1350001',),
    '韩国' => array('首尔|1120018','济州岛|1120019','釜山|1120005','济州|1120020','仁川|1120011','大邱|1120003','西归浦|1120045','春川|1120002','清州|1120022','原州|1120017','倭馆|1120016','蔚珍|1120015','蔚山|1120014','水原|1120013','束草|1120012','群山|1120010','秋风岭|1120009','浦项|1120008','晋州|1120007','筏桥|1120004','安东|1120001','光州|1120021','大田|1120023','全州|1120024','马山|1120025','汶山|1120026','尚州|1120027','白翎岛|1120028','保宁|1120029','铁原|1120030','忠州|1120031','大关岭|1120032','东豆川|1120033','东海|1120034','江陵|1120035','居昌|1120036','高敞|1120037','龟尾|1120038','黑山岛|1120039','利川|1120040','井邑市|1120041','珍岛|1120042','木浦|1120043','南原|1120044','城山|1120046','瑞山|1120047','顺天|1120048','统营|1120049','郁陵岛|1120050','莞岛|1120051','宁越|1120052','丽水|1120053',),
    '泰国' => array('曼谷|1300016','普吉岛|1430016','清迈|1300026','芭提雅|1300071','苏梅岛|1300030','甲米|1300040','庄他武里（尖竹汶）|1300036','乌汶|1300035','他朗|1300034','泰国芒|1300033','素攀武里|1300032','索叻他尼|1300031','宋卡府|1300029','沙木沙空|1300028','沙没巴干|1300027','彭世洛|1300025','帕尧|1300024','帕府市大城府|1300023','南奔|1300022','那拉提瓦|1300021','莫达汉府|1300020','湄索|1300019','湄林|1300018','湄宏顺|1300017','玛哈沙拉堪|1300015','罗富里|1300014','黎逸|1300013','孔敬|1300012','空巴吞|1300011','华欣|1300010','呵叻|1300009','合艾|1300008','春武里|1300007','春蓬|1300006','猜也蓬|1300005','碧武里|1300004','北碧府|1300003','巴武|1300002','班沙拉披|1300001','芭堤雅|1300037','亚兰|1300038','卡马拉塞|1300039','南邦|1300041','北大年府|1300042','碧差汶|1300043','帕府|1300044','拉廊|1300045','罗勇|1300046','越定男|1300047','梭桃邑|1300048','沙敦|1300049','素可泰|1300050','素林|1300051','达克|1300052','腾县|1300053','董里|1300054','程逸|1300055','曼谷港|1300056','武里南|1300057','清莱|1300058','廊曼|1300059','甲民武里|1300060','甘烹碧|1300061','考斯昌|1300062','哥颂披柿|1300063','华富里|1300064','美撒良|1300065','美索|1300066','那空拍侬|1300067','那空沙旺|1300068','娘隆|1300069','廊开|1300070','巴真武里|1300072','沙沙功那空|1300073','沙缴市|1300074','塔库巴|1300075','乌隆|1300076','蕴朋|1300077','威齐伯里|1300078',),
    '尼泊尔' => array('加德满都|1240002','博卡拉|1240003','巴克塔普尔|1240001','Dadeldhura|1240004','Dhankuta|1240005','Jumla|1240006','当斯|1240007','丹尔加希|1240008','奥卡尔东加|1240009','苏尔凯德|1240010','塔普勒琼|1240011',),
    '缅甸' => array('仰光|1230004','曼德勒|1230003','密支那|1230013','丹老|1230032','毛淡棉|1230034','帕本|1230036','勃生|1230002','勃固|1230001','敏布|1230005','马德岛|1230006','仁安羌|1230007','当达|1230009','皎漂|1230011','内比都|1230012','腊戌|1230014','八莫|1230015','土瓦|1230016','马乌宾|1230017','莫莱县|1230018','密铁拉|1230019','蒙育瓦|1230020','彬马那|1230021','雪布|1230022','实兑|1230023','东枝|1230024','可可岛|1230025','坎迪县|1230026','霍马林|1230027','帕安|1230028','葛礼瓦|1230029','卡萨|1230030','景栋|1230031','明加拉当|1230033','良乌县|1230035','卑谬|1230037','葡萄|1230038','丹兑|1230039','达雅瓦底|1230040','东吁|1230041','维多利亚角|1230042',),
    '马来西亚' => array('吉隆坡|1200011','马六甲|1200013','关丹|1200008','瓜拉登嘉楼|1200029','纳闽|1200031','怡保|1200020','昔加末|1200019','实兆远|1200018','诗巫|1200017','山打根|1200016','柔佛州新山市|1200015','民都鲁|1200014','吉隆坡龙运|1200012','古晋|1200010','古达|1200009','瓜拉丁加奴|1200007','亚庇|1200006','芙蓉|1200005','丰盛港|1200004','斗湖|1200003','成邦江|1200002','巴株巴辖|1200001','沙巴州|1200035','新山|1200021','巴特沃斯|1200023','居銮|1200024','美里|1200025','亚罗士打|1200026','金马伦高原|1200027','朱宾|1200028','瓜拉吉赖|1200030','兰卡威岛|1200032','八打灵|1200033','淡马鲁|1200034',),
    '斯里兰卡' => array('科伦坡|1280001','康提|1280007','亭可马里|1280002','阿努拉德普勒|1280003','巴杜勒|1280004','拜蒂克洛|1280005','贾夫纳|1280006','库鲁内格勒|1280008','普特拉姆|1280009','拉特纳普勒|1280010','瓦武尼亚|1280011','班德勒韦勒|1280012','汉班托塔|1280013','卡图那亚克|1280014','马纳尔|1280015','穆莱蒂武|1280016','波士维尔|1280017','拉特默勒讷|1280018',),
    '沙特阿拉伯' => array('麦加|1270010','利雅得|1270008','吉达|1270004','胡富夫|1270016','塔伊夫|1270023','塔布克|1270012','塞卡凯|1270011','麦地那|1270009','拉夫哈|1270007','拉比格|1270006','吉赞|1270005','代瓦迪米|1270003','阿尔阿萨|1270002','艾卜哈|1270001','哈伊勒|1270013','布赖代|1270014','达曼|1270015','奈季兰|1270017','哈达|1270019','奥尔朱夫|1270020','朱拜勒|1270021','阿尔卡夫及|1270022','沃季|1270024','比舍|1270025','季赞|1270026','吉达港|1270027','迈纳|1270028','穆兹达里法|1270029',),
    '菲律宾' => array('马尼拉|1090019','达沃市|1090011','拉瓦格|136060100','杜马格特|136510100','黎牙实比|1090016','塔比拉兰|136520100','科伦|136380100','伊洛伊洛|1090030','武端|1090029','塔亚巴斯|1090028','塔克洛班|1090027','宿务市|1090026','苏里高|1090025','桑托斯将军城|1090024','三宝颜|1090023','帕加迪安|1090022','梅卡瓦延|1090021','马斯巴特|1090020','马洛洛斯|1090018','罗哈斯|1090017','利巴岗|1090015','奎松市|1090014','甲万那端|1090013','第波罗|1090012','达特|1090010','丹达|1090009','打拉|1090008','拉古板|1090007','碧瑶|1090006','邦板牙|1090005','巴科奥尔|1090004','奥卢丹牙岛|1090003','奥隆阿波|1090002','阿拉巴特|1090001','比拉克|136360100','土格加劳|136080100','科学园|136250100','桑莱岬|136240100','旧金山|136320100','圣荷西|136390100','朗布隆|136400100','王子港|136480100','帕拉南|136700100','诺拉站|136110100','穆诺斯|136170100','马拉巴拉|136620100','麦克坦|136540100','马阿辛|136550100','伦比亚机场|136600100','拉巫格|136530100','霍洛岛|136670100','伊特巴亚特|111840100','英凡达|136290100','海纳图安|136650100','圭乌安|136470100','三投斯将军市|136690100','费尔南多航空基地|136310100','库约|136490100','卡巴洛甘|136440100','卡塔曼|136430100','卡西古兰|136210100','加拉彦|136020100','卡拉潘|136260100','卡加延德塔威塔威|136660100','卡加延德寨多|136610100','博龙岸|136460100','阿帕里|136070100','安布隆|136270100','普林塞萨港|1090032','博斯科|1090033','那端|1090034','塔克洛班市|1090036',),
    '柬埔寨' => array('暹粒市|1140004','金边|1140001','暹粒|1140009','西哈努克港|1140002','贡布|1140006','马德望|1140003','隆发|1140005','磅湛|1140007','格罗戈|1140008','上丁省|1140010','柴桢|1140011',),
    '约旦河西岸' => array('拉马拉|1450003','盖兰迪耶|1450002','伯利恒|1450001',),
    '约旦' => array('祖韦扎|1440004','亚喀巴|1440003','萨菲|1440002','安曼|1440001','佩特拉|1440005','斋福尔|1440006','杰利科|1440007','马安|1440008','马夫拉克|1440009','塔菲拉|1440010',),
    '伊朗' => array('扎黑丹|1400023','扎尔甘|1400022','赞詹|1400021','亚兹德|1400020','设拉子|1400019','梅赫里兹|1400018','马斯吉德苏来曼|1400017','马什哈德|1400016','克尔曼|1400015','卡纳维斯|1400014','戈姆|1400013','戈尔甘|1400012','德黑兰|1400011','道戈巴但|1400010','大不里士|1400009','博季努尔德|1400008','比尔詹德|1400007','班娥港|1400006','班娥安扎里|1400005','阿扎尔沙赫尔|1400004','阿瓦士|1400003','阿拉克|1400002','阿巴丹|1400001','阿巴斯港|1400024','阿巴代|1400025','阿哈尔|1400026','巴姆|1400027','伊拉姆|1400028','伊朗沙赫尔|1400029','卡尚|1400030','克尔曼沙阿|1400031','霍拉马巴德|1400032','雷什特|1400033','萨卜泽瓦尔|1400034','萨南达季|1400035','萨拉赫斯|1400036','塞姆南|1400037','阿鲁德|1400038','锡尔延|1400039','塔巴斯|1400040','扎布尔|1400041','阿布穆萨岛|1400042','阿瓦兹|1400043','阿德比尔|1400044','伦格港|1400045','班达阿巴斯|1400046','布什尔|1400047','加兹温|1400048','哈麦丹|1400049','伊斯法罕|1400050','贾斯克|1400051','哈格岛|1400052','豪尔|1400053','霍伊|1400054','基什岛|1400055','克拉那克|1400056','马库|1400057','马拉盖|1400058','瑙沙赫尔|1400059','乌尔米耶|1400060','拉姆萨尔|1400061','萨拉|1400062','萨拉万|1400063','托儿巴特海达里耶|1400064',),
    '伊拉克' => array('提克里特|1390010','摩苏尔|1390004','巴士拉|1390003','巴格达|1390001','拉马迪|1390024','希拉|1390006','纳杰夫|1390005','巴古拜|1390002','哈迪塞|1390007','基尔库克|1390008','辛贾尔镇|1390009','阿玛拉|1390011','亚拿|1390012','巴德拉|1390013','拜伊吉|1390014','巴斯拉港|1390015','迪瓦尼耶|1390016','海拉|1390017','卡尔巴拉|1390018','哈奈根|1390019','库特|1390020','纳贾夫|1390021','纳西里耶|1390022','拉发雷尔|1390023','鲁特拜|1390025','撒拉丁|1390026','萨马沃|1390027','索兰|1390028','图兹|1390029','扎胡|1390030',),
    '也门' => array('亚丁|1380007','谢赫欧斯曼|1380006','塔伊兹|1380005','姆凯拉斯|1380004','拉赫季|1380003','盖勒钡瓦齐尔|1380002','盖达|1380001','萨纳|1380008','穆卡拉|1380009','哈杰|1380010','伊卜|1380011','萨那|1380012','阿塔克|1380013','扎马尔|1380014','荷台达|1380015','马利卜|1380016','摩卡|1380017','穆赫拉斯|1380018','里雅恩|1380019','萨达|1380020','索科特拉岛|1380021','赛莫德|1380022',),
    '亚美尼亚' => array('久姆里|1370002','埃里温|1370001','瓦纳佐尔|223120100','绍尔哈|223280100','伊杰万|223150100','嘉瓦|223270100','法坦|223250100','阿什塔拉克|223210100','阿塔沙特|223290100','阿尔马维尔|223230100','阿雷尼|223330100','阿勒山|223320100','安伯|223190100','阿马西亚|223040100',),
    '叙利亚' => array('大马士革|1360001','阿勒颇|1360006','哈马|1360009','拉卡|1360013','伊德利卜|1360005','霍姆斯|1360004','富尔格卢斯|1360003','德拉雅|1360002','德尔佐尔|1360007','艾特利亚|1360008','卡米什利|1360010','拉塔基亚|1360011','巴尔米拉|1360012','塔尔图斯|1360014',),
    '乌兹别克斯坦' => array('铁尔梅兹|1340010','塔什干|1340009','撒马尔罕|1340008','布哈拉|1340002','乌尔根奇|1340011','普斯凯姆|1340007','努库斯|1340006','纳曼干|1340005','卡塔库尔干|1340004','费尔干纳|1340003','阿尔马雷克|1340001','卡拉库耳|1340012','恰尔达拉|1340013','查尔哲夫|1340014','金武|1340015','吉扎克|1340016','伊斯法拉|1340017','喀什|1340018','浩罕|1340019','昆格勒|1340020','努拉塔|1340021','塔姆德|1340022',),
    '文莱' => array('斯里巴加湾市|1330001',),
    '土库曼斯坦' => array('阿什哈巴德|1320001','乌夫拉|1320009','土库曼巴什|1320008','萨拉戈特|1320007','卡拉卡拉|1320006','捷詹|1320005','达尔甘阿塔|1320004','别济梅恩|1320003','阿什哈巴德凯希|1320002','马雷|1320010','土库曼纳巴德|1320011','卡卡|1320012','穆尔加布|1320013','巴依拉马利|1320014','恰尔尚加|1320015','达什克霍夫兹|1320016','厄本特|1320017','加兹甘|1320018','克尔基|1320019','涅比特达格|1320020',),
    '塔吉克斯坦' => array('杜尚别|1290001','鲁雄|1290009','达沃滋|1290003','伊什卡希姆|1290004','霍罗格|1290005','库利亚布|1290006','库尔干秋别|1290007','本吉肯特|1290008',),
    '塞浦路斯' => array('帕福斯|1260006','法马古斯塔|1260001','特罗|1260007','尼科西亚|1260005','利马索尔|1260004','拉纳卡|1260003','克蒂马|1260002',),
    '孟加拉' => array('锡尔赫特|1220008','库尔纳|1220005','吉大港|1220003','达卡|1220009','勐腊|1220028','兰加马蒂|1220030','坦盖尔|1220007','纳拉扬甘杰|1220006','杰索尔|1220004','博格拉|1220002','巴瑞索|1220001','波拉|1220010','库米拉|1220011','迪纳杰普尔|1220012','福里德布尔|1220013','芬尼|1220014','杰马勒布尔|1220015','马达里布尔|1220016','迈门辛|1220017','拉杰沙希|1220018','朗布尔|1220019','赛伊德布尔|1220020','松迪布|1220021','萨德基拉|1220022','纳夫|1220023','坚德布尔|1220024','朱瓦当加|1220025','哈蒂亚|1220026','库图布迪亚|1220027','博杜阿卡利|1220029','斯里曼高|1220031',),
    '蒙古' => array('乌兰巴托|1210008','乌里雅苏台|1210007','达尔汗|1210011','西乌尔特|1210009','马塔德|1210006','曼达尔戈壁|1210005','卡勒克戈尔|1210004','呼塔格|1210003','达什巴勒巴尔|1210002','阿尔达尔|1210001','额尔登特|1210010','巴彦洪戈尔|1210012','布尔干|1210013','托孙臣格勒|1210014','车尔勒格|1210015','乌兰固木|1210016','阿尔泰|1210017','阿尔拜赫雷|1210018','巴伦图伦|1210019','巴彦敖包|1210020','巴彦布拉格|1210021','乔巴山|1210022','达兰扎达嗄德|1210023','额尔德尼查干|1210024','胡季尔特|1210025','曼提|1210026','曼达勒戈壁|1210027','慕仁|1210028','赛音山达|1210029','塔里亚兰|1210030','朝格特敖包|1210031','扎门乌德|1210032',),
    '黎巴嫩' => array('贝鲁特|1180001','朱尼耶|1180002',),

    '老挝' => array('琅勃拉邦|1170005','万象|1170001','巴色|1170007','沙湾拿吉|1170002','沙拉湾|1170009','塞诺|1170011','他曲|1170003','奔讷|1170004','乌多姆塞|1170006','帕克松|1170008','沙耶武里|1170010',),
    '科威特' => array('科威特|1160001','科威特城|1160002','实验农场|1160006','艾哈迈迪|1160004','舒瓦克|1160008','瓦巴|1160009','阿卜杜利|1160003','巴比延|1160005','费拉卡岛|1160007',),
    '卡塔尔' => array('多哈|1150001','多哈港|1150002',),
    '吉尔吉斯斯坦' => array('比什凯克|1130001','奥什|1130002','纳伦|1130003','塔拉斯|1130004','托克马克|1130005',),
    '哈萨克斯坦' => array('阿特劳|1110004','阿拉木图|1110002','阿斯塔纳|1110021','阿克套|1110024','乌拉尔斯克|1110018','什姆肯特|1110013','巴甫洛达尔|1110005','厄斯克门|1110022','克孜勒奥尔达|1110009','塔拉兹|1110023','朱萨雷|1110020','叶西尔|1110019','乌尔贾尔|1110017','铁米尔套|1110016','塔尔戈哈尔|1110015','斯捷普诺戈尔斯克|1110014','塞贡蒂|1110012','鲁扎耶夫卡|1110011','库斯塔奈|1110010','卡拉干达|1110008','彼得罗巴浦洛夫斯克|1110007','巴卡纳斯|1110006','阿特巴萨尔|1110003','阿克穆拉|1110001','里德|1110026','铁米尔|1110027','土耳其斯坦|1110028','扎尔肯特|1110029','阿库杜克|1110030','阿克托比|1110031','巴尔喀什|1110032','伯雷克|1110033','恰帕耶夫|1110034','江贝提|1110035','舍甫琴柯堡|1110036','卡扎林斯克|1110037','科什阿加赤|1110038','克孜勒|1110039','奥尔斯克|1110040','欧塔|1110041','罗迪诺|1110042','山姆|1110043','塞米巴拉金斯克|1110044','泰帕克|1110045','图罗恰克|1110046','扎尔特尔|1110047','杰兹卡兹甘|1110048','兹利克哈|1110049','兹梅伊诺戈尔斯克|1110050',),
    '格鲁吉亚' => array('巴统|1100004','第比利斯|1100001','库塔伊西|1100007','塔希尔|1100012','泰拉维|1100009','祖格迪迪|1100010','鲁斯塔维|1100002','阿哈尔齐赫|1100003','博尔尼西|1100005','哥里|1100006','波蒂|1100008','杰尔宾特|1100011',),
    '朝鲜' => array('平壤|1080006','元山|1080013','沙里院|1080008','开城|1080004','中江|1080018','新义州|1080012','新浦|1080011','熙川|1080010','咸兴|1080009','三池渊|1080007','南浦|1080005','江界|1080003','惠山|1080002','安居|1080001','清津|1080014','海州|1080015','圭城|1080016','长津|1080017','金策|1080019','丰山|1080020','平康|1080021','龙渊|1080022','先锋|1080023','水丰|1080024','阳德|1080025',),
    '不丹' => array('廷布|1070001',),
    '巴林' => array('麦纳麦|1060001',),
    '巴基斯坦' => array('卡拉奇|1050007','伊斯兰堡|1050020','Skardu|1050043','罕萨|1050052','白沙瓦|1050002','拉合尔|1050011','奎达|1050010','木尔坦|1050014','Gilgit|1050029','章萨德尔|1050021','谢胡布尔|1050019','苏库尔|1050018','萨希瓦尔|1050017','萨戈达|1050016','讷瓦布沙阿|1050015','马尔丹|1050013','拉瓦尔品第|1050012','科哈特|1050009','卡苏尔|1050008','吉尼奥德|1050006','古杰拉特|1050005','古杰兰瓦拉|1050004','费萨拉巴德|1050003','奥卡拉|1050001','Badin|1050022','Bahawalnagar|1050023','Bahawalpur|1050024','Bannu|1050025','Barkhan|1050026','Cherat|1050027','Dalbandin|1050028','Jacobabad|1050030','Jhelum|1050031','Jiwani|1050032','Kalat|1050033','Mangla|1050034','Mianwali|1050035','Murree|1050036','Muzaffarabad|1050037','Pasni|1050038','Risalpur|1050039','Rohri|1050040','Sialkot|1050041','Sibi|1050042','杜尔伯德|1050044','佐布|1050045','阿斯多|1050046','巴拉科特|1050047','本及|1050048','吉德拉尔|1050049','瓜达尔|1050050','古比斯|1050051','伊斯兰堡市|1050054','章|1050055','卡拉姆|1050056','胡兹达尔|1050057','拉合尔市|1050058','克昆迪|1050059','本杰古尔|1050060','帕拉奇纳|1050061','帕坦|1050062','拉沃拉科特|1050063',),
    '阿塞拜疆' => array('萨利亚纳|224610100','巴库|1040001','乌古斯|224060100','巴尔达|224340100','夏奇|1040003','连科兰|224800100','阿格达姆|224510100','梅格里|224730100','占贾|1040002','扎尔多布|224350100','塔乌兹|224040100','塔塔|224330100','沙鲁尔|224460100','沙姆基尔|224160100','萨比拉巴德|224360100','卡巴拉|224190100','奥尔杜巴德|224720100','涅夫捷恰拉|224640100','纳希切万|224650100','纳布兰|224070100','明盖恰乌尔|224200100','列里克|224790100','拉钦|224550100','丘尔达米尔|224370100','杰姆克|224490100','古巴|224100100','盖奥克恰伊|224230100','戈里斯|224710100','凯达贝克|224150100','达什卡桑|224310100','比利亚苏瓦尔|224760100','阿斯塔拉|224810100','舒沙|1040004','苏姆盖特|1040005',),
    '阿曼' => array('马特拉|1030006','马斯喀特|1030005','海塞卜|1030003','Sur|1030013','塞拉莱|1030009','奈兹瓦|1030007','塔卡|1030008','迈尔穆勒|1030004','布赖米|1030002','阿斯布|1030001','Adam|1030010','Bahla|1030011','Ibra|1030012','迪贝|1030014','杜古姆|1030015','费胡德|1030016','海塞卜港|1030017','马西拉|1030018','迈纳塞拉莱|1030019','盖勒哈特|1030020','鲁斯塔克|1030021','塞马伊勒|1030022','塞迈里|1030023',),
    '阿富汗' => array('喀布尔|1010002','赫拉特|1010001','巴米扬|155250100','坎大哈|1010003','昆都士|155080100','马扎里沙里夫|1010004','贾拉拉巴德|155320100','巴格兰农场|155090100','扎兰季|155410100','加慈尼|155340100','提林库特|155380100','辛丹德|155330100','萨罗比|155290100','北沙浪|155170100','洛加尔省|155280100','拉格曼|155300100','海拉顿|155100100','加德兹|155350100','法拉赫|155370100','恰赫恰兰|155240100','安德胡伊|155040100','霍斯特|155360100','丹德|1010005','南沙浪|1010006',),
    '东帝汶' => array('帝力|1460020','包考|1460021','维克克|1460022',),
  ),
  
  '欧洲' => array(
    '奥地利' => array('维也纳|2050069','维也纳新城|2050070','因斯布鲁克|2050075','萨尔茨堡|2050054','林茨|2050043','祖尔斯|2050079','詹纳斯多夫|2050078','尤登堡|2050077','伊施格尔|2050076','伊姆斯特|2050074','沃尔夫斯堡|2050073','温肯|2050072','温迪施加斯滕|2050071','魏德霍芬河畔伊布斯|2050068','魏德霍芬河畔塔亚|2050067','魏茨|2050066','图尔恩|2050065','塔姆斯维格|2050064','斯太尔|2050063','施瓦茨|2050062','施托克劳|2050061','施泰雷格|2050060','施拉德明|2050059','沙伊布斯|2050058','上瓦特|2050057','上普伦多尔夫|2050056','塞尔斯博格|2050055','普赫贝格|2050053','佩尔戈|2050052','穆劳|2050051','穆尔河畔布鲁克|2050050','莫德灵|2050049','密斯特巴赫|2050048','米尔茨楚施拉格|2050047','梅尔克|2050046','马特斯|2050045','罗伊特|2050044','利林费尔德|2050042','利岑|2050041','劳里斯|2050040','兰纳克|2050039','莱塔河畔布鲁克|2050038','莱布尼茨|2050037','莱昂丁|2050036','库夫施泰因|2050035','克尼特尔费尔德|2050034','克洛斯特新堡|2050033','克拉根福|2050032','科恩堡|2050031','卡普芬贝格|2050030','居辛|2050029','基茨比厄尔|2050028','黑马戈尔|2050027','哈莱恩|2050026','格蒙登|2050025','格里斯科尔琴|2050024','格兰特科恩|2050023','格莱斯多夫|2050022','格拉茨|2050021','甘瑟恩多夫|2050020','弗克拉布鲁克|2050019','弗尔克马克特|2050018','菲拉赫|2050017','菲尔斯滕费尔德|2050016','恩斯|2050015','多恩比恩|2050014','德意志兰兹博格|2050013','茨韦特尔城|2050012','采尔特维格|2050011','布鲁登茨|2050010','布雷根茨|2050009','比绍夫斯霍芬|2050008','滨湖新锡德尔|2050007','滨湖采尔|2050006','巴特伊施尔|2050005','巴特霍夫加施泰因|2050004','巴特格莱兴贝格|2050003','艾森斯塔特|2050002','埃弗丁|2050001','阿姆施泰滕|2050080','巴登|2050081','费尔德巴赫|2050082','费尔德基希|2050083','弗赖施塔特|2050084','弗里萨赫|2050085','延巴赫|2050086','兰德克|2050087','朗根洛伊斯|2050088','利恩茨|2050089','月亮湖|2050090','波伊斯多夫|2050091','拉德施塔特|2050092','雷茨|2050093','阿亨基希|2050094','巴特加施泰因|2050095','布兰德|2050096','布伦纳|2050097','多瑙费尔德|2050098','费尔德基兴|2050099','费施巴赫|2050100','格洛森哲斯多夫|2050101','霍尔茨高|2050102','基茨比尔|2050103','克雷姆斯|2050104','克雷姆斯明斯特|2050105','克里姆勒|2050106','洛费尔|2050107','玛丽亚草甸|2050108','迈尔霍芬|2050109','米尔施塔特|2050110','诺伊马克特|2050111','诺伊希德尔|2050112','奥伯谷尔格|2050113','上陶恩|2050114','帕茨科托弗|2050115','帕特沙赫|2050116','兰舍芬|2050117','罗尔巴赫|2050118','舍尔丁|2050119','泽费尔德|2050120','塞贝斯多夫|2050121','塞默灵|2050122','锡利安|2050123','松布利克|2050124','风怒角|2050125',),
    '爱尔兰' => array('都柏林|2030012','利默里克|2030026','科克|2030018','伊登德里|2030041','香农河畔卡里克|2030040','塔拉特|2030039','舒尔河畔卡里克|2030038','舍考克|2030037','帕拉斯金利|2030036','纽马基特弗格斯|2030035','莫伊库伦|2030034','米德尔顿|2030033','马林加|2030032','罗斯莱尔|2030031','罗斯克雷|2030030','洛赫雷|2030029','洛港|2030028','灵厄斯基迪|2030027','莱伊什港|2030025','莱特肯尼|2030024','莱克斯利普|2030023','克洛纳基尔蒂|2030022','克鲁克黑文|2030021','克朗斯|2030020','克莱尔莫里斯|2030019','卡斯尔马特|2030017','卡斯尔巴|2030016','卡里克马克罗斯|2030015','卡里加林|2030014','基拉迪瑟特|2030013','邓莱里|2030011','德罗伊达|2030010','波特马诺克|2030009','贝尔马利特|2030008','巴林克利格|2030007','巴利纳斯洛|2030006','巴利马洪|2030005','巴利卡纽|2030004','阿斯利|2030003','奥兰莫尔|2030002','阿克洛|2030001','戈尔韦|2030042','马林角|2030043','穆林加尔|2030044','谢尔金岛|2030045','瓦伦蒂亚天文台|2030046',),
    '比利时' => array('那慕尔|2080012','根特|2080009','布鲁塞尔|2080006','安特卫普|2080005','奥斯坦德|2080025','列日|2080028','于克勒|2080018','小布罗赫尔|2080017','维尔福德|2080016','圣尼古拉斯|2080015','沙勒罗瓦|2080014','瑟兰|2080013','列日市|2080011','科克赛德|2080010','弗洛雷讷|2080008','登德尔蒙德|2080007','安德莱赫特|2080004','艾瓦耶|2080003','埃斯塔勒|2080002','埃尔森博恩|2080001','博弗尚|2080019','布拉斯哈特|2080020','谢夫儿|2080021','迪彭贝克|2080022','亨克|2080023','梅勒|2080024','热帖|2080026','泽布吕赫|2080027','沙勒罗瓦·戈斯利|2080029','蒙特瑞奇|2080030','塞梅尔扎克|2080031','休伯特|2080032',),
    '保加利亚' => array('索非亚|2070013','索菲亚|2070016','普罗夫迪夫|2070009','瓦尔纳|2070015','布尔加斯|2070001','托尔布欣|2070014','斯利文|2070012','沙布拉|2070011','桑丹斯基|2070010','佩尔尼克|2070008','帕扎尔吉克|2070007','卡瓦尔纳|2070006','旧扎戈拉|2070005','戈采代尔切夫|2070004','弗拉察|2070003','布拉戈耶|2070002','德拉格曼|2070017','蒙大拿|2070018','普列文|2070019','拉兹格勒|2070020','锡利斯特拉|2070021','斯维伦格勒|2070022','维丁|2070023','伊瓦依洛|2070024','库尔德加里|2070025','洛夫奇|2070026','鲁塞|2070027','弗拉塔|2070028',),
    '希腊' => array('雅典|2370044','米科诺斯|2370027','扎金索斯|2370047','米洛斯|2370028','伊拉克利翁|2370049','萨洛尼卡|2370034','纳夫普利翁|2370029','佐格拉夫斯|2370048','伊利奥普里斯|2370046','亚历山德鲁波利斯|2370045','锡罗斯|2370043','锡基诺斯|2370042','希俄斯|2370041','沃洛斯|2370040','斯基亚奈斯|2370039','斯基罗斯|2370038','圣帕拉斯凯维|2370037','塞里福斯|2370036','塞雷|2370035','萨拉米斯|2370033','普雷韦扎|2370032','帕特雷|2370031','纳克索斯|2370030','米蒂利尼|2370026','利姆诺斯|2370025','科扎尼|2370024','克桑西|2370023','科林斯|2370022','克基拉|2370021','卡里姆诺斯|2370020','卡拉马孔|2370019','卡拉迈|2370018','卡尔帕索斯|2370017','喀迪察|2370016','基西拉|2370015','基斯诺斯|2370014','基莫洛斯|2370013','哈尔基斯|2370012','福莱甘兹罗斯|2370011','蒂诺斯|2370010','蒂洛斯|2370009','波利赫尼托斯|2370008','比雷埃夫斯|2370007','安德罗斯|2370006','阿纳菲|2370005','阿摩尔戈斯|2370004','阿拉科斯|2370003','艾奥斯|2370002','阿格里尼翁|2370001','阿尔塔|2370050','弗洛里纳|2370051','拉米亚|2370052','特里卡拉|2370053','迈索尼|2370054','雷斯蒙|2370055','萨摩斯|2370056','西提亚|2370057','塔托伊|2370058',),
    '法国' => array('巴黎|2150007','尼斯|2150042','戛纳|2150018','马赛|2150036','里昂|2150027','阿维尼翁|2150058','普罗旺斯地区艾克斯|2150045','波尔多|2150010','斯特拉斯堡|2150062','阿讷西|2150002','图卢兹|2150059','兰斯|2150022','第戎|2150014','里尔|2150061','耶尔|2150057','亚眠|2150056','维勒班|2150055','土伦|2150054','图尔宽|2150053','图尔|2150052','特鲁瓦|2150051','索恩河畔沙隆|2150050','沙勒维尔-梅济耶尔|2150049','塞日|2150048','塞纳河畔维特里|2150047','普瓦捷|2150046','佩皮尼昂|2150044','欧奈|2150043','尼姆|2150041','尼奥尔|2150040','南锡|2150039','南特|2150038','南泰尔|2150037','米卢斯|2150035','蒙彼利埃|2150034','梅斯|2150033','马恩河畔尚皮尼|2150032','吕埃尔-马尔迈松|2150031','洛里昂|2150030','鲁昂|2150029','利摩日|2150028','勒瓦卢瓦-佩雷|2150026','勒芒|2150025','雷恩|2150024','勒阿弗尔|2150023','克莱蒙费朗|2150021','坎佩尔|2150020','卡昂|2150019','加来|2150017','格勒诺布尔|2150016','敦刻尔克|2150015','德朗西|2150013','布洛涅-比扬古|2150012','布尔日|2150011','贝桑松|2150009','贝济耶|2150008','阿雅克肖|2150006','阿让特伊|2150005','昂热|2150004','昂蒂布|2150003','埃夫勒|2150001','布雷斯特|2150060','阿布维尔|2150063','阿根|2150064','阿尔比|2150065','阿朗松|2150066','奥赫|2150067','欧里亚克|2150068','欧塞尔|2150069','阿沃尔|2150070','巴斯蒂亚|2150071','贝尔热拉克|2150072','布卢瓦|2150073','卡尔维|2150074','卡尔卡松|2150075','卡庞特拉|2150076','沙特尔|2150077','沙托丹|2150078','克里尔|2150079','达克斯|2150080','迪耶普|2150081','迪纳尔|2150082','恩伯润|2150083','古尔东|2150084','伊斯特尔|2150085','朗格勒|2150086','兰里安|2150087','勒卡特|2150088','梅肯|2150089','马里尼亚讷|2150090','默伦|2150091','闷得|2150092','米洛|2150093','蒙托邦|2150094','蒙特利马尔|2150095','奥尔良|2150096','塞特|2150097','塔布|2150098','特拉普|2150099','昂贝略|2150100','比斯加奥斯|2150101','布伦|2150102','布里诺冈|2150103','布里夫|2150104','菲加里|2150105','勒布尔热|2150106','勒皮|2150107','勒图凯|2150108','里尔·莱斯坎|2150109','克瑟伊莱班|2150110','蒙德马桑|2150111','巴黎蒙苏里|2150112','罗莫朗坦|2150113','普罗旺斯地区萨隆|2150114','索兰扎拉|2150115','圣日龙|2150116',),
    '德国' => array('柏林|2130011','法兰克福|2130019','慕尼黑|2130071','斯图加特|2130058','汉堡|2130030','纽伦堡|2130070','汉诺威|2130031','杜塞尔多夫|2130017','德累斯顿|2130016','波恩|2130010','波茨坦|2130009','因戈尔施塔特|2130069','亚琛|2130068','锡根|2130067','希尔德斯海姆|2130066','伍珀塔尔|2130065','乌尔姆|2130064','维滕|2130063','威斯巴登|2130062','威廉港|2130061','特里尔|2130060','索林根|2130059','施韦因富特|2130057','什未林|2130056','萨尔茨吉特|2130055','普劳恩|2130054','普福尔茨海姆|2130053','帕德博恩|2130052','诺伊斯|2130051','门兴格拉德巴赫|2130050','美因茨|2130049','曼海姆|2130048','马格德堡|2130047','吕贝克|2130046','罗斯托克|2130045','路德维希港|2130044','勒沃库森|2130043','雷姆沙伊德|2130042','雷克林豪森|2130041','雷根斯堡|2130040','莱比锡|2130039','库克斯港|2130038','科特布斯|2130037','克雷费尔德|2130036','科布伦茨|2130035','康斯坦茨|2130034','基尔|2130033','黑尔讷|2130032','哈瑙|2130029','哈姆|2130028','海尔布隆|2130027','哈根|2130026','格赖夫斯瓦尔德|2130025','格拉|2130024','盖尔森基兴|2130023','弗伦斯堡|2130022','腓特烈港|2130021','菲林根-施文宁根|2130020','杜伊斯堡|2130018','德尔门霍斯特|2130015','茨维考|2130014','不伦瑞克|2130013','博特罗普|2130012','贝尔吉施格拉德巴赫|2130008','拜罗伊特|2130007','阿沙芬堡|2130006','奥格斯堡|2130005','奥芬堡|2130004','奥尔登堡|2130003','奥伯豪森|2130002','埃尔朗根|2130001','多特蒙德|2130072','不莱梅|2130073','伊策霍|2130074','耶弗尔|2130075','诺伊鲁平|2130076','亚历山大广场|2130077','叙尔特岛|2130078',),
    '冰岛' => array('雷克雅未克|2090002','阿库雷里|2090001','赫本|2090017','凯夫拉维克|2090019','埃伊尔斯塔济|2090005','韦斯特曼纳|2090007','斯蒂基斯霍尔米|2090024','温泉城|2090004','韦斯特曼纳群岛|2090003','格林达维克|2090006','布伦迪欧斯|2090008','博隆加维克|2090009','达拉角|2090010','达尔维克|2090011','埃拉巴几|2090012','哲居尔|2090013','格雷姆塞岛|2090014','格里姆斯塔迪尔|2090015','格兰达坦基|2090016','惠拉维德利|2090018','寇尔卡|2090020','帕特雷克斯尧德|2090021','勒伊法赫本|2090022','斯特勒伊姆维克|2090023',),
    '英国' => array('伦敦|2400011','爱丁堡|2400001','牛津|2400016','剑桥|2400029','曼彻斯特|2400013','格拉斯哥|2400005','伯明翰|2400004','利物浦|2400010','布里斯托尔|2400026','伍斯特|2400023','伍尔弗汉普顿|2400022','特伦特河畔斯托克|2400021','斯旺西|2400020','设菲尔德|2400019','奇切斯特|2400018','诺丁汉|2400017','纽波特|2400015','南安普敦|2400014','伦敦德里|2400012','莱斯特|2400009','考文垂|2400008','赫尔河畔京士顿|2400007','格洛斯特|2400006','贝尔法斯特|2400003','埃克塞特|2400002','普利茅斯|2400024','加的夫|2400025','阿伯丁|2400027','利兹|2400028','道格拉斯|2400036','威克|2400037','埃布尔达伦|2400041','阿伯珀斯|2400042','沃提夏姆|2400043','伍德福德|2400044','约维尔顿|2400045',),
    '丹麦' => array('哥本哈根|2120013','奥胡斯|2120005','赫尔辛格|2120014','罗斯基勒|2120018','比隆|2120008','奥尔堡|2120003','欧登赛|2120035','希勒罗德|2120029','韦斯勒斯|2120028','瓦尔德|2120027','托尔斯港|2120026','斯文堡|2120025','斯克吕斯楚普|2120024','斯坎讷堡|2120023','斯基弗|2120022','森纳堡|2120021','齐斯泰兹|2120020','尼克宾|2120019','兰德斯|2120017','凯隆堡|2120016','霍尔斯特布罗|2120015','弗雷德里西亚|2120012','弗雷德里克斯|2120011','菲尔斯考|2120010','布拉明|2120009','比克勒|2120007','奥斯特利尔德|2120006','奥古斯滕堡|2120004','奥本罗|2120002','埃斯比约|2120001','汉斯特霍尔姆|2120030','斯卡恩|2120031','阿尔斯列夫|2120032','阿拜德|2120033','盖瑟|2120034',),
    '挪威' => array('奥斯陆|2280002','卑尔根|2280003','特隆赫姆|2280034','斯塔万格|2280031','卡拉绍克|2280014','特罗姆瑟|2280045','旺斯内斯|2280037','瓦达尔瑞普|2280070','约维克|2280043','约松|2280042','希尔克内斯|2280041','希恩|2280040','沃尔达|2280039','韦尔达尔瑟拉|2280038','廷瑟|2280036','滕斯贝格|2280035','塔菲尤尔|2280033','松达尔|2280032','斯切达尔沙尔森|2280030','斯克勒瓦|2280029','桑讷菲尤尔|2280028','赛于达|2280027','诺托登|2280026','诺尔哈依姆森|2280025','纳姆索斯|2280024','莫斯乔恩|2280023','留坎|2280022','利勒桑|2280021','勒罗斯|2280020','莱旺厄尔|2280019','拉尔维克|2280018','孔斯温厄尔|2280017','克罗克内斯|2280016','克拉格勒|2280015','赫讷福斯|2280013','赫尔简根|2280012','哈默弗斯特|2280011','海于格松|2280010','弗洛罗|2280009','费德列斯达|2280008','德拉门|2280007','布伦讷于松|2280006','波什格伦|2280005','博茨菲尤尔|2280004','埃沃内斯|2280001','摩城|2280044','朗伊尔城|2280046','艾于什库格|2280047','哈马尔|2280048','哈尔斯塔|2280049','利勒哈默尔|2280050','瑞纳|2280051','索特兰德|2280052','斯特林|2280053','班纳克|2280054','巴尔杜福斯|2280055','熊岛|2280056','埃季岛|2280057','法格内斯|2280058','费迪厄|2280059','菲勒弗捷尔|2280060','霍恩松|2280061','凯于图凯努|2280062','米克|2280063','欧布瑞丝塔德|2280064','奥斯陆·加勒穆恩|2280065','希博滕|2280066','诺尔兰郡|2280067','瑟休森|2280068','于特西拉|2280069',),
    '乌克兰' => array('利沃夫|2350011','基辅|2350008','敖德萨|2350001','哈尔科夫|2350005','顿涅茨克|2350004','切尔诺贝利|2350038','波尔塔瓦|2350002','切尔卡瑟|2350027','卢布内|2350030','伊兹梅尔|2350020','雅尔塔|2350019','辛菲罗波尔|2350018','文尼察|2350017','苏梅|2350016','日托米尔|2350015','切尔诺夫策|2350014','切尔尼戈夫|2350013','罗夫诺|2350012','刻赤|2350010','基洛夫格勒|2350009','捷尔诺波尔|2350007','赫尔松|2350006','德罗戈贝奇|2350003','第聂伯罗彼得罗夫斯克|2350021','塞瓦斯托波尔|2350022','尼古拉耶夫|2350023','阿卢什塔|2350024','鲍里斯波尔|2350025','布洛迪|2350026','德鲁日巴|2350028','科诺托普|2350029','奥夫鲁奇|2350031','罗姆内|2350032','萨尔内|2350033','乌日哥罗德|2350034','埃佩特里|2350035','别列扎内|2350036','布里恰内|2350037','弗罗洛沃|2350039','科洛梅亚|2350040','米列罗沃|2350041','帕拉索夫卡|2350042','索罗卡|2350043','扎波罗热|2350044',),
    '塞尔维亚' => array('诺维萨德|2320012','贝尔格莱德|2320001','尼什|2320011','兹拉蒂博尔|2320019','科帕奥尼克|2320028','斯梅代雷沃|2320016','克拉列沃|2320006','Krusevac|2320021','谢尼察|2320018','瓦列沃|2320017','斯雷姆斯卡米特罗维察|2320015','丘普里亚|2320014','潘切沃|2320013','内戈廷|2320010','雷尼亚宁|2320009','拉塔利|2320008','莱斯科瓦茨|2320007','基金达|2320005','弗尔沙茨|2320004','大格拉迪什泰|2320003','查查克|2320002','Kragujevac|2320020','Sombor|2320022','弗拉涅|2320023','贝尔格莱德·苏尔津|2320024','尼沙瓦州|2320025','季米特洛夫格勒|2320026','科拉欣|2320027','洛兹尼察|2320029','尼克希奇|2320030','佩克|2320031','普列夫利亚|2320032','波德戈里察格拉德|2320033','普里什蒂纳|2320034','普里兹伦|2320035','扎布利亚克|2320036',),
    '瑞士' => array('苏黎世|2310023','卢塞恩|2310020','因特拉肯|2310039','日内瓦|2310022','伯尔尼|2310008','洛桑|2310019','格林德尔瓦尔德|2310013','采尔马特|2310009','卢加诺|2310017','巴塞尔|2310005','乌斯特|2310026','温特图尔|2310025','韦比尔|2310024','帕耶讷|2310021','洛迦诺|2310018','利斯塔尔|2310016','科尼兹|2310015','格施塔德|2310014','弗利姆斯|2310012','迪森蒂斯|2310011','措理孔|2310010','比尔|2310007','贝林佐纳|2310006','奥尔滕|2310004','阿劳|2310003','埃门布鲁克|2310002','艾格勒|2310001','阿德尔博登|2310027','阿尔特多夫|2310028','阿罗萨|2310029','布里恩茨|2310030','湛|2310031','库尔|2310032','达沃斯|2310033','艾因西德伦|2310034','英格堡|2310035','吉斯维尔|2310036','格拉鲁斯|2310037','格伦岑|2310038','迈林根|2310040','纳沙泰尔|2310042','波斯基亚沃|2310043','沙夫豪森|2310044','施库尔|2310045','锡永|2310046','斯塔比奥|2310047','菲斯普|2310048','阿尔滕莱茵|2310049','贝兹瑙|2310050','查榭哈峰|2310051','肖蒙|2310052','奇梅塔|2310053','迪森蒂斯·塞德龙|2310054','法伊|2310055','哥纳葛特山|2310056','后莱茵河|2310057','荷恩利|2310058','少女峰|2310059','洛桑市|2310060','拉绍德封|2310061','莱布施塔特|2310062','马加迪诺|2310063','蒙特罗萨|2310064','米勒贝格|2310065','纳普夫|2310066','皮拉图斯山|2310067','昆腾|2310068','桑蒂斯峰|2310069','萨梅丹|2310070','圣加仑|2310071','维瑙|2310072',),
    '芬兰' => array('赫尔辛基|2160005','图尔库|2160022','罗瓦涅米|2160041','坦佩雷|2160032','伊瓦洛|2160034','瓦萨|2160024','万塔|2160023','波尔沃|2160004','奥卢|2160003','于韦斯屈莱|2160030','穆奥尼奥|2160015','库萨莫|2160010','约马拉|2160029','约基奥因内恩|2160028','伊马特拉|2160027','伊洛曼齐|2160026','许温凯|2160025','塔米萨阿里|2160021','索丹屈莱|2160020','上维耶斯卡|2160019','塞伊奈约基|2160018','萨翁林纳|2160017','尼瓦拉|2160016','米奈迈基|2160014','莱希亚|2160013','拉赫|2160012','库桑科斯基|2160011','库奥皮奥|2160009','卡亚尼|2160008','卡拉河|2160007','凯拉瓦|2160006','奥拉瓦伊内恩|2160002','埃斯波|2160001','玛丽港|2160031','艾赫泰里|2160033','约恩苏|2160035','考哈瓦|2160036','拉提|2160037','拉彭兰塔|2160038','佩洛|2160039','波里|2160040','维塔萨里|2160042','海卢奥托|2160043','凯沃|2160044','基尔皮斯耶尔维|2160045','尼尼萨洛|2160046','尼汉姆|2160047','兰基|2160048','鲁萨洛|2160049','坦佩雷·皮尔卡拉|2160050','卡拉河乌尔科卡拉岛|2160051','于特|2160052','乌堤|2160053','科什霍尔姆瓦尔斯群岛|2160054',),
    '卢森堡' => array('卢森堡|2400031','克莱沃|2400040','埃希特纳赫|2400038',),
    '意大利' => array('罗马|2390118','威尼斯|2390203','佛罗伦萨|2390054','米兰|2390138','比萨|2390026','那不勒斯|2390146','维罗纳|2390202','博洛尼亚|2390033','都灵|2390046','因佩里亚|2390215','亚历山德里亚|2390214','西罗滨海|2390213','锡尔米奥内|2390212','锡代诺|2390211','夏卡|2390210','乌尔克斯|2390209','乌尔巴尼亚|2390208','乌迪内|2390207','渥尔特拉|2390206','维亚雷焦|2390205','维琴察|2390204','维拉西米乌斯|2390201','瓦雷泽古雷|2390200','瓦拉塔|2390199','托雷德格雷科|2390198','托尔托利|2390197','托尔吉亚诺|2390196','特伦托|2390195','特拉帕尼|2390194','特拉诺瓦-布拉乔利尼|2390193','特尔尼|2390192','塔韦尔内尔-瓦尔第|2390191','陶里阿诺瓦|2390190','陶尔米纳|2390189','塔兰托|2390188','泰拉奇纳|2390187','泰拉莫|2390186','泰尔莫利|2390185','泰尔米尼-伊梅雷塞|2390184','斯考利|2390183','斯蒂亚|2390182','斯波莱托|2390181','圣洛伦佐镇|2390180','萨萨里|2390179','萨莱诺|2390178','热那亚|2390177','冉达佐|2390176','奇维塔韦基亚|2390175','奇斯特尼诺|2390174','奇尼基亚诺|2390173','切塔尔多|2390172','切里科|2390171','切雷托圭迪|2390170','恰姆皮诺|2390169','普里兹|2390168','普雷甘兹佐|2390167','普拉托|2390166','皮佐费拉图|2390165','皮翁比诺|2390164','皮蒂利亚诺|2390163','蓬迪雷格诺|2390162','佩扎罗|2390161','佩希纳|2390160','佩斯卡拉|2390159','佩乔利|2390158','佩鲁贾|2390157','佩拉戈|2390156','佩恩多克莱港|2390155','潘泰莱里亚|2390154','庞贝|2390153','帕拉亚|2390152','帕基诺|2390151','帕尔米|2390150','帕多瓦|2390149','诺瓦拉|2390148','努奥罗|2390147','穆拉沃拉|2390145','墨西拿|2390144','莫斯库夫|2390143','莫诺波利|2390142','莫拉弟巴里|2390141','莫尔费塔|2390140','摩德纳|2390139','蒙扎|2390137','蒙特西瓦诺|2390136','蒙特斯佩托利|2390135','蒙特切利奥|2390134','蒙特卡蒂尼-泰尔梅|2390133','蒙特利齐约尼|2390132','蒙塔约内|2390131','蒙泰普尔恰诺|2390130','蒙塔尔奇诺|2390129','蒙卡列里|2390128','蒙德拉贡|2390127','梅斯特|2390126','梅拉诺|2390125','马泰利卡|2390124','马萨马尔塔纳|2390123','马萨罗萨|2390122','马萨卢布伦塞|2390121','洛韦雷|2390120','罗维戈|2390119','伦蒂亚|2390117','鲁菲娜|2390116','里耶提|2390115','利沃诺|2390114','利维尼奥|2390113','里瓦-德勒加尔达|2390112','里齐亚|2390111','里米尼|2390110','利卡塔|2390109','联合会在基安蒂|2390108','雷杰诺|2390107','雷焦卡拉布里亚娣|2390106','拉文纳|2390105','拉韦洛|2390104','拉帕洛|2390103','劳利诺|2390102','拉努韦奥|2390101','兰恰诺|2390100','兰佩杜萨|2390099','莱切|2390098','莱科|2390097','拉古萨|2390096','拉戈堡|2390095','库内奥|2390094','克罗托内|2390093','克莱斯|2390092','科莱戈诺|2390091','科尔托纳|2390090','卡坦扎罗|2390089','卡塔尼亚|2390088','卡塔尼塞塔|2390087','卡斯特尔韦特拉诺|2390086','卡斯泰纳索|2390085','卡塞塔|2390084','卡普拉尼卡|2390083','坎波马里诺|2390082','坎波巴索|2390081','卡麦奥雷|2390080','卡利亚里|2390079','卡尔塔吉罗|2390078','卡尔皮|2390077','卡尔马戈诺拉|2390076','卡尔博尼亚|2390075','基耶蒂|2390074','基瓦索|2390073','焦亚省科莱|2390072','基奥贾|2390071','基安蒂卡斯特利纳|2390070','基安蒂格雷沃|2390069','基安蒂盖奥勒|2390068','加尔法尼亚纳新堡|2390067','赫拉弗多纳|2390066','古比奥|2390065','瓜尔多塔迪亚|2390064','瓜尔迪亚-隆巴尔迪|2390063','格罗塞托|2390062','戈里齐亚|2390061','福洛尼卡|2390060','弗龙托内|2390059','弗兰卡维拉丰塔纳|2390058','福贾|2390057','福尔诺沃-迪塔洛|2390056','福尔米亚|2390055','菲韦扎诺|2390053','费拉拉|2390052','菲奥伦蒂诺堡|2390051','凡提米利亚|2390050','恩波利|2390049','多纳|2390048','多莫多索拉|2390047','蒂拉诺|2390045','迪科马诺|2390044','德尔堡湾|2390043','代森扎诺|2390042','布鲁尼科|2390041','布龙佐洛|2390040','布龙尼|2390039','布雷西亚|2390038','博亚诺|2390037','波西塔诺|2390036','波坦察|2390035','波马兰切|2390034','波利克洛|2390032','波拉希|2390031','波基博恩西|2390030','博尔米奥|2390029','博比奥|2390028','比耶拉|2390027','贝卢诺|2390025','贝拉登加新堡|2390024','贝加莫|2390023','巴萨诺-德尔格拉帕|2390022','巴切洛纳波佐迪戈图|2390021','巴列塔|2390020','巴里|2390019','巴勒莫|2390018','巴盖里亚|2390017','阿西斯|2390016','阿韦扎诺|2390015','阿斯科利皮切诺|2390014','阿奇雷亚莱|2390013','阿佩基奥|2390012','奥斯塔|2390011','奥斯蒂利亚|2390010','奥齐诺维|2390009','奥尔维托|2390008','奥尔比亚|2390007','安齐奥|2390006','阿夸彭登泰|2390005','阿戈内|2390004','阿尔塔姆拉|2390003','阿尔卡莫|2390002','阿尔盖罗|2390001','阿尔伯格|2390216','安科纳|2390217','阿雷佐|2390218','阿维亚诺|2390219','博尔扎诺|2390220','博尼法蒂|2390221','布林迪西|2390222','卡普里|2390223','卡洛福泰|2390224','切尔维亚|2390225','基亚瓦里|2390226','德奇莫曼努|2390227','多比亚科|2390228','恩纳|2390229','弗利|2390230','弗罗西诺内|2390231','加拉拉泰|2390232','杰拉|2390233','格拉扎尼塞|2390234','格罗塔列|2390235','圭多尼亚|2390236','拉丁|2390237','洛雷托|2390238','马泰拉|2390239','蒙多维|2390240','奥特朗托|2390241','蓬扎|2390242','罗洛|2390243','萨尔扎纳|2390244','塔尔维西奥|2390245','特乌拉达|2390246','的里雅斯特|2390247','维斯特|2390248','维皮泰诺|2390249','维泰博|2390250','沃兰诺|2390251','阿门多拉|2390252','巴里·佩雷斯|2390253','布雷西亚·盖迪|2390254','贝亚维斯塔角|2390255','卡恰角|2390256','坎帕尼亚帕利努罗角|2390257','卡玻斯罗伦佐|2390258','法尔科纳拉|2390259','富齐诺|2390260','富尔巴拉|2390261','蓝佩杜萨岛|2390262','鲁卡|2390263','马里纳-迪吉诺萨|2390264','马天尼芬卡|2390265','米兰·利纳特|2390266','蒙特阿根塔略|2390267','蒙特奇莫尼|2390268','蒙特斯 安吉洛|2390269','蒙特斯库罗|2390270','巴勒莫省西西里|2390271','佩鲁贾埃吉迪奥|2390272','皮亚琴察·达米亚诺|2390273','比萨·圭斯托|2390274','庞特卡格纳诺|2390275','普拉提卡·迪马雷|2390276','龙基代莱焦纳里|2390277','圣玛利亚迪勒乌卡|2390278','锡拉库萨|2390279','特雷维科|2390280','特雷维索·伊斯楚阿纳|2390281','乌斯蒂卡岛|2390282','维罗纳·维拉弗兰卡|2390283',),
    '匈牙利' => array('布达佩斯|2380009','埃格尔|2380041','佩奇|2380027','塞格德|2380030','杰尔|2380017','索普朗|2380045','凯斯特海伊|2380020','德布勒森|2380012','希欧福克|2380038','乌伊费赫托|2380037','瓦克|2380036','陶陶巴尼奥|2380035','塔波尔卡|2380034','索尔诺克|2380033','塞切尼|2380032','塞克希费黑瓦尔|2380031','萨尔博加德|2380029','皮什珀克洛达尼|2380028','欧罗什哈佐|2380026','尼赖吉哈佐|2380025','瑙吉考尼饶|2380024','密什科尔茨|2380023','迈泽恰特|2380022','孔圣马尔通|2380021','凯奇凯梅特|2380019','凯采尔|2380018','多瑙新城|2380016','蒂萨铁堡|2380015','蒂萨纳拉|2380014','蒂萨福尔德|2380013','大莱陶|2380011','采格莱德|2380010','波罗兹洛|2380008','波尔加|2380007','巴拉顿博格拉|2380006','拜赖焦新村|2380005','奥费赫尔托|2380004','奥包乌伊桑托|2380003','埃杰克|2380002','埃尔德|2380001','巴哈|2380039','贝凯什乔包|2380040','莫雄马扎尔古堡|2380042','保克什|2380043','帕帕|2380044','松博特海伊|2380046','陶萨尔|2380047','札亨尼|2380048','阿加德|2380049','帕里奇|2380050','托科|2380051',),
    '西班牙' => array('巴塞罗纳|2360006','马德里|2360012','塞维利亚|2360020','格拉纳达|2360008','托莱多|2360015','巴伦西亚|2360018','塞戈维亚|2360035','马拉加|2360010','毕尔巴鄂|2360007','阿维拉|2360045','萨拉曼卡|2360054','萨拉戈萨|2360057','希洪|2360016','卡斯特利翁-德拉普拉纳|2360014','潘普洛纳|2360013','穆尔西亚|2360011','雷阿尔城|2360009','巴利亚多利德|2360005','奥维耶多|2360004','阿利坎特|2360003','埃尔切|2360002','阿尔赫西拉斯|2360001','帕尔马|2360017','托雷维耶哈|2360019','拉科鲁尼亚|2360021','拉斯帕尔玛斯|2360022','香格里拉马格罗|2360023','卡塞雷斯|2360024','休达|2360025','韦尔瓦|2360026','伊维萨|2360027','哈恩|2360028','莱里达|2360029','梅利利亚|2360030','纳瓦塞拉达|2360031','庞费拉达|2360032','庞特维德拉|2360033','罗塔|2360034','索里亚|2360036','塔里|2360037','特鲁埃尔|2360038','托尔托萨|2360039','萨莫拉|2360040','伊萨纳|2360041','特纳利夫·吉马尔|2360042','阿尔巴塞特|2360043','阿尔梅里亚|2360044','卡斯特利翁|2360046','拉柯鲁尼亚|2360047','拉磨利那|2360048','洛格罗尼奥|2360049','马德里·巴拉哈斯|2360050','马略卡岛|2360051','梅诺卡岛|2360052','奥伦塞|2360053','瓦伦西亚|2360055','维多利亚|2360056',),
    '斯洛文尼亚' => array('卢布尔雅那|2340005','波斯托|2340001','马里博尔|2340011','采列|2340009','克拉尼|2340003','利斯卡|2340010','新梅斯托|2340008','斯洛伐克比斯特里察|2340007','穆尔斯卡索博塔|2340006','科切维|2340004','克尔斯科|2340002',),
    '斯洛伐克' => array('布拉迪斯拉发|2330004','科希策|2330007','波普拉德|2330003','巴尔代约夫|2330001','皮耶什佳尼|2330012','卢切内茨|2330010','托波尔恰尼|2330018','斯特罗普科夫|2330017','斯尼纳|2330016','斯里阿奇|2330015','恰德察|2330014','普列维扎|2330013','尼特拉|2330011','罗兹纳瓦|2330009','里马夫斯卡索博塔|2330008','胡门内|2330006','汉德洛瓦|2330005','班斯卡-什佳夫尼察|2330002',),
    '瑞典' => array('斯德哥尔摩|2300054','哥德堡|2300102','马尔默|2300044','赫尔辛堡|2300026','基律纳|2300080','乌普萨拉|2300069','吕勒奥市|2300042','延雪平|2300109','林雪平|2300117','于斯塔德|2300077','于默奥|2300076','尤城|2300075','永瑟勒|2300074','耶利瓦勒|2300073','耶夫勒|2300072','耶代德|2300071','谢莱夫特奥|2300070','乌普兰斯韦斯比|2300068','乌尔里瑟港|2300067','乌德瓦拉|2300066','韦特兰达|2300065','韦斯特罗斯|2300064','维纳什堡|2300063','瓦尔马森|2300062','特罗尔海坦|2300061','特雷勒堡|2300060','索莱夫特奥|2300059','松兹瓦尔|2300058','松德比贝里|2300057','斯韦格|2300056','斯图利恩|2300055','绍伦吐纳|2300053','瑟尔沃斯堡|2300052','帕尔蒂勒|2300051','诺尔雪平|2300050','尼雪平|2300049','南泰利耶|2300048','莫利拉|2300047','默恩达尔|2300046','玛丽弗雷德|2300045','吕瑟希尔|2300043','吕克瑟勒|2300041','罗伯茨弗尔斯|2300040','利丁厄|2300039','兰德斯克|2300038','拉克索|2300037','莱克桑德|2300036','孔艾尔夫|2300035','克里斯蒂安斯塔德|2300034','科尔拜克|2300033','卡尔斯库加|2300032','卡尔斯克鲁纳|2300031','胡斯克瓦纳|2300030','霍弗尔斯|2300029','胡丁厄|2300028','胡布里|2300027','哈瑟勒霍尔姆|2300025','哈帕兰达|2300024','海讷桑德|2300023','海尔利永阿|2300022','海德穆拉|2300021','哈格福什|2300020','贡纳恩|2300019','芬斯蓬|2300018','法里拉|2300017','法尔雪平|2300016','恩雪平|2300015','恩金尔兹维克|2300014','厄勒格伦德|2300013','东哈马尔|2300012','蒂姆罗|2300011','蒂达霍尔姆|2300010','博伦厄|2300009','博戈霍尔姆|2300008','博尔奈斯|2300007','奥特维达贝里|2300006','埃斯基尔斯蒂纳|2300005','埃斯宾|2300004','埃克舍|2300003','阿尔维卡|2300002','阿比斯库|2300001','维斯比|2300078','穆拉市|2300079','阿尔耶普卢格市|2300082','阿尔维斯|2300083','奥瑟勒|2300084','博登|2300085','卡尔马|2300086','卡尔斯堡|2300087','马隆|2300088','奥雷布洛|2300089','帕亚拉|2300090','龙讷比|2300091','孙讷|2300092','图灵厄|2300093','威廉明娜|2300094','艾尔夫达伦|2300095','艾莫特|2300096','恩厄尔霍尔姆|2300097','阿克斯图|2300098','比勒克勒布|2300099','法尔斯特布|2300100','弗卢达|2300101','哈兰斯韦德岛|2300103','阿拉曼|2300104','哈诺|2300105','哈什特纳|2300106','霍尔曼|2300107','约克莫克|2300108','卡雷苏安多|2300110','克洛腾|2300111','科斯达|2300112','克龙厄德|2300113','克维克约克|2300114','拉卡特拉斯克|2300115','兰德索尔特|2300116','尼卡卢奥克塔|2300118','科斯特群岛|2300119','诺斯约|2300120','厄兰岛|2300121','厄斯特松德|2300122','奥佛卡利克斯|2300123','龙厄达拉|2300124','希灵厄|2300125','坦奈斯|2300126','塔法拉|2300127','韦克舍|2300128','维德塞尔|2300129','伐拉|2300130',),
    '葡萄牙' => array('里斯本|2290002','波尔图|2290001','Faro|2290007','Coimbra|2290005','Braganca|2290004','Evora|2290006','Sagres|2290012','马希库|2290003','Funchal|2290008','Horta|2290009','Montijo|2290010','Portalegre|2290011','Sines|2290013','维塞乌|2290014','英雄港|2290015','布朗库堡|2290016','科尔沃岛|2290017','弗洛勒斯岛|2290018','拉日什|2290019','蒙特垒|2290020','蓬塔德尔加达|2290021','波尔图 佩德拉什|2290022','圣港|2290023','圣玛丽亚|2290024','坦措什|2290025','比利亚雷亚尔|2290026',),
    '摩尔多瓦' => array('基希纳乌|2270002','蒂拉斯波尔|2270001','巴尔蒂|2270004','弗莱什蒂|2270007','麦克莱|2270010','尼科波尔|2270011','斯特拉瑟尼|2270003','卡古尔|2270005','杜伯萨里|2270006','勒布尼察|2270008',),
    '马其顿' => array('斯科普里|2260009','比托拉|2260002','奥赫里德|2260001','德巴尔|2260012','普瑞特|2260019','斯图米加|2260015','韦莱斯|2260010','拉扎罗波勒|2260008','克里瓦河帕兰卡|2260007','革新|2260006','戈斯蒂瓦尔|2260005','格夫戈里亚|2260004','德米尔卡皮亚|2260003','贝罗沃|2260011','卡瓦达尔齐|2260013','普里莱普|2260014','泰托沃|2260016','克鲁塞沃|2260017','马夫罗沃|2260018',),
    '罗马尼亚' => array('布加勒斯特|2250005','锡比乌|2250022','雅西|2250024','布拉索夫|2250006','图尔恰|2250056','奥拉迪亚|2250002','德瓦|2250033','蒂米什瓦拉|2250009','西格赫图-马尔马蒂耶|2250023','塔尔马齐乌|2250021','萨图马雷|2250020','普洛耶什蒂|2250019','皮特什蒂|2250018','洛西奥里-德维德|2250017','勒姆尼库沃尔恰|2250016','克卢日·纳波卡|2250015','克拉约瓦|2250014','卡兰赛贝什|2250013','卡拉法特|2250012','加拉茨|2250011','格奥尔基尼|2250010','布泽乌|2250008','布勒伊拉|2250007','博托沙尼|2250004','巴克乌|2250003','阿拉德|2250001','康斯坦察|2250025','阿德茹德|2250027','亚历山大|2250028','伯尔拉德|2250029','贝谢|2250030','比斯特里察|2250031','克勒拉希|2250032','福克沙尼|2250034','朱尔朱|2250035','哈索瓦|2250036','胡埃丁|2250037','金波耶|2250038','卢戈日|2250039','马赫穆迪亚|2250040','曼加利亚|2250041','梅吉迪亚|2250042','彼得罗沙尼|2250043','雷代亚尔|2250044','勒德乌齐|2250045','雷希察|2250046','古罗马的|2250047','锡纳亚|2250048','西莉亚|2250049','斯拉蒂纳|2250050','斯洛博齐亚|2250051','苏恰瓦|2250052','苏利纳|2250053','特尔戈维什泰|2250054','题图|2250055','图尔达|2250057','济切尼|2250058','瓦斯卢伊|2250059','扎勒乌|2250060','坎皮纳|2250061','法加拉斯|2250063','米耶尔库雷亚丘克|2250064','新摩尔多瓦|2250065','朋特琉|2250066','皮亚特拉|2250067',),
    '列支敦士登' => array('瓦杜兹|2240001',),
    '立陶宛' => array('维尔纽斯|2230003','考纳斯|2230001','希奥利艾|2230006','帕兰加|2230004','克莱佩达|2230002','特尔希艾|2230008','帕涅韦日斯|2230005','斯路特|2230007','乌克梅尔盖|2230009','欧蒂娜|2230010','尼达|2230011','上第文斯基|2230012',),
    '拉脱维亚' => array('里加|2220003','利耶帕亚|2220004','文茨皮尔斯|2220007','陶格夫匹尔斯|2220005','包斯卡|2220009','瓦尔米耶拉|2220006','叶尔加瓦|2220008','雷泽克内|2220002','奥格雷|2220001','多贝莱|2220010','马多娜|2220011','萨尔杜斯|2220012',),
    '克罗地亚' => array('萨格勒布|2210010','杜布罗夫尼克|2210004','斯普利特|2210013','罗维尼|2210007','希贝尼克|2210024','拉布岛|2210030','里耶卡|2210006','科尔丘拉|2210005','斯拉沃尼亚布罗德|2210012','上胡马克|2210011','木洛希尼|2210009','马里通|2210008','茨雷斯|2210003','比奥格勒|2210002','奥西耶克|2210001','别洛瓦尔|2210014','达鲁瓦尔|2210015','戈斯皮奇|2210016','赫瓦尔|2210017','克宁|2210018','克拉皮纳|2210019','克里热夫齐|2210020','马卡尔斯卡|2210021','帕任|2210022','塞尼|2210023','锡萨克|2210025','瓦拉日丁|2210026','米扎|2210027','拉斯托伏|2210028','普洛切|2210029','马尔让山|2210031',),
    '捷克' => array('布拉格|2200028','卡罗维发利|2200008','比尔森|2200002','奥洛穆茨|2200001','霍穆托夫|2200006','俄斯特拉发|2200039','伊钦|2200027','因德日赫城堡|2200026','耶塞尼克|2200025','图尔诺夫|2200024','特热比奇|2200023','特鲁特诺夫|2200022','斯特拉科尼采|2200021','顺佩尔克|2200020','丘兰诺夫|2200019','切尔韦纳|2200018','普日姆达|2200017','普罗斯捷约夫|2200016','帕尔杜比采|2200015','利贝雷茨|2200014','拉贝河畔乌斯季|2200013','科斯泰尔尼-米斯洛瓦|2200012','科切罗维奇|2200011','克拉托维|2200010','卡维纳|2200009','捷克捷欣|2200007','霍莱绍夫|2200005','河畔乌斯季奥尔利|2200004','布热茨拉夫|2200003','恰斯拉夫|2200029','海布|2200030','普热罗夫|2200031','普日比斯拉夫|2200032','杜丁西|2200033','杜库凡尼|2200034','胡尔巴诺沃|2200035','迈尔索夫卡|2200036','莫霍夫采|2200037','奥斯拉瓦河畔纳梅什季|2200038','波普拉德·塔特拉山|2200040','布拉格科贝里|2200041','普雷绍夫|2200042','泰梅林|2200043','日利纳|2200044',),
    '黑山' => array('波德戈里察|2190001','蒂瓦特|2190002','乌尔齐尼|2190003',),
    '荷兰' => array('阿姆斯特丹|2180002','鹿特丹|2180012','海牙|2180019','马斯特里赫特|2180013','莱顿|2180010','格罗宁根|2180007','乌特勒支|2180018','新米利根|2180017','希尔弗苏姆|2180016','瓦森纳|2180015','斯塔茨卡纳尔|2180014','莱利斯塔德|2180011','霍克范荷兰|2180009','霍赫芬|2180008','弗拉尔丁恩|2180006','多德雷赫特|2180005','蒂尔堡|2180004','德拉赫滕|2180003','埃默洛尔德|2180001','吕伐登|2180020','沃尔克|2180021','迪莱|2180022','艾恩德霍芬|2180023','蒂纳洛德伦特|2180024','弗利兰岛|2180025',),
    '格陵兰' => array('西西缪特|2170007','塔西拉克|2170014','纳萨尔苏瓦克|2170003','康克鲁斯瓦克|2170002','亚西亚特|2170008','伊托考托米特|2170012','尤利安娜霍布|2170006','雅各布沙温|2170005','苏克托彭|2170004','阿基奈特赛特|2170001','戈特霍布|2170009','达讷堡|2170010','洪堡特|2170011','瑞士训练营|2170013',),
    '俄罗斯' => array('莫斯科|2140027','圣彼得堡|2140035','伊尔库茨克|2140047','索契|2140058','新西伯利亚|2140044','摩尔曼斯克|2140026','海参崴|2140050','叶卡捷琳堡|2140046','喀山|2140053','乌兰乌德|2140064','哈巴罗夫斯克|2140238','布拉戈维申斯克|2140218','伊万诺沃|2140049','伊热夫斯克|2140048','雅库茨克|2140045','下诺夫哥罗德州|2140043','乌里扬诺夫斯克|2140042','乌法|2140041','沃洛格达|2140040','托木斯克|2140039','特维尔|2140038','坦波夫|2140037','斯摩棱斯克|2140036','瑟克特夫卡尔|2140034','萨马拉|2140033','萨列哈尔德|2140032','萨拉托夫|2140031','萨兰斯克|2140030','普斯科夫|2140029','南萨哈林斯克|2140028','马加丹|2140025','迈科普|2140024','利佩茨克|2140023','库尔干|2140022','科斯特罗马|2140021','克麦罗沃|2140020','克拉斯诺达尔|2140019','堪察加彼得巴甫洛夫斯克|2140018','卡卢加|2140017','基洛夫|2140016','加里宁格勒|2140015','哈巴罗夫斯克（伯力）|2140014','弗拉基米尔|2140013','符拉迪沃斯托克|2140012','伏尔加格勒|2140011','鄂木斯克|2140010','顿河畔罗斯托夫|2140009','赤塔|2140008','车里雅宾斯克|2140007','别尔哥罗德|2140006','彼得罗扎沃茨克|2140005','奔萨|2140004','巴尔瑙尔|2140003','奥伦堡|2140002','阿巴坎|2140001','阿尔汉格尔斯克|2140051','下诺夫哥罗德|2140052','沃尔库塔|2140054','彼尔姆|2140055','阿斯特拉罕|2140056','马哈奇卡拉|2140057','秋明|2140059','下瓦尔托夫斯克|2140060','诺里尔斯克|2140061','新库兹涅茨克|2140062','克拉斯诺亚尔斯克|2140063','阿纳德尔|2140065','别洛戈尔斯克|2140066','斯特列尔卡|2140067','艾德勒|2140068','阿尔丹|2140069','亚历山德罗夫|2140070','亚历山大罗夫斯克|2140071','俄罗斯|2140072','安加尔斯克|2140073','安娜|2140074','阿帕季特|2140075','这区|2140076','卡尔斯克|2140077','亚速海|2140078','巴拉瑟夫|2140079','拉宾斯克|2140080','别洛沃|2140081','别洛焦尔斯克|2140082','比金|2140083','比罗比詹|2140084','比尔斯克|2140085','博戈托尔|2140086','鲍里索格列布斯克|2140087','博尔贾|2140088','布拉茨克|2140089','布列德|2140090','布琼诺夫斯克|2140091','布古鲁斯兰|2140092','这里|2140093','钱尼|2140094','德诺|2140095','落合|2140096','杜金卡|2140097','杜万|2140098','埃格韦基诺特|2140099','埃利斯塔|2140100','加加林|2140101','格多夫|2140102','巨人|2140103','格拉佐夫|2140104','戈林|2140105','戈罗多维科夫斯克|2140106','古杰尔梅斯|2140107','伊加尔卡|2140108','是他|2140109','卡勒瓦拉|2140110','坎达拉克沙|2140111','坎斯克|2140112','卡拉布拉克|2140113','卡拉苏克|2140114','卡尔塔雷|2140115','基廉斯克|2140116','柯尔斯|2140117','基尔沙诺夫|2140118','克林|2140119','科洛姆纳|2140120','多波加|2140121','康斯坦丁诺夫斯克|2140122','科特拉斯|2140123','克拉斯诺乌菲姆斯克|2140124','克鲁泡特金|2140125','库德姆卡尔|2140126','昆古尔|2140127','库皮诺|2140128','库尔斯克|2140129','凯拉|2140130','李曼|2140131','利斯基|2140132','利夫|2140133','洛沃泽罗|2140134','马格尼托哥尔斯克|2140135','妈妈|2140136','马林斯克|2140137','马尔科沃|2140138','梅列乌兹|2140139','缅泽林斯克|2140140','莫戈恰|2140141','莫罗佐夫斯克|2140142','莫兹多克|2140143','穆罗姆|2140144','纳德姆|2140145','涅温诺梅斯克|2140146','下乌金斯克|2140147','诺格利基|2140148','诺林斯克|2140149','奥库洛夫卡|2140150','奥列尼奥克|2140151','奥涅加|2140152','奥廖尔|2140153','帕拉别利|2140154','游击队城|2140155','帕韦列茨|2140156','伯朝拉河|2140157','彼得罗夫斯克|2140158','皮涅加|2140159','波克罗夫卡|2140160','罗斯托夫|2140161','雷宾斯克|2140162','萨拉普尔|2140163','萨索沃|2140164','谢苗诺夫|2140165','谢罗夫|2140166','申库尔斯克|2140167','石勒喀河|2140168','斯科沃罗季诺|2140169','斯拉夫戈罗德|2140170','索托瓦拉|2140171','索斯诺沃|2140172','索西瓦|2140173','斯列坚斯克|2140174','斯塔里察|2140175','斯塔夫罗波尔|2140176','斯捷尔利塔马克|2140177','苏拉|2140178','斯韦特洛格勒|2140179','塔甘罗格|2140180','塔拉|2140181','鞑靼斯克|2140182','塔夫达|2140183','捷别尔达|2140184','捷姆尼科夫|2140185','捷夫里兹|2140186','季克西|2140187','托博尔斯克|2140188','托古钦|2140189','特鲁布切夫斯克|2140190','图阿普谢|2140191','图拉|2140192','图伦|2140193','图拉|2140194','图林斯克|2140195','滕达|2140196','乌格里哥斯克|2140197','乌廖特|2140198','翁巴|2140199','韦列夏吉诺|2140200','韦特卢加|2140201','维季姆河|2140202','弗拉基高加索|2140203','沃洛科拉姆斯克|2140205','维堡|2140206','维克萨|2140207','维捷格拉|2140208','济马|2140209','兹拉托乌斯特|2140210','阿金斯科耶|2140211','阿克萨|2140212','亚鲁克斯尼|2140213','阿德马|2140214','阿尔卡|2140215','巴尔卡希诺|2140216','贝罗瑞克|2140217','布鲁伊斯克|2140219','波汉|2140220','博洛戈耶|2140221','朋内克|2140222','布斯克|2140223','州库尔塔|2140224','德米杨斯克|2140225','埃夫雷莫夫|2140226','叶拉布加|2140227','怡莱|2140228','艾麦克|2140229','恩戈泽罗|2140230','尹尔肖夫|2140231','加利奇|2140232','基联恩金克|2140233','格鲁吉夫斯克|2140234','格罗兹尼|2140235','古加|2140236','古尔贝内|2140237','哈卡斯|2140239','哈坦加|2140240','霍尔姆|2140241','印塞|2140242','印迪加|2140243','卡缅斯克乌拉尔斯基|2140244','卡西恩|2140245','凯西琳|2140246','基努|2140247','卡尔夫|2140249','科斯塔那|2140250','科泰尔|2140251','科夫达|2140252','库雷萨雷|2140253','基恩|2140254','路希|2140255','马里乌波尔|2140256','梅德韦日耶戈尔斯克|2140257','梅利托波尔|2140258','米赫路夫|2140259','蒙迪|2140260','莫扎伊斯克|2140261','纳里扬马尔|2140262','纳罗福明斯克|2140263','纳吉莫伏|2140264','诺拉|2140265','诺尔斯克|2140266','新罗西斯克|2140267','济良卡|2140268','乌努耳|2140269','奥则基|2140270','普洛列塔尔斯卡亚|2140272','赛马|2140273','萨兰保罗|2140274','萨维奥洛夫|2140275','谢尔普霍夫|2140276','斯卢茨克|2140277','苏岑斯克|2140278','苏亚|2140279','塔尔科萨列|2140280','提瑞博卡|2140281','托姆帕|2140282','图伊玫资|2140283','唐卡|2140284','乌赫塔|2140285','乌里茨基|2140286','乌鲁普|2140287','瓦拉姆|2140288','瓦尔加|2140289','上扬斯克|2140290','维尔扬迪|2140291','佛洛昌卡|2140292','沃罗涅日|2140293','沃鲁|2140294',),
    '波黑' => array('萨拉热窝|2110005','莫斯塔尔|2110004','纽姆|2110013','图兹拉|2110014','巴尼亚卢卡|2110001','亚伊采|2110011','泽尼察|2110007','桑斯基莫斯特|2110006','科托尔城|2110003','布尔奇科|2110002','比哈奇|2110008','布戈伊诺|2110009','格拉达卡奇|2110010','利夫诺|2110012',),
    '波兰' => array('华沙|2100014','克拉科夫|2100018','罗兹|2100043','卢布林|2100026','卡托维兹|2100017','格但斯克|2100009','弗罗茨瓦夫|2100008','波兹南|2100044','扎维尔切|2100042','扎布热|2100041','希维诺乌伊希切|2100040','托伦|2100039','塔尔努夫|2100038','苏瓦乌基|2100037','索斯诺维茨|2100036','斯塔拉乔维切|2100035','斯塔加德什切青|2100034','什切青|2100033','琴斯托霍瓦|2100032','乔伊尼斯|2100031','普沃茨克|2100030','姆瓦瓦|2100029','梅莱茨|2100028','马尔克兹伊切|2100027','雷布尼克|2100025','拉齐布日|2100024','莱格尼察|2100023','科扎林|2100022','克沃兹科|2100021','科沃布热格|2100020','肯琴|2100019','卡利什|2100016','凯尔采|2100015','格涅兹诺|2100013','格鲁德柴兹|2100012','戈莱纽夫|2100011','格丁尼亚|2100010','蒂黑|2100007','但泽|2100006','大波兰地区戈茹夫|2100005','比亚韦斯托克|2100004','贝尔恰托|2100003','奥特沃克|2100002','埃尔布隆格|2100001','Bydgoszcz|2100045','Hel|2100046','Kolo|2100047','Kozienice|2100048','Krosno|2100049','Leba|2100050','Lebork|2100051','Lesko|2100052','Mikolajki|2100053','Opole|2100054','Ostroleka|2100055','Pila|2100056','Przemysl|2100057','Pulawy|2100058','Rzeszow|2100059','Sandomierz|2100060','Siedlce|2100061','Szczecinek|2100062','Terespol|2100063','乌斯特卡|2100064','维隆|2100065','弗沃达瓦|2100066','扎科帕内|2100067','扎莫希奇|2100068','贝沃兹|2100069','别尔斯克·比亚瓦|2100070','耶列尼亚古拉|2100071','卡托维兹佩朔维茨|2100072','新松奇|2100073','斯涅兹卡|2100074','绿山城|2100075',),
    '白俄罗斯' => array('明斯克|2060011','莫吉廖夫|2060012','戈梅利|2060006','格罗德诺|2060005','鲍里索夫|2060003','维捷布斯克|2060014','平斯克|2060013','利普|2060010','林图皮|2060009','利达|2060008','科布林|2060007','多布鲁什|2060004','巴拉诺维奇|2060002','奥尔沙|2060001','多克西泽|2060015','高尔基|2060016','莫济里|2060017','波洛茨克|2060018','仙纳|2060019','斯帕斯-杰缅斯克|2060020',),
    '爱沙尼亚' => array('塔林|2040001','约格瓦|2040002','昆达|2040003','金吉谢普|2040004','基里希|2040005','图里|2040006','维尔楚|2040007','沃洛索沃|2040008',),
    '阿尔巴尼亚' => array('斯库台|2020002','地拉那|2020001','都拉斯|2020003','库克斯|2020004','佩什科比|2020005','发罗拉|2020006','吉诺卡斯特|2020007','科尔察|2020008',),
    '马耳他' => array('瓦莱塔|2400030',),
    '安道尔' => array('安道尔|2400032',),
    '摩纳哥' => array('摩纳哥|2400033',),
    '圣马力诺' => array('圣马力诺|2400034',),
    '梵蒂冈' => array('梵蒂冈城|2400035',),
    '直布罗陀' => array('直布罗陀市|2400039',),
  ),
  
  '美洲' => array(

    '美国' => array('纽约|3250059','拉斯维加斯|3250049','洛杉矶|3250048','旧金山|3250035','华盛顿|3250033','波士顿|3250016','芝加哥|3250096','西雅图|3250087','哥伦布|3250030','新奥尔良|3250110','哥伦比亚|3250212','泽西城|3250095','亚特兰大|3250094','印第安纳波利斯|3250093','扬克斯|3250092','英格尔伍德|3250091','尤金|3250090','西瓦利城|3250089','西米谷|3250088','休斯顿|3250086','夏洛特|3250085','锡达拉皮兹|3250084','韦恩堡|3250083','沃伦|3250082','沃特伯里|3250081','瓦列霍|3250080','温斯顿-赛伦|3250079','图森|3250078','檀香山|3250077','唐尼|3250076','塔拉哈西|3250075','图尔萨|3250074','苏瀑|3250073','什里夫波特|3250072','圣地亚哥|3250071','圣贝纳迪诺|3250070','斯托克顿|3250069','萨克拉门托|3250068','乔利埃特|3250067','钱德勒|3250066','切萨皮克|3250065','庞帕诺比奇|3250064','潘布鲁克派恩斯|3250063','欧申赛德|3250062','诺福克|3250061','诺克斯维尔|3250060','诺沃克|3250058','密尔沃基|3250057','明尼阿波利斯|3250056','莫雷诺谷|3250055','莫德斯托|3250054','迈阿密|3250053','梅斯基特|3250052','莫比尔|3250051','罗克福德|3250050','劳德代尔堡|3250047','拉雷多|3250046','罗利|3250045','克拉克斯维尔|3250044','科林斯堡|3250043','科罗拉多泉|3250042','科斯塔梅萨|3250041','康科德|3250040','克利尔沃特|3250039','科勒尔斯普林斯|3250038','开普科勒尔|3250037','吉尔伯特|3250036','加兰|3250034','好莱坞|3250032','海厄利亚|3250031','格林斯伯勒|3250029','菲尼克斯|3250028','弗里蒙特|3250027','弗雷斯诺|3250026','费城|3250025','底特律|3250024','独立城|3250023','丹佛|3250022','戴利城|3250021','达拉斯|3250020','查尔斯顿|3250019','长滩|3250018','北拉斯维加斯|3250017','伯班克|3250015','波莫纳|3250014','贝克斯菲尔德|3250013','贝尔维尤|3250012','埃文斯维尔|3250011','奥马哈|3250010','安娜堡|3250009','埃斯孔迪多|3250008','安大略|3250007','奥克斯纳德|3250006','安那罕|3250005','奥兰多|3250004','阿克伦|3250003','奥斯汀|3250002','奥克拉荷马市|3250001','罗切斯特|3250097','巴尔的摩|3250099','罗福|3250100','辛辛那提|3250101','得梅因|3250102','克里夫兰|3250103','匹兹堡|3250104','尼亚加拉瀑布城|3250105','奥尔巴尼|3250106','杰克逊维尔|3250107','坦帕|3250108','蒙哥马利|3250109','小石城|3250111','孟菲斯|3250112','纳什维尔|3250113','山景城|3250115','伯克利|3250116','波特兰|3250117','斯波坎|3250118','博伊西|3250119','大瀑布城|3250120','俾斯麦|3250121','堪萨斯城|3250122','俄克拉何马城|3250123','休斯敦|3250124','圣安东尼奥|3250125','奥斯丁|3250126','凤凰城|3250127','盐湖城|3250128','阿尔伯克基|3250129','安克雷奇|3250130','费尔班克斯|3250131','朱诺|3250132','乌纳拉斯卡|3250133','诺姆|3250134','火奴鲁鲁|3250135','阿拉莫萨|3250136','阿梅里奥|3250137','贝克利|3250138','布罗克|3250139','伯恩斯|3250140','森特维尔|3250141','张伯伦|3250142','哈森|3250143','夏安|3250144','克雷格|3250145','克罗斯维尔|3250146','杜兰戈|3250147','埃尔科|3250148','埃斯卡诺巴|3250149','弗拉格斯塔夫|3250150','弗兰肯|3250151','加尔维斯顿|3250152','汉福德|3250153','哈蒂斯堡|3250154','亨利|3250155','基奈|3250156','科迪亚克|3250157','利胡埃|3250158','琳达|3250159','马凯特|3250160','奥林匹亚|3250161','奥马克|3250162','帕迪尤卡|3250163','裴吉|3250164','彭萨科拉|3250165','罗斯福|3250166','拉姆福德|3250167','塞勒姆|3250168','索尔兹伯里|3250169','苏厄德|3250170','锡特卡|3250171','托皮卡|3250172','厄普顿|3250173','瓦尔迪兹|3250174','瓦利|3250175','威尔士|3250176','温菲尔德|3250177','温斯洛|3250178','兰格尔|3250179','圣胡安|3250180','克里斯琴斯特德|3250181','空军学院|3250182','安古恩|3250183','阿尼亚克|3250184','安妮特岛|3250185','大西洋城|3250186','巴特岛|3250187','圣马丁站|3250188','埃斯佩兰萨站|3250189','马兰比奥站|3250190','奥尔卡达斯站|3250191','巴吞鲁日|3250192','比弗岛|3250193','白令豪山|3250194','倍特尔斯|3250195','大派尼|3250196','伯德岛|3250197','毕斯科群岛|3250198','毕夏普|3250199','波拿巴特尖|3250200','布里斯托尔约翰逊金仕堡|3250201','布莱克斯堡|3250202','巴特勒岛|3250203','卡连特|3250204','哈特拉斯角|3250205','菲利普斯岬|3250206','罗斯岬|3250207','锡特拉皮兹|3250208','中央公园|3250209','查塔姆|3250210','冷湾|3250211','肯考迪亚|3250213','戴维斯|3250214','德弗尔斯莱克|3250215','迪金森|3250216','富士圆顶|3250217','伊莱恩|3250218','鹰|3250219','东港|3250220','伊丽莎白城|3250221','埃尔帕索|3250222','埃尼威托克|3250223','尤里卡|3250224','费雷尔|3250225','本宁堡|3250226','卡森堡|3250227','道奇堡|3250228','格里利堡|3250229','福德堡|3250230','瓦丘卡堡|3250231','波克堡|3250232','莱利堡|3250233','锡尔堡|3250234','沃斯堡|3250235','育空堡|3250236','弗雷什庞德|3250237','诺克斯堡|3250238','盖奇|3250239','盖洛德|3250240','格伦纳伦|3250241','格雷|3250242','大瀑布村|3250243','长城|3250244','格林维尔|3250245','古利德维肯|3250246','古斯塔夫斯|3250247','哈雷|3250248','哈特福德|3250249','豪普特冰原岛峰|3250250','亨廷顿|3250251','赫尔伯特菲尔德|3250252','印第安泉靶场|3250253','杰克逊|3250254','杰斐逊城|3250255','晋州岛|3250256','凯纳角|3250257','卡内奥赫湾|3250258','基拉韦厄|3250259','乔治王岛|3250260','大鳞大麻哈鱼|3250261','寇基|3250262','考拿|3250263','利蒙|3250264','林肯|3250265','朗维尤|3250266','曼露埃拉|3250267','大理石尖|3250268','玛里琳|3250269','麦克格拉斯|3250270','麦克默多|3250271','梅迪辛洛奇|3250272','梅尔罗斯靶场|3250273','米德尔顿岛|3250274','迈尔斯城|3250275','明丘米纳|3250276','米纳布拉夫|3250277','米尔内|3250278','莫洛凯|3250279','莫耐特|3250280','纽麦尔|3250281','新港|3250282','诺思韦|3250283','渥烈治|3250284','大洋城|3250285','帕默站|3250287','帕克佛斯|3250288','桃树城|3250289','北飞马座|3250290','波普拉布拉夫|3250291','克拉伦斯港|3250292','海登港|3250293','普雷斯克岛|3250294','阔德城|3250295','拉皮特城|3250296','羅西拉|3250297','昭和站|3250298','圣特雷莎|3250300','桑德伯格|3250301','桑德森|3250302','圣马里亚|3250303','塞勒溪靶场|3250304','斯科茨布拉夫|3250305','海狮岛|3250306','谢里丹|3250307','希珀尔站|3250308','斯卡圭|3250309','斯莫科希尔靶场|3250310','斯奈德岩石区|3250311','南考拿|3250312','圣约翰斯伯利|3250313','圣保罗群岛|3250314','圣斯图尔特|3250315','萨尔弗格罗夫|3250316','塔尔基特纳|3250317','塔纳纳河|3250318','乌米亚特|3250319','安阿拉克利特|3250320','维尔纳茨基|3250321','沃斯托克|3250322','华盛顿山|3250323','韦科·库珀|3250324','威基基|3250325','怀马纳洛|3250326','沃拉沃拉|3250327','瓦勒普斯岛|3250328','沃罗德|3250329','法莎|3250330','西棕榈滩|3250331','西多佛|3250332','西普莱恩斯|3250333','白湖|3250334','白沙|3250335','维特洛克|3250336','威尔克斯|3250337','威廉姆斯区|3250338','亚卡塔格|3250339','亚库塔特|3250340',),
    '加拿大' => array('渥太华|3230049','温哥华|3230048','多伦多|3230010','蒙特利尔|3230034','本那比|3230007','魁北克市|3230060','惠斯勒高山|3230220','辛普森堡|3230129','温尼伯|3230050','柯林顿|3230110','卡尔加里|3230024','维多利亚冈萨雷斯|3230215','支里画|3230055','伊努维克|3230054','伊魁特|3230053','药帽|3230052','希布加莫|3230051','威廉斯湖|3230047','天明|3230046','诗古提米|3230045','沙普洛|3230044','珊尼亚|3230043','萨斯卡通|3230042','皮克尔湖|3230041','尼皮贡|3230040','纳塔诗昆|3230039','纳奈莫|3230038','纳尔逊堡|3230037','穆斯乔|3230036','密西沙加|3230035','蒙克顿|3230033','麦克默里堡|3230032','鲁伯特王子港|3230031','里贾纳|3230030','里福斯多克|3230029','桑德贝|3230028','拉龙日|3230027','兰今湾|3230026','魁北克|3230025','旧克罗|3230023','基隆拿|3230022','吉兰湖|3230021','科纳布鲁克|3230020','焦林|3230019','加蒂诺|3230018','黄刀镇|3230017','红鹿|3230016','海河|3230015','格莱斯湾|3230014','高堡|3230013','甘露市|3230012','弗雷德里克顿|3230011','迪斯莱克|3230009','宾迪顿|3230008','北战堡|3230006','贝克湖|3230005','奥沙瓦|3230004','奥克维尔|3230003','安提格尼斯|3230002','埃德蒙顿|3230001','怀特霍斯|3230057','汉密尔顿|3230059','七岛港|3230061','圣约翰斯|3230063','哈利法克斯|3230064','夏洛特敦|3230065','阿姆斯壮|3230067','阿蒂科肯|3230068','班夫|3230069','博纳维斯塔|3230070','克兰|3230071','戈德里奇|3230072','格林伍德|3230073','希望|3230074','卡普斯卡辛|3230075','凯诺拉|3230076','出版社|3230077','莱斯布里奇|3230078','劳埃德明斯特|3230079','马尼沃基|3230080','尼帕温|3230081','尤斯|3230082','佩塔瓦瓦|3230083','罗泊威尔|3230084','舍布鲁克|3230085','史密瑟斯|3230086','赛德|3230087','汤普森|3230088','雅茅斯|3230089','约克顿|3230090','阿格西|3230091','阿真舍|3230092','巴伦纳斯岛|3230093','大特劳特莱克|3230094','布朗萨布隆|3230095','布卢里弗|3230096','布罗德维尤|3230097','布法罗峡口|3230098','伯恩斯莱克湖|3230099','剑桥湾|3230100','开普多塞特|3230101','开普胡珀|3230102','开普帕里|3230103','开普雷斯|3230104','开普代尔|3230105','卡特赖特|3230106','切维利|3230107','丘吉尔|3230108','丘吉尔瀑布|3230109','克莱德里弗|3230111','科尔德莱克|3230112','科林斯湾|3230113','科尔维尔湖|3230114','科莫克斯|3230115','科勒尔港|3230116','丹尼尔斯港|3230117','多菲内|3230118','德尔拉克阿|3230120','德瓦尔莱克斯|3230121','伊斯特波因特|3230122','埃斯特万|3230123','埃斯特万波因特|3230124','福瑞特蒙特莫伦斯|3230125','奇普怀恩堡|3230126','圣约翰堡|3230128','史密斯堡|3230130','古斯贝|3230131','戈尔贝|3230132','大普雷里|3230133','大急流城|3230134','大鸭岛|3230135','格雷特纳|3230136','霍尔比奇|3230137','海莱夫尔|3230138','海里弗|3230139','海福尔斯|3230140','霍普代尔|3230141','哈德逊贝|3230142','印地安海德|3230143','英格尼什海滩|3230144','英鸟克胡阿克|3230145','伊斯兰莱克|3230146','库格鲁克图克|3230147','库朱阿克|3230148','拉格兰德|3230149','兰加拉|3230151','兰加拉岛|3230152','兰斯都赫斯|3230153','长岬|3230154','朗斯塔夫布鲁夫|3230155','林莱克|3230156','利顿|3230157','麦肯齐河|3230158','马提考特岛|3230159','麦克因尼斯岛|3230160','梅多莱克|3230161','梅利塔|3230162','米斯库岛|3230163','朱利亚山|3230164','穆索尼|3230165','森林山|3230166','纳加加米|3230167','内恩|3230168','诺地吉|3230169','挪威豪斯|3230170','庞纳唐|3230171','帕朗|3230172','皮斯里弗|3230173','皮瓦努克|3230174','平彻克里克|3230175','庞德因莱特|3230176','阿尔伯尼港|3230177','钱纳尔-巴斯克港|3230178','哈迪港|3230179','梅尼埃港|3230180','乔治王子城|3230181','雷德莱克|3230182','雷索卢申岛|3230183','里维耶尔|3230184','罗伯逊湖|3230185','罗克格伦|3230186','落基山庄|3230187','东玫瑰镇|3230188','塞布尔岛|3230189','桑兹皮特|3230190','圣约翰|3230191','萨图纳岛|3230192','苏圣玛丽|3230193','谢弗维尔|3230194','苏卢考特|3230195','灵魂河汽车站|3230196','西斯皮里特伍德|3230197','斯阔米什|3230198','圣安东尼亚|3230199','圣彼得斯|3230200','圣斯蒂芬|3230201','斯蒂芬维尔|3230202','萨德伯里|3230203','塔斯林|3230204','帕斯|3230205','汤姆森河|3230206','托拉卡迪|3230207','特伦顿|3230208','图克托亚图克|3230209','图克图特诺革特国家公园|3230210','阿普萨拉|3230211','铀城|3230212','瓦勒多|3230213','温哥华港|3230214','维尔莉特格罗夫|3230216','华沙加明|3230217','沃瓦|3230218','韦兰佩勒姆|3230219','怀特法院|3230221','怀尔顿|3230222','莱克豪斯|3230223','温耶德|3230224',),
    '墨西哥' => array('墨西哥城|3270004','瓜纳华托|3270031','蒂华纳|3270015','科利马|3270027','坎昆|3270022','梅里达|3270021','萨尔蒂|3270035','维多利亚城|3270043','伊达尔戈|3270011','韦拉克鲁斯|3270010','瓦哈卡|3270009','特拉斯卡拉|3270008','萨卡特卡斯|3270007','奇瓦瓦|3270006','普埃布拉|3270005','莫雷洛斯|3270003','马尔多纳多港|3270002','坎佩切|3270001','克雷塔罗|3270012','瓜达拉哈拉|3270013','马萨特兰|3270014','埃莫西约|3270016','蒙特雷|3270017','坦皮科|3270018','阿卡普尔科|3270019','图斯特拉-古铁雷斯|3270020','阿瓜斯卡连特斯|3270023','阿里亚加|3270024','切图马尔|3270025','夸察夸尔科斯|3270026','库埃纳瓦卡|3270028','库利亚坎|3270029','埃姆帕尔姆|3270030','蒙克洛瓦|3270032','莫雷利亚|3270033','奥里萨巴|3270034','塔穆因|3270036','塔帕丘拉|3270037','特皮克|3270038','托卢卡|3270039','托雷翁|3270040','比亚埃尔莫萨|3270041','奇尔潘辛戈|3270042','克夫雷贡城|3270044','伊达尔戈德尔帕拉尔|3270045','拉巴斯|3270046','里奥维德|3270047','圣路易波托西|3270048','特莫沙奇克|3270049','特佩瓦内斯|3270050',),
    '智利' => array('圣地亚哥|3380015','卡拉马|3380008','瓦尔帕莱索|3380021','伊基克|3380024','蓬塔阿雷纳斯|3380012','库里|3380010','奥索尔诺|3380005','安托法加斯塔|3380004','圣多明哥|3380037','岩德圣多明各|3380023','维塔库拉|3380022','瓦尔迪维亚|3380020','特木科|3380019','塔拉甘特|3380018','塔尔卡诺瓦|3380017','塔尔卡|3380016','沙伊顿|3380014','普孔|3380013','兰卡瓜|3380011','科皮亚波|3380009','比尼亚德尔马|3380007','奥瓦列|3380006','阿里卡|3380003','阿莱马纳镇|3380002','艾森港|3380001','蒙特港|3380026','奇廉|3380027','考昆|3380028','康塞普西翁|3380029','巴尔马塞塔|3380032','考伊海格|3380033','富塔乐富|3380034','拉塞雷纳|3380035','阿雷纳斯角|3380036',),
    '秘鲁' => array('利马|3260008','库斯科|3260007','通贝斯|3260030','莫罗纳|3260033','塔拉波托|3260034','查查波亚斯|3260003','瓦努科|3260017','塔克纳|3260015','普卡尔帕|3260012','拉斯帕尔马斯|3260032','卡哈马卡|3260006','尤里马瓜斯|3260021','伊卡|3260020','伊基托斯|3260019','维塔尔特|3260018','瓦拉|3260016','钦查阿尔塔|3260014','钦博特|3260013','皮乌拉|3260011','莫克瓜|3260010','马图卡纳|3260009','胡利亚卡|3260005','胡安惠|3260004','安达韦拉斯|3260002','阿雷基帕|3260001','Ayacucho|3260022','Chiclayo|3260023','Jauja|3260024','Nazca|3260025','Pisco|3260026','Rioja|3260027','Talara|3260028','Trujillo|3260029','阿塔拉亚|3260031','廷戈玛丽亚|3260035',),
    '洪都拉斯' => array('特古西加尔巴|3220002','圣佩德罗苏拉|3220003','罗阿坦|3220001','阿马帕拉|3220004','圭亚那|3220005','约罗|3220006','卡塔开马斯|3220007','乔卢特卡|3220008',),
    '哥伦比亚' => array('波哥大|3160006','麦德林|3160015','佩雷拉|3160021','卡利|3160012','伊皮亚莱斯|3160027','帕斯托|3160020','巴兰基亚|3160003','伊塔古伊|3160028','图马科|3160026','通哈|3160025','索莱达|3160024','索加莫索|3160023','皮豪|3160022','帕尔米拉|3160019','内瓦|3160018','蒙特里亚|3160017','马尼萨莱斯|3160016','里奥阿查|3160014','库库塔|3160013','基布多|3160011','恩维加多|3160010','布卡拉曼加|3160009','布埃纳文图拉|3160008','波帕扬|3160007','比亚维森西奥|3160005','巴耶杜帕尔|3160004','阿帕|3160002','阿劳卡|3160001','皮塔利托|3160029','拉斯维加斯加维奥塔斯|3160030',),
    '巴西' => array('里约热内卢|3100011','圣保罗|3100017','马瑙斯|3100013','巴西利亚|3100003','萨尔瓦多|3100016','库里蒂巴|3100008','伊瓜苏|3100019','贝洛奥里藏特|3100004','特雷西纳|3100018','若昂佩索阿|3100015','帕尔马斯|3100014','马卡帕|3100012','累西腓|3100010','库亚巴|3100009','福塔莱萨|3100007','弗洛里亚诺波利斯|3100006','大坎普|3100005','阿雷格里港|3100002','阿拉卡茹|3100001','特费|3100020','博阿维斯塔|3100021','因佩拉特里斯|3100022','圣路易斯|3100023','戈亚尼亚|3100024',),
    '巴拿马' => array('巴拿马城|3090004','科罗纳多|3090002','David|3090003','博卡斯德尔托罗|3090001','阿利根帝|3090005',),
    '阿根廷' => array('布宜诺斯艾利斯|3030001','马德普拉港|3030008','门多萨|3030003','乌斯怀亚|3030012','萨尔塔|3030005','内乌肯|3030004','卡塔马卡|3030002','圣米格尔-德图库曼|3030006','雷西斯滕西亚|3030007','布兰卡港|3030009','里瓦达维亚准将城|3030010','里奥加耶戈斯|3030011','马金乔|3030013','欧贝拉|3030014','蒂诺加斯塔|3030015','奇佩斯|3030016','哈察尔|3030017','拉斯弗洛雷斯|3030018','圣马丁|3030019','乌斯帕雅塔|3030020',),
    '牙买加' => array('内格里尔|3370002','奥乔里奥斯|3370001',),
    '古巴' => array('哈瓦那|3180005','卡马圭|3180006','古巴圣地亚哥|3180004','西恩富戈斯|3180010','比那尔德里奥|3180003','关塔那摩|3180018','科科岛|3180027','吉隆滩|3180009','巴亚莫|3180002','马坦萨斯|3180008','曼萨尼约|3180007','奥尔金|3180001','阿尔特米萨|3180011','巴拉科亚|3180012','巴塔瓦诺|3180013','凯巴连|3180014','孔特拉马埃斯特雷|3180015','埃斯梅拉达|3180016','佛罗里达州|3180017','霍贝拉诺斯|3180019','努埃维塔斯|3180020','翁达港|3180021','巴乌达|3180022','克鲁斯角|3180023','卡波圣安东尼奥|3180024','卡米洛西恩富戈斯|3180025','波多黎各|3180028','雅布|3180029','大佩德拉|3180030','古奥罗|3180031','吉内斯|3180032','伊莎贝尔卢比奥|3180033','哈圭格兰|3180034','胡卡罗|3180035','拉帕玛|3180036','拉斯图纳斯|3180037','帕洛瑟可|3180038','皮可圣胡安|3180039','比那尔德里奥省|3180040','帕德雷港|3180042','潘达鲁克蕾西亚|3180043','大萨瓜|3180044','圣斯皮里图斯|3180045','圣胡安马丁内斯|3180046','圣卢西亚|3180047','南圣克鲁斯|3180048','尤尼弗西蒂|3180049','维拉斯科|3180050',),
    '乌拉圭' => array('科洛尼亚|3360016','阿蒂加斯|3360006','萨尔托|3360013','梅洛|3360009','帕索德洛斯托罗斯|3360017','特雷塔伊特雷斯|3360005','派桑杜|3360004','查皮库伊|3360003','埃斯特角|3360002','埃尔帕索德洛斯托罗斯|3360001','杜拉斯诺|3360007','梅赛德斯|3360010','里维拉|3360011','罗查|3360012','塔夸伦博|3360014','卡拉斯科|3360015','普拉多|3360018','特雷因塔伊特雷斯|3360019',),
    '委内瑞拉' => array('加拉加斯|3350009','马拉开波|3350016','马拉凯|3350015','委内瑞拉|3350020','科罗|3350012','卡贝略|3350032','卡拉沃索|3350022','吉里亚|3350029','图梅雷莫|3350018','乌帕塔|3350019','梅内格兰德|3350017','库马纳|3350014','科洛尼亚托瓦尔|3350013','卡维马斯|3350011','坎陶拉|3350010','圭亚那城|3350008','瓜雷纳斯|3350007','波拉马尔|3350006','巴里纳斯|3350005','巴莱拉|3350004','巴基西梅托|3350003','安蒂马诺|3350002','阿卡里瓜|3350001','阿亚库乔港|3350021','扎尔|3350023','瓜纳雷|3350024','马图林|3350025','玻利瓦尔城|3350027','瓜斯杜阿里托|3350028','拉奥契拉岛|3350030','阿亚库齐港|3350031','圣安东尼奥塔奇拉|3350033','圣费尔南多德亚布雷|3350034','圣多明戈|3350035','帕斯夸谷镇|3350036',),
    '危地马拉' => array('危地马拉|3340009','蒂卡尔|3340010','韦韦特南戈|3340008','奇马尔特南戈省|3340007','南戈|3340006','马萨特南戈|3340005','雷塔卢|3340004','哈拉帕|3340003','波普通|3340002','巴里奥斯港|3340001',),
    '特立尼达和多巴哥' => array('西班牙港|3330001','特立尼达|3330002',),
    '苏里南' => array('帕拉马里博|3320001','尼克里|3320004','帕拉南|3320002','卡巴莱博|3320003','西帕利维尼|3320005','斯托尔曼赛尔|3320006','塔菲尔伯格|3320007',),
    '圣文森特和格林纳丁斯' => array('金斯敦|3310002','比奎阿|3310001',),
    '圣卢西亚' => array('卡斯特里|3300002','丹讷里|3300001',),
    '萨尔瓦多' => array('圣萨尔瓦多|3290002','乌苏卢坦|3290004','松索|3290003','阿卡胡特拉|3290001',),
    '尼加拉瓜' => array('马那瓜|3280002','Rivas|3280013','圣卡洛斯|3280014','Leon|3280008','奇南德加|3280003','卡贝萨斯港|3280001','希诺特加|3280004','Bluefields|3280005','Corinto|3280006','Juigalpa|3280007','Masatepe|3280009','Nagarote|3280010','Ocotal|3280011','Posoltega|3280012',),
    '马提尼克' => array('法兰西堡|3240001','圣皮埃尔市|3240002',),
    '荷属安的列斯群岛' => array('克拉伦迪吉克|3210001',),
    '海地' => array('太子港|3200003','佩蒂翁维尔|3200002','戈纳伊夫|3200001','海地角|3200004',),
    '瓜德罗普' => array('巴斯特尔|3190001','珀蒂堡|3190004','路易港|3190003','彼得尔角城|3190002',),
    '哥斯达黎加' => array('阿拉胡埃拉|3170001','蓬塔雷纳斯|3170004','利蒙港|3170002','图里亚尔瓦|3170003',),
    '法属圭亚那' => array('卡宴|3150001','锡纳马里|3150002',),
    '厄瓜多尔' => array('基多|3140005','瓜亚基尔|3140003','昆卡|3140007','加拉帕戈斯群岛|3140004','曼塔|3140012','安巴托|3140001','萨利纳斯|3140013','马查拉|3140011','洛哈|3140010','里奥班巴|3140009','拉塔昆加|3140008','凯扬波|3140006','波托维耶霍|3140002','圣克里斯托巴尔岛|3140014',),
    '多明尼加' => array('卡布雷拉|3130002','布拉达港|3130006','罗索|3130001','希马尼|3130003','巴拉宏那|3130004','埃雷拉|3130005',),
    '伯利兹' => array('伯利兹市|3120002','贝尔莫潘|3120001','半月岛|3120003',),
    '玻利维亚' => array('苏克雷|3110010','波托西|3110002','塔里哈|3110011','科恰班巴|3110005','奥鲁罗|3110001','圣哈维尔|3110024','马格达莱纳|3110009','罗沃雪|3110008','鲁雷纳瓦克|3110007','奎拉乔洛|3110006','科罗伊科|3110004','瓜亚拉美林|3110003','卡米里|3110012','科维哈|3110013','雷耶斯|3110015','里韦拉尔塔|3110016','比亚蒙特斯|3110017','雅古巴|3110018','阿波罗|3110019','查拉纳|3110020','圣华金|3110021','圣塔安娜|3110022','圣博尔加|3110023','维鲁维鲁|3110025',),
    '巴拉圭' => array('新亚松森|3080006','埃斯特城|3080002','亚松森|3080007','佩卓璜卡巴耶洛|3080015','蓬塔里埃雷斯|3080005','堡奥林波|3080004','奥维多上校|3080003','埃斯蒂加里维亚元帅镇|3080001','Encarnacion|3080009','Paraguari|3080010','Pilar|3080011','比亚|3080012','巴伊亚内格拉港|3080013','卡萨帕|3080014','萨尔托德尔瓜|3080016','圣埃斯塔尼斯劳|3080017','圣胡安波蒂斯塔|3080018',),
    '巴哈马' => array('拿骚|3070005','比米尼群岛|3070002','安德罗斯镇|3070001','弗里波特|3070006','科伯恩城|3070011','马修镇|3070004','卡特岛|3070003','亚伯拉罕斯湾|3070007','艾丽斯镇|3070008','格鲁夫教堂|3070009','克拉仑斯镇|3070010','刚果镇|3070012','邓肯镇|3070013','海龟湾|3070015','坎普斯湾|3070016','莫斯镇|3070017','北伊柳塞拉|3070018','普罗维登西亚莱斯|3070019','罗克桑德|3070020','海湾|3070021','特克斯岛|3070022','威斯特安德|3070023',),
    '巴巴多斯' => array('布里奇敦|3060001',),
    '安圭拉' => array('安圭拉岛|3050002','红花山|3050001',),
    '阿鲁巴' => array('奥拉涅斯塔克|3040001',),
    '维尔京群岛' => array('夏洛特阿马里|3380031','罗德城|3380025',),
    '圭亚那' => array('乔治城|3380030','凯厄图尔瀑布|3380038','新阿姆斯特丹|3380042','卡马朗|3380039','莱瑟姆|3380040','马巴鲁马|3380041',),
  ),

  '大洋洲' => array(

    '澳大利亚' => array('悉尼|4040116','墨尔本|4040082','布里斯班|4040013','黄金海岸|4040135','堪培拉|4040049','珀斯|4040004','科夫斯港|4040052','霍巴特|4040034','古尔本|4040031','维克多港|4040104','爱丽斯泉|4040002','奥古斯塔港|4040128','哲朗|4040126','尤丹达|4040124','伊丽莎白|4040123','耶蓬|4040122','亚斯|4040121','扬塔|4040120','扬加拉|4040119','延杜穆|4040118','亚历山德拉|4040117','谢珀顿|4040115','谢尔哈伯|4040114','圣何塞|4040113','武麦拉|4040112','伍洛格朗|4040111','伍拉梅尔|4040108','伍尔古尔加|4040107','沃盖特|4040106','韦里斯溪|4040105','瓦努韦|4040103','旺内鲁|4040102','提伯布拉|4040100','天鹅岛|4040099','滕南特克里克|4040098','特尔弗采矿中心|4040097','泰弗纳德岛|4040096','索雷尔|4040095','斯旺伯恩|4040094','桑古|4040093','萨戈明达|4040092','佩恩斯范恩德|4040091','帕拉马塔|4040090','诺斯曼|4040089','努里乌特帕|4040088','宁根|4040087','楠布卡黑兹|4040086','纳拉库特|4040085','纳拉伯|4040084','莫鲁亚海兹|4040083','默宾|4040081','米灵金比|4040080','米卡萨拉|4040079','马塔兰卡|4040078','马宁里达|4040077','曼德拉|4040076','马鲁兰迪|4040075','玛拉|4040073','麦夸里岛|4040072','马布尔巴|4040071','罗特尼斯特岛|4040070','洛坎普顿|4040069','罗伯恩|4040068','伦马克|4040067','里尔莫斯|4040065','雷德斯代尔|4040064','拉皮德湾|4040063','兰斯林|4040062','拉默鲁|4040060','库奴纳拉|4040059','昆比恩|4040058','奎纳纳|4040057','奎尔皮|4040056','库尔戈拉|4040055','库伯佩迪|4040054','科里金|4040053','科尔斯点|4040051','卡通巴|4040050','坎纳马拉|4040048','卡穆威尔|4040046','卡拉曼达|4040045','卡拉德拉|4040044','凯乐尔|4040043','凯恩卡塔|4040042','卡尔古利|4040041','卡尔巴里|4040040','金格罗伊|4040039','吉姆纳|4040037','杰维斯湾|4040036','霍登谷|4040035','赫伦岛|4040033','黑镇|4040032','戈兹沃西|4040030','戈斯内尔斯|4040029','冈尼达|4040027','盖恩达|4040026','弗里曼特尔|4040025','弗兰克斯顿|4040024','德韦令阿普|4040023','德比|4040022','丹皮尔|4040021','丹德农|4040020','戴利沃特斯|4040019','达尔文|4040018','达博|4040017','布洛古罗|4040016','布利亚|4040014','布莱科尔|4040012','波拉尔|4040011','博尔达角|4040010','拉里马|4040009','宾利|4040008','巴朱尔|4040007','班克斯|4040006','巴拉多尼亚|4040005','奥古斯塔|4040003','阿得雷德|4040001','凯恩斯|4040149','米尔迪拉|4040127','林肯港|4040129','杰拉尔顿|4040130','黑德兰港|4040131','伊萨山市|4040133','汤斯维尔|4040134','阿米代尔|4040136','亚勒旺加|4040138','阿黛勒岛|4040139','阿尔瓦海滩|4040140','安达目卡|4040141','阿灵顿礁|4040142','阿尔敦加|4040143','奥斯汀平原|4040144','巴尔戈丘|4040145','巴尔拉纳德|4040146','温德姆|4040147','依利里|4040148',),
    '新西兰' => array('惠灵顿|4080014','基督城|4080016','奥克兰|4080002','罗托鲁瓦|4080024','达尼丁|4080005','马丁堡|4080025','沃克沃斯|4080046','拉姆斯登|4080049','因弗卡吉尔|4080043','希克斯湾|4080042','下哈特|4080041','塔坡|4080040','陶玛鲁努伊|4080039','塔拉岱尔|4080038','塔卡普纳|4080037','上哈特|4080036','塞夫顿|4080035','普雷鲁阿|4080034','普雷|4080033','帕帕托伊托伊|4080032','帕拉帕拉乌穆|4080031','帕波库拉|4080030','摩斯吉尔|4080029','马斯特顿|4080028','玛努考|4080027','马卡雷瓦|4080026','里卡顿|4080023','卡斯尔波因特|4080022','卡尼里|4080021','凯塔亚|4080020','凯库拉|4080019','凯厄波伊|4080018','卡尔弗登|4080017','霍基蒂卡|4080015','璜加雷|4080013','怀韦拉|4080012','怀塔提|4080011','怀帕拉|4080010','怀欧鲁|4080009','怀霍拉|4080008','哈韦拉|4080007','格雷茅斯|4080006','波里鲁瓦|4080004','北帕默斯顿|4080003','奥卡里托|4080001','内皮尔|4080044','凯里凯里|4080045','兄弟岛|4080047','城堡角|4080048','米尔福德桑德|4080050','牙威|4080051','奥哈基|4080052','劳尔岛|4080053','蒂芬斯岛|4080054','陶兰加港|4080055','提马鲁港|4080056','特威泽尔|4080057','韦斯特波特港|4080058','方格帕罗河|4080059','弗努阿派|4080060','威格拉姆|4080061','阿塔富|4080062','努库诺诺环礁|4080063','努库诺努|4080064',),
    '斐济' => array('苏瓦|4090002','瓦努阿岛|4090023','劳托卡|4090018','罗图马岛|4090022','瓦努阿巴拉乌|4090025','威尼塞阿岛|4090026','马图库|4090001','兰巴萨|4090016','莱克巴|4090017','马特|4090019','瑙索里|4090020','楠迪|4090021','亚萨瓦岛|4090024',),
    '汤加' => array('努库阿洛法|4090039','诺穆卡|4090040','瓦瓦乌|4090041',),
    '瓦努阿图' => array('维拉港|4090045','阿内蒂乌姆|4090046','拉马普|4090047',),
    '瑙鲁' => array('亚伦|4090005','瑙鲁|4090035','巴纳巴岛|4090034',),
    '所罗门群岛' => array('奥基|4070002','霍尼亚拉|4070001','蒙达|4070004','基拉基拉|4070003','塔洛岛|4070005',),
    '基里巴斯' => array('塔拉瓦|4060002','坎顿岛|4060005','莫尔岛|4060006','布塔里塔里|4060001','阿罗拉亚岛|4060003','贝鲁|4060004',),
    '巴布亚新几内亚' => array('莫尔兹比港|4050017','韦瓦克|4050019','瓦尼莫|4050006','莱城|4050003','阿拉瓦|4050005','萨马赖|4050002','莫罗贝|4050001','金贝|4050004','基永加|4050007','阿格瓦|4050008','格尼|4050010','霍斯金斯|4050011','卡维恩|4050012','高伊纳贝|4050013','马当|4050014','米西马|4050015','努库瑞亚|4050016','塞拉莫|4050018',),
    '北马里亚纳群岛邦' => array('塞班岛|4090003',),
    '关岛' => array('阿加尼亚|4090004',),
    '萨摩亚' => array('阿皮亚|4090007','帕果帕果|4090006',),
    '图瓦卢' => array('Funafuti|4090008','纽基拉塔|4090044','阿绍|4090042','纳奴米|4090043',),
    '新喀里多尼亚' => array('努美阿|4090010','马修|4090037','库马克|4090009','拉罗史|4090036',),
    '库克群岛' => array('拉罗汤加|4090015','贾维斯岛|4090012','帕墨斯顿岛|4090013','阿洛菲|4090011','普卡普卡|4090014',),
    '波利尼西亚' => array('波拉波拉岛|4090028','拉帕|4090027','曼格雷哇岛|4090029','伦吉拉环礁|4090030','塔卡罗阿环礁|4090031','罗阿岛|4090032','土布艾群岛|4090033',),
    '皮特凯恩群岛' => array('皮特凯恩|4090038',),
  ),



  '非洲' => array(

    '埃及' => array('开罗|5060005','卢克索|5060006','阿斯旺|5060002','赫尔格达|5060003','沙姆沙伊赫|5060008','苏伊士|5060009','扎加齐格|5060011','伊斯梅利亚|5060010','萨尔瓦多阿里什|5060007','基纳|5060004','艾斯尤特|5060001','卢克索|5060012','杜姆亚特|5060013','罗塞塔|5060014','阿布辛拜勒|5060015','巴哈利亚|5060016','巴尔的姆|5060017','达哈布|5060018','里士|5060019','哈萨纳|5060020','费拉菲拉|5060021','法尤姆|5060022','吉萨|5060023','阿勒旺|5060024','洪加达|5060025','洪加达污染区|5060026','库赛尔|5060027','明亚|5060028','努扎|5060029','拉法赫|5060030','希宾库姆|5060031','锡瓦|5060032','南谷大学|5060033','亚历山大|5060034','塔里尔|5060035',),
    '摩洛哥' => array('舍夫沙万|5330019','马拉喀什|5330024','卡萨布兰卡市|5330001','丹吉尔|5330004','瓦尔扎扎特|5330025','索维拉|5330006','梅克内斯|5330011','拉巴特|5330002','阿加迪尔|5330003','纳祖尔|5330005','伊夫兰|5330007','盖尼特拉|5330008','胡里卜盖|5330009','拉腊什|5330010','米德勒特|5330012','穆罕默迪耶|5330013','乌季达|5330014','塔鲁丹特|5330015','提兹尼特|5330016','胡塞马群岛|5330017','贝尼梅拉尔|5330018','贾迪达|5330020','埃拉契迪亚|5330021','卡斯巴泰德拉|5330022','阿尤恩|5330023','番摊|5330026','得土安|5330027',),
    '突尼斯' => array('突尼斯|5430007','苏塞|5430006','斯法克斯|5430005','比塞大|5430001','纳布勒|5430013','梅德宁|5430020','雷马达|5430004','加夫萨|5430003','加贝斯|5430002','贝雅|5430008','坚杜拜|5430009','卡塞林|5430010','吉比利|5430011','马迪亚|5430012','锡勒亚奈|5430014','塔巴卡|5430015','泰塔温|5430016','托泽尔|5430017','宰格万|5430018','加利比亚|5430019','西吉布吉特|5430021',),
    '南非' => array('约翰内斯堡|5360023','开普敦|5360013','杰米斯顿|5360010','比勒陀利亚|5360006','德班|5360008','内斯普利特|5360016','赫曼努斯|5360031','亚历山大湾|5360059','波特维尔|5360109','温特斯多普|5360125','马姆斯伯里|5360039','阿多大象公园|5360058','伊洛沃|5360022','伊丽莎白港|5360021','威特班克|5360020','通加特|5360019','索韦托|5360018','帕尔|5360017','肯普顿公园|5360015','克鲁格斯多普|5360014','卡尔文尼亚|5360012','金伯利|5360011','哈加-哈加|5360009','布隆方丹|5360007','彼得斯堡|5360005','彼得马里茨堡|5360004','巴克利西|5360003','阿平顿|5360002','奥埃滕哈赫|5360001','博福特西|5360024','贝瑟尔|5360025','埃利奥特|5360027','埃尔默洛|5360028','格雷厄姆|5360029','格雷顿|5360030','卡图|5360032','克莱克斯多普|5360033','克尼斯纳|5360034','克龙斯塔德|5360035','库鲁曼|5360036','利克田堡|5360037','莱登堡|5360038','马盖特|5360040','纽卡斯尔|5360041','奥次颂|5360042','帕拉博鲁瓦|5360043','波洛|5360044','普里斯卡|5360045','皇后镇|5360046','勒斯滕堡|5360047','斯普林博克|5360048','塔巴津比|5360049','托霍延杜|5360050','乌伦迪|5360051','乌姆塔塔|5360052','弗里尼欣|5360053','弗雷登达尔|5360054','弗雷堡|5360055','弗雷黑德|5360056','韦尔科姆|5360057','奥赫拉比斯瀑布|5360060','东巴克利|5360061','毕斯合|5360062','布韦岛|5360063','圣布雷兹岬|5360064','圣弗朗西斯角|5360065','厄加勒斯岬|5360066','开普敦港|5360067','卡罗莱纳|5360068','克兰威廉|5360069','咖啡湾|5360070','科菲蒙瓦巴|5360071','达森岛|5360072','德班弗吉尼亚|5360073','东伦敦|5360074','艾斯特科特|5360075','福尔史密斯|5360076','费克斯堡|5360077','波福堡|5360078','夫拉则堡|5360079','嘎瑞普水库|5360080','巨人城堡|5360081','好望角|5360082','戈夫岛|5360083','赫拉夫·里内特|5360084','中央|5360085','格拉斯科普|5360086','侯斯普瑞特|5360087','詹姆斯敦|5360088','基特曼斯胡普|5360089','高林奈思|5360090','莱迪史密斯|5360091','兰斯堡|5360092','拉法拉勒|5360093','马拉|5360094','马尔肯|5360095','马塞卢|5360096','马塔泰勒|5360097','马泽帕湾|5360098','莫霍特隆|5360099','莫尔蒂诺湖|5360100','穆伊河|5360101','尼湖德维|5360102','帕多克|5360103','匹兰斯堡|5360104','普利登堡湾|5360105','蓬戈拉|5360106','爱德华港|5360107','诺洛斯港|5360108','加查斯内克|5360110','理查兹湾|5360111','里佛斯达|5360112','罗布恩岛|5360113','罗伯森|5360114','皇家国家公园|5360115','史库库莎|5360116','东索美塞特|5360117','斯特兰德|5360118','萨瑟兰|5360119','汤恩|5360120','柴邦|5360121','奇皮塞|5360122','齐齐卡马|5360123','范瑞恩|5360124','维佩纳|5360126',),
    '马达加斯加' => array('塔那那利佛|5480065','马哈赞加|5480009','安齐拉纳纳|5480010','图阿马西纳|5480011','安楚希希|5480017','菲亚纳兰楚阿|5480028','穆龙达瓦|5480036','法拉凡加纳|5480012','图莱亚尔|5480013','安达帕|5480015','安塔拉哈|5480016','马哈努鲁|5480032','马南扎里|5480033','桑巴瓦|5480041','阿纳拉拉瓦|5480066','安齐拉贝|5480067','贝萨兰皮|5480068','法夸尔|5480069','诺西贝|5480070','法奥克斯卡波|5480071','马门提腊奴|5480072','穆龙贝|5480073','武海马尔|5480074',),
    '毛里求斯' => array('阿加莱加|5480082','普莱桑斯|5480084','罗德里格斯岛|5480085','瓦科阿|5480044','普莱恩珊瑚岛|5480083','圣布兰登|5480086',),
    '塞舌尔' => array('普拉兰岛|5480091','阿尔达布拉|5480089','德罗什|5480090',),
    '阿尔及利亚' => array('阿尔及尔|5050001','安纳巴|5050002','巴特纳|5050026','奥兰|5050003','阿德拉尔|5050032','提米蒙|5050017','伊利济|5050023','瓦尔格拉|5050022','图古尔特|5050021','提亚雷特|5050020','廷杜夫|5050019','提奈斯|5050018','塔希费特|5050016','塔曼拉塞特|5050015','泰贝萨|5050014','斯基克达|5050013','塞提夫|5050012','穆斯塔加奈姆|5050011','迈舍里耶|5050010','贾奈特|5050009','盖尔达耶|5050008','布阿拉里季堡|5050007','贝沙尔|5050006','贝尼阿巴斯|5050005','贝贾亚|5050004','拉格瓦特|5050024','巴里卡|5050025','康斯坦丁|5050027','代利斯|5050028','盖尔马|5050029','纳马|5050030','赛达|5050031','艾因塞夫拉|5050033','阿尔泽|5050034','贝贾亚港|5050035','贝尼萨夫|5050036','比斯克拉|5050037','布维拉|5050038','谢利夫|5050039','杰勒法|5050040','埃尔果累阿|5050041','加扎乌埃特|5050042','英纳梅那斯|5050043','英盖扎姆|5050044','因萨拉赫|5050045','吉杰勒港|5050046','姆西拉|5050047','米利亚纳|5050048','苏克阿赫拉斯|5050049','提济乌祖|5050050',),
    '埃塞俄比亚' => array('亚的斯亚贝巴|5070002','贡德尔|5070001','巴赫达尔|5070005','默克莱|5070009','阿瓦萨|5070004','戈尔|5070003','德雷达瓦|5070006','戈德|5070007','季马|5070008','梅特哈拉|5070010',),
    '安哥拉' => array('罗安达|5080001','万博|5080002','梅农盖|5080008','卢班戈|5080003','内加热|5080022','本格拉|5080004','洛比托港|5080005','卡宾达|5080006','卢埃纳|5080007','恩泽托|5080009','绍里木|5080010','松贝|5080011','比耶|5080012','卡马克斯洛|5080013','卡莫纳|5080014','卡宗博|5080015','敦多|5080016','马兰热|5080017','马文加|5080018','木萨米迪什|5080019','蒙巴卡|5080020','恩达拉坦多|5080021','安博因港|5080023','洛卡达斯|5080024',),
    '贝宁' => array('波多诺伏|5090001',),
    '博茨瓦纳' => array('哈博罗内|5100003','马翁|5100008','弗朗西斯敦|5100002','马哈拉佩|5100007','杭济|5100004','察内|5100001','卡萨内|5100005','莱特拉卡内|5100006','哈伯罗内|5100009','朱瓦能|5100010','梅富根|5100011','西雷毕菲克威|5100012',),
    '布基纳法索' => array('瓦加杜古|5110001','博博迪乌拉索|5110006','加瓦|5110004','瓦希古亚|5110005','博罗莫|5110002','汤姆|5110003','法达恩古尔马|5110007',),
    '布隆迪' => array('布琼布拉|5120001','穆因加|5120002',),
    '赤道几内亚' => array('马拉博|5130001','巴塔|5130002',),
    '多哥' => array('洛美|5140001',),
    '厄立特里亚' => array('阿斯马拉|5150001','马萨瓦|5150003','厄立特里亚|5150004','阿萨布|5150002',),
    '佛得角' => array('普拉亚|5160001','明德卢|5160002',),
    '冈比亚' => array('班珠尔|5170001','凯雷万|5170003','贝士|5170004','萨普|5170005',),
    '刚果' => array('黑角|5180001','布拉柴维尔|5180004','多利西|5180006','马卡巴纳|5180012','凯莱|5180011','因普丰多|5180003','马丁戈-卡伊|5180002','兼巴拉|5180005','甘博马|5180007','马夸|5180008','韦索|5180009','锡比提|5180010','穆永济|5180013','苏安凯|5180014',),
    '刚果民主共和国' => array('金沙萨|5190002','卢本巴希|5190006','布卡武|5190015','戈马|5190021','基桑加尼|5190003','洛贾|5190032','乌维拉|5190009','姆班达卡|5190008','马塔迪|5190007','利卡西|5190005','卡南加|5190004','博马|5190001','科卢韦齐|5190010','姆布吉马伊|5190011','班顿杜|5190012','巴索科|5190013','博恩|5190014','本巴|5190016','布尼亚|5190017','布塔|5190018','布滕博|5190019','盖梅纳|5190020','伊莱博|5190022','伊农戈|5190023','伊西罗|5190024','卡莱米|5190025','卡松戈|5190026','基奎特|5190027','金杜|5190028','孔戈洛|5190029','利本盖|5190030','利萨拉|5190031','奇卡帕|5190033','瓦察|5190034','巴山库苏|5190035','邦多|5190036','迪罗罗|5190037','易博尔|5190038','因加|5190039','卡利马|5190040','根盖|5190041','齐托纳|5190042','鹿山堡|5190043','卢本巴希卢阿诺|5190044','卢奥济|5190045','卢布塔|5190046','马巴萨|5190047','马诺诺|5190048','米特瓦巴|5190049','莫安达|5190050','鲁丘鲁|5190051','桑多亚|5190052',),
    '吉布提' => array('吉布提|5200001',),
    '几内亚' => array('科纳克里|5210002','康康|5210004','拉贝|5210007','博法|5210001','巴法塔|5210011','博拉马|5210012','博克|5210003','金迪亚|5210005','基西杜古|5210006','马森塔|5210008','马木|5210009','锡吉里|5210010',),
    '几内亚比绍' => array('比绍|5220001',),
    '加纳' => array('阿克拉|5230001','特马|5230010','库马西|5230002','塔马利|5230009','阿库斯|5230016','延迪|5230012','阿卡赤|5230014','阿克西姆|5230003','科福里杜亚|5230004','纳夫龙戈|5230005','萨尔特庞德|5230006','苏尼亚尼|5230007','塔科拉迪|5230008','文奇|5230011','阿达|5230013','阿奇莫达|5230015','阿塔帕梅|5230017','玻尔|5230018','喀拉海|5230019','克特克拉契|5230020','芒戈|5230021','拉马卡拉|5230022','索科德|5230023',),
    '加蓬' => array('利伯维尔|5240001','马永巴|5240006','比塔姆|5240003','让蒂尔港|5240002','兰巴雷内|5240004','马科库|5240005','米齐克|5240007','奇班加|5240008',),
    '津巴布韦' => array('哈拉雷|5250004','布拉瓦约|5250001','卡里巴|5250011','马旬戈|5250003','万基国家公园|5250017','达尔文山|5250020','西尼科尔森|5250024','鲁萨佩|5250002','拜特布里奇|5250005','奇诺伊|5250006','奇平盖|5250007','戈奎|5250008','圭鲁|5250009','卡多马|5250010','卡罗伊|5250012','奎奎|5250013','兹维沙瓦内|5250014','布法罗伦奇|5250015','大草原|5250016','卡尼耶恩巴|5250018','玛卡恩伽|5250019','恩伽布|5250021','恩卡伊|5250022','蒂约罗|5250023',),
    '喀麦隆' => array('雅温得|5260005','杜阿拉|5260004','巴门达|5260006','克里比|5260010','埃代阿|5260001','马鲁阿萨拉克|5260015','布埃亚|5260003','巴富萨姆|5260002','巴图里|5260007','贝尔图阿|5260008','加鲁瓦|5260009','马姆费|5260011','恩冈代雷|5260012','恩康桑巴|5260013','阿邦姆邦|5260014',),
    '科特迪瓦' => array('阿比让|5270001','亚穆苏克罗|5270013','大巴萨姆|5270002','布瓦凯市|5270005','科霍戈|5270009','圣佩德罗|5270014','阿迪亚克|5270003','邦杜库|5270004','达洛亚|5270006','丁博克罗|5270007','加尼奥阿|5270008','Man|5270010','奥迭内|5270011','萨桑德拉|5270012',),
    '肯尼亚' => array('内罗毕|5280011','纳库鲁|5280010','马萨比特|5280008','拉姆|5280015','基苏木|5280004','加里萨|5280003','沃伊|5280012','锡卡|5280013','蒙巴萨|5280009','洛德瓦尔|5280007','卡卡梅加|5280006','基西|5280005','阿西河|5280002','埃尔多雷特|5280001','基塔莱|5280014','瓦吉尔|5280016','古鲁|5280017','马辛迪|5280018','索罗蒂|5280019',),
    '利比里亚' => array('蒙罗维亚|5290001','利比里亚|5290002',),
    '卢旺达' => array('基加利|5300001','吉塞尼|5300003','布塔雷|5300002','卡门贝|5300004','鲁亨盖里|5300005',),
    '马拉维' => array('利隆圭|5310001','卡龙加|5310004','萨利马|5310008','恩科塔科塔|5310007','猴子湾|5310013','奇莱卡|5310011','奇蒂帕|5310002','代扎|5310003','卡松古|5310005','曼戈切|5310006','波莱罗|5310009','井宿|5310010','曼考卡|5310012',),
    '马里' => array('巴马科|5320001','莫普提|5320003','加奥|5320004','萨恩|5320010','锡卡索|5320011','泰萨利|5320014','塞古|5320002','布古尼|5320005','基达尔|5320006','奇塔|5320007','库蒂亚拉|5320008','梅娜卡|5320009','洪博里|5320012','凯涅巴|5320013','通布图|5320015','耶利马内|5320016',),
    '莫桑比克' => array('马普托|5340001','楠普拉|5340015','贝拉|5340003','卡亚|5340012','维兰库卢什|5340017','克利马内|5340009','马希谢|5340002','希莫尤|5340004','库安巴|5340005','伊尼扬巴内|5340006','利欣加|5340007','奔巴岛|5340008','太特|5340010','安戈谢|5340011','伦博|5340013','蒙特普埃兹|5340014','佩巴内|5340016','赛赛|5340018','宗博|5340019',),
    '纳米比亚' => array('温得和克|5350001','鲸湾佩利肯角|5350010','奥乔|5350007','赫鲁特方丹|5350003','奥马鲁鲁|5350005','戈巴比斯|5350002','马林塔尔|5350004','翁旦格瓦|5350006','朗杜|5350008','奥考奎约|5350009',),
    '尼日利亚' => array('阿布贾|5370002','拉各斯|5370009','伊巴丹|5370011','迈杜古里|5370010','卡诺|5370008','阿贝奥库塔|5370001','乔斯|5370019','贝宁城|5370031','哈科特港|5370037','约拉|5370030','扎里亚|5370012','卡拉巴尔|5370007','比尔宁凯比|5370006','奥约|5370005','奥尼查|5370004','埃努古|5370003','索科托|5370013','博契|5370014','尔必达|5370015','揖斐|5370016','伊科姆|5370017','伊洛林|5370018','卡杜纳|5370020','卡齐纳|5370021','罗科贾|5370022','马库尔迪|5370023','明娜|5370024','恩古鲁|5370025','翁多|5370026','波提斯昆|5370027','瓦里|5370028','耶卢瓦|5370029','古绍|5370032','康迪|5370033','纳蒂廷古|5370034','奥绍博|5370035','帕拉库|5370036','萨瓦河|5370038',),
    '塞拉利昂' => array('弗里敦|5380001','博|5380002','考度|5380007','邦特|5380003','达鲁|5380004','马可尼|5380005','隆吉|5380006','冶勒|5380008',),
    '塞内加尔' => array('达喀尔|5390001','马塔姆|5390012','考拉克|5390004','济金绍尔|5390003','科尔达|5390007','坦巴昆达|5390008','久尔贝勒|5390010','姆布尔|5390005','捷斯|5390002','凯杜古|5390006','斯基灵角|5390009','林盖尔|5390011','波多尔|5390013',),
    '苏丹' => array('喀土穆|5400001','苏丹港|5400004','马拉卡尔|5400002','朱巴|5400014','萨瓦金|5400020','瓦乌|5400021','卡萨拉|5400007','瓦德马达尼|5400005','尼亚拉|5400003','阿特巴拉|5400006','科斯蒂|5400008','托卡|5400009','阿尔巴特|5400010','栋古拉|5400011','埃尔奥贝德|5400012','格达雷夫|5400013','卡瑞玛|5400015','拉珈|5400016','拉沙德|5400017','伦克|5400018','第六站|5400019',),
    '索马里' => array('摩加迪沙|5410001','哈尔格萨|5410011','基斯马尤|5410007','加勒卡约|5410009','柏培拉|5410002','阿卢拉|5410003','巴尔代雷|5410004','博萨索|5410005','布劳|5410006','埃里加伏|5410008','加尔多|5410010','拉斯阿诺得|5410012','奥比亚|5410013','斯库斯休班|5410014',),
    '坦桑尼亚' => array('多多马|5420001','姆万扎|5420005','达累斯萨拉姆|5420002','坦噶|5420007','桑给巴尔|5420006','姆特瓦拉|5420004','姆贝亚|5420008','莫希|5420014','穆索马|5420015','阿鲁沙|5420010','伊林加|5420012','马鲁库|5420003','基戈马|5420009','布科巴|5420011','莫罗戈罗|5420013','纳钦圭阿|5420016','希尼安加|5420017','辛吉达|5420018','松盖阿|5420019','松巴万加|5420020',),
    '乌干达' => array('坎帕拉|5440002','阿鲁阿|5440003','神社|5440004','恩德培|5440001','卡巴莱|5440005','卡塞塞|5440006','姆巴拉拉|5440007','多罗罗|5440008','梅鲁|5440009',),
    '西撒哈拉' => array('别墅西斯内罗斯|5450001',),
    '赞比亚' => array('赞比西河|5460023','卢萨卡|5460003','卡布韦|5460002','恩多拉|5460001','基特韦|5460006','曼萨|5460014','利文斯通|5460005','卡萨马|5460011','姆祖祖|5460028','钦戈洛|5460004','奇帕塔|5460007','乔马|5460008','伊索卡|5460009','卡奥马|5460010','卡森帕|5460012','卡万布瓦|5460013','姆巴拉|5460015','芒古|5460016','姆皮卡|5460017','布瓦|5460018','姆维尼伦加|5460019','佩塔乌凯|5460020','塞谢凯|5460021','索卢韦齐|5460022','宾加|5460024','姆富韦|5460025','玛库鲁山|5460026','姆津巴|5460027','恩卡塔贝|5460029',),
    '乍得' => array('恩贾梅纳|5470001','帕拉|5470009','阿提|5470003','蒙杜|5470008','安提曼|5470010','戈兹贝达|5470013','阿贝歇|5470002','博科罗|5470004','布索|5470005','毛泽东|5470006','蒙戈|5470007','法达|5470011','法雅|5470012','萨尔|5470014',),
    '中非' => array('班吉|5480001','博桑戈阿|5480023','布阿尔|5480024','布里亚|5480025','莫巴伊|5480035','阿林道|5480014','班巴里|5480018','班加苏|5480019','贝贝拉蒂|5480020','比罗|5480022','奥博|5480039','耶林格|5480045',),
    '利比亚' => array('的黎波里|5480043','班加西|5480002','图卜鲁格|5480003','德尔纳|5480050','米苏拉塔|5480057','纳卢特|5480038','库夫拉|5480056','奥巴里|5480058','塞卜哈|5480059','加特|5480030','阿格达比亚|5480047','迈尔季|5480048','贝尼纳|5480049','奥哈马德|5480051','欧胡姆斯|5480052','加达迈斯|5480053','厚恩|5480054','伽罗|5480055','萨哈特|5480060','苏尔特|5480061','斯瓦尼|5480062','耶夫兰|5480063','兹瓦拉|5480064',),
    '毛里塔尼亚' => array('努瓦克肖特|5480004','努瓦迪布|5480005','提吉克贾|5480042','阿塔尔|5480076','卡埃迪|5480078','祖埃拉特|5480081','阿克儒特|5480075','布提利米特|5480077','基法|5480079','奈玛|5480080',),
    '尼日尔' => array('尼亚美|5480006','迪法|5480026','塔瓦|5480007','津德尔|5480008','马拉迪|5480034','比尔马|5480021','多索|5480027','古尔|5480031','阿加德兹|5480087','马伊内索罗阿|5480088',),
    '科摩罗' => array('马约特|5480046','莫罗尼|5480037','昂儒昂|5480040',),
  ),
  
);

/*
header("content-type: text/html; charset=utf-8");
//echo var_export($seek['china'], true);
//查重复县
$url = 'getweather_seek.php';
$f = file_get_contents($url);
$n = array();

$word = '市'; //区|镇|县|盟|市
preg_match_all('/\'([^\'\|]+)'.$word.'\|/isU', $f, $m);
foreach ($m[1] as $k=>$v) {
  if (!preg_match('/\''.preg_quote($v, '/').'\|/', $f)){
    $n[] = $v;
  }
}
if (count($n) > 0) {
  echo implode("|", $n);
} else {
  echo '没有查到县';
}


//查重复
$url = 'getweather_seek.php';
$f = file_get_contents($url);
$n = $arr = array();
preg_match_all('/\'(.+)\|(.+)\'/isU', $f, $m);
foreach ($m[1] as $k=>$v) {
  if (isset($arr[$v])) {
    $n[$v] = $arr[$v].' '.$v.'|'.$m[2][$k];
  } else {
    $arr[$v] = $v.'|'.$m[2][$k];
  }
}
if (count($n) > 0) {
  echo implode("\n", $n);
} else {
  echo '没有重复的城市';
}
*/

/*
//定期修正城市、拼音、代码等
ini_set('display_errors', false);
ini_set('default_charset', 'utf-8');
error_reporting(E_ERROR | E_WARNING | E_PARSE);
set_time_limit(0); require '../../function/read_file.php';
$text = '$seek[\'china\'] = array (
';
$url = 'https://www.tianqi.com/chinacity.html';
$f = read_file($url);
if ($f) {
  if (preg_match('/<div\s+class="citybox">(.+)<\/div><\/div>/isU', $f, $m)) {
    preg_match_all('/<h2><a\s+href="(\/province)?\/([\w-]+)\/">(.+)<\/a><\/h2><span>(.+)<\/span>/isU', $m[1], $shengs);
  }
}
foreach ($shengs[3] as $k=>$sheng) {
  $text .= '
  \''.strip_tags($sheng).'\'=>array(';
  if ($sheng=='北京'||$sheng=='天津'||$sheng=='上海'||$sheng=='重庆') {
    $text .= '
      \''.$sheng.'|'.$shengs[2][$k].'\'=>array(';
    preg_match_all('/<a\s+href="\/([\w-]+)\/">(.+)<\/a>/isU', $shengs[4][$k], $xians);
    foreach ($xians[2] as $i=>$xian) {
      $text .= '\''.$xian.'|'.$xians[1][$i].'\',';
    }
    $text .= '),';
  } else{
    $shengs[4][$k] = preg_replace('/<h3>/isU', '</AAA><h3>', $shengs[4][$k]).'</AAA>';
    preg_match_all('/<h3><a\s+href="\/([\w-]+)\/">(.+)<\/a><\/h3>(.*)<\/AAA>/isU', $shengs[4][$k], $shis);
    foreach ($shis[2] as $j=>$shi) {
      $text .= '
      \''.$shi.'|'.$shis[1][$j].'\'=>array(';
      preg_match_all('/<a\s+href="\/([\w-]+)\/">(.+)<\/a>/isU', $shis[3][$j], $xians);
      foreach ($xians[2] as $i=>$xian) {
        $text .= '\''.$xian.'|'.$xians[1][$i].'\',';
      }
      $text .= '),';
    }
  }
  $text .= '
  ),
';
}
$text .= '
);
';
echo $text;
*/







?>
