<?php
header("content-type: text/html; charset=utf-8");
$weatherurl = 'https://www.tianqi.com/';
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>天气</title>
<?php echo $web['slogan']; ?>
<link href="readonly/css/style.css?<?php echo filemtime('readonly/css/style.css'); ?>" rel="stylesheet" type="text/css">
<link href="readonly/css/<?php echo $web['cssfile']; ?>/style.css?<?php echo filemtime('readonly/css/'.$web['cssfile'].'/style.css'); ?>" rel="stylesheet" type="text/css" id="my_style">
<style type="text/css">
<!--
html { text-align:left; }
#tq { min-width:660px; margin-bottom:10px; background-color:#EEEEEE; font-size:12px; color:#999999; height:16px; padding:7px 10px; line-height:normal; clear:both; text-align:left; font-weight:bold; }
#tq a {color:#336699; text-decoration:underline; }
#search_weather { text-align:center; color:#999999; clear:both; }
.weatherurl {
  white-space:nowrap;
  display:inline-block; *display:inline; *zoom:1;
  font-size:12px;
  font-weight:bold; 
  font-family:tahoma,arial,"Microsoft YaHei";
  font-style:italic;
  color:#D2F98F !important;
  text-decoration:none;
  background-color: #00D2FF;
  /*position:fixed; right:0; bottom:0; z-index:999;*/
  line-height:normal; padding:0 3px;
  text-shadow: #363636 1px 0 0, #363636 0 1px 0, #363636 -1px 0 0, #363636 0 -1px 0;
}
-->
</style>
<script type="text/javascript" language="javascript">
<!--
var nowVersion='<?php @ include 'writable/require/browse_reload.txt'; ?>';
-->
</script>
<script type="text/javascript" language="javascript" src="writable/js/main.js?<?php echo filemtime('writable/js/main.js'); ?>"></script>
<script type="text/javascript" language="javaScript">
var par = parent.document.getElementById("wdFr");
</script>
</head>
<body>
<div id="tq">
  <div style="float:left; margin-right:3px;"><a id="weather_channel" href="<?php echo $weatherurl; ?>" target="_blank" class="weatherurl">天气网tianqi.com</a></div>
  <div style="float:left; margin-right:3px; position:relative;  white-space:nowrap;">
    <form id="wform" action="weather.php" method="post" target="_self" style="display:inline;">
    <input id="weather_fr" name="weather_fr" type="hidden">
            <div style="cursor:pointer">[<a href="javascript:void(0)" id="optionName" onclick="document.getElementById('optionMenu').style.display=''; return false;">切换天气频道</a><span class="mainmore" onmouseover="document.getElementById('optionMenu').style.display='';">&raquo;</span>]</div>
            <ul id="optionMenu" onmouseover="this.style.display='';" onmouseout="this.style.display='none';" style="position:absolute; top:20px; left:0; z-index:99; padding:5px 10px; line-height:30px; background-color:#FFFFFF; border:1px #D8D8D8 solid; display:none;">
<?php
if ($w_f = @glob('readonly/weather/*', GLOB_ONLYDIR)) {
  foreach($w_f as $w_type) {
    $w_type = basename($w_type);
    $w_set = $system_weather_from==$w_type ? '（系统默认）':'';
    $wfr_title = @file_get_contents('readonly/weather/'.$w_type.'/title.txt');
    $wfr_title = $wfr_title ? $wfr_title : $w_type;
    if ($web['weather_from'] == $w_type) {
      echo '
<li><span>当前天气源：'.$wfr_title.''.$w_set.'</span></li>';
    } else {
      echo '
<li><a href="javascript:void(0)" onclick="document.getElementById(\'weather_fr\').value=\''.$w_type.'\'; document.getElementById(\'wform\').submit(); return false;">切换到：'.$wfr_title.''.$w_set.'</a></li>';
    }
    unset($w_type, $wfr_title);
  }
}
unset($w_f, $w_type);
?>
            </ul>
    </form>
  </div>
  <div style="float:left;">[<a href="?area=china">更换城市&raquo;</a>]</div>
  <div style="clear:both; height:1px; margin-top:-1px; overflow:hidden;">&nbsp;</div>
</div>

<?php


$text = '';
if (empty($_GET['area'])) {
  $_GET['type'] = 2;
  echo '
<!-- body start -->
<div class="body" id="body">
<style>
html { background:none; background-color:#3399FF; }
body { width:auto!important; text-align:center; background:none; }
.body { width:1100px !important; margin-left:auto !important; margin-right:auto !important; background:none; position:static; z-index:0; }
</style>

';
  @ require 'readonly/weather/getweather.php';
  if ($city2) {
    if (is_numeric($city2)){
      $weatherurl .= 'worldcity/'.$city2.'.html';
    } else {
      $weatherurl .= $city2;
    }
  }
  echo  '
<script type="text/javascript" language="javaScript">
  document.getElementById("weather_channel").href = \''.$weatherurl.'\';
</script>
</div>
<!-- body end -->
';

  if ($city != $NOWCITY || $NOWCITY_ == 1) {
    echo '
<script type="text/javascript" language="javaScript">
  if (parent.document.getElementById("sendWeather") != null) {
    var reloadIfr = \'parent.document.getElementById("sendWeather")\';
  } else {
    document.write(\'<iframe id="reloadcity" src="PseudoXMLHTTP.php?xml_id=weather&xml_file='.get_en_url('readonly/weather/getweather.php').'&char=utf-8" style="display:none;"></iframe>\');
    var reloadIfr = \'document.getElementById("reloadcity")\';
  }
  function relaodCity() {
    var rIfr = eval(reloadIfr);
    if (rIfr != null) {
      rIfr.contentWindow.location.reload(true);
    }
  }
  if (document.all) {
    window.attachEvent("onload", relaodCity);
  } else {
    window.addEventListener("load", relaodCity, false);
  }
</script>
';
  }
  $rel1 = '
      var wText = document.getElementById("body");
      if (wText) {
        wText.innerHTML = wText.innerHTML.replace(/(<dd class="name"><h2>[^\<\>]*)<\/h2>/i, \'$1 <u style="font-size:12px;color:#EEEEEE;">[<a href="weather.php" target="_blank">更多详情&raquo;</a>]</u></dd>\');
      }
';


} else { require 'readonly/weather/'.$web['weather_from'].'/getweather_seek.php';
  if (empty($_GET['area']) || $_GET['area'] != 'international') {
    $text .= '<div id="search_weather">国内城市 | <a href="?area=international">国外城市</a></div>';
    //$text .= '<div id="search_weather">国内城市</div>';
    if (empty($_GET['province']) || !isset($seek['china'][$_GET['province']])) {
      $text_capital = $text_province = '';
      foreach ($seek['china'] as $k => $v) {
        $temp_capital = array_keys($v);
        list($temp_capital_, $py_capital, $pys_capital) = explode('|', $temp_capital[0]);
        $text_capital .= '<li><a href="?city='.urlencode($temp_capital_).'">'.$temp_capital_.'</a></li>';
        unset($temp_capital);
        $text_province .= '<li><a href="?area=china&province='.urlencode($k).'">'.$k.'</a></li>';
      }
      $text .= '<div class="column"><div class="column_title">省会城市</div><div class="class"><ul>'.$text_capital.'</ul></div></div><div class="column" style="margin-top:-1px;"><div class="column_title">各省查找</div><div class="class"><ul>'.$text_province.'</ul></div></div>';
    } else {
      if (empty($_GET['metropolis']) || !isset($seek['china'][$_GET['province']][$_GET['metropolis']])) {
        $text_metropolis = '';
        foreach ($seek['china'][$_GET['province']] as $k => $v) {
          list($temp_metropolis_, $py_metropolis, $pys_metropolis) = explode('|', $k);
          $text_metropolis .= '<ul><li><a href="?city='.urlencode($temp_metropolis_).'">'.$temp_metropolis_.'</a></li>';
          foreach ($v as $city) {
            list($temp_city_, $py_city, $pys_city) = explode('|', $city);
            $text_metropolis .= '<li><a href="?city='.urlencode($temp_city_).'" class="grayword">'.$temp_city_.'</a></li>';
          }
          $text_metropolis .= '</ul>';
        }
        $text .= '<div class="column"><div class="column_title"><a href="?area=china">国内</a> &gt; '.$_GET['province'].'</div><div class="class">'.$text_metropolis.'</div></div>';

      } else {
        $text_city = '<li><a href="?city='.urlencode($_GET['metropolis']).'">'.$_GET['metropolis'].'</a></li>';
        foreach ($seek['china'][$_GET['province']][$_GET['metropolis']] as $k => $v) {
          list($temp_city_, $py_city, $pys_city) = explode('|', $v);
          $text_city .= '<li><a href="?city='.urlencode($temp_city_).'">'.$temp_city_.'</a></li>';
        }
        $text .= '<div class="column"><div class="column_title"><a href="?area=china">国内</a> &gt; <a href="?area=china&province='.urlencode($_GET['province']).'">'.$_GET['province'].'</a> &gt; '.$_GET['metropolis'].'</div><div class="class"><ul>'.$text_city.'</ul></div></div>';
      }
    }


  } else {
    $text .= '<div id="search_weather"><a href="?area=china">国内城市</a> | 国外城市</div>';
    if (empty($_GET['continent']) || !isset($seek['international'][$_GET['continent']])) {
      $text_continent = '';
      foreach ($seek['international'] as $k => $v) {
        $text_continent .= '<li><a href="?area=international&continent='.urlencode($k).'">'.$k.'</a></li>';
      }
      $text .= '<div class="column"><div class="column_title">洲际</div><div class="class"><ul>'.$text_continent.'</ul></div></div>';
    } else {
      if (empty($_GET['country']) || !isset($seek['international'][$_GET['continent']][$_GET['country']])) {
        $text_country = '';
        foreach ($seek['international'][$_GET['continent']] as $k => $v) {
          $text_country .= '<li><a href="?area=international&continent='.urlencode($_GET['continent']).'&country='.urlencode($k).'">'.$k.'</a></li>';
        }
        $text .= '<div class="column"><div class="column_title"><a href="?area=international">洲际</a> &gt; '.$_GET['continent'].'国家</div><div class="class"><ul>'.$text_country.'</ul></div></div>';

      } else {

        $text_city = '';
        foreach ($seek['international'][$_GET['continent']][$_GET['country']] as $k => $v) {
          list($temp_city_, $py_city, $pys_city) = explode('|', $v);
          $text_city .= '<li><a href="?city='.urlencode($temp_city_).'">'.$temp_city_.'</a></li>';
        }
        $text .= '<div class="column"><div class="column_title"><a href="?area=international">洲际</a> &gt; <a href="?area=international&continent='.urlencode($_GET['continent']).'">'.$_GET['continent'].'国家</a> &gt; '.$_GET['country'].'</div><div class="class"><ul>'.$text_city.'</ul></div></div>';

      }
    }

  }
  echo $text;
}



?>



</body>
</html>