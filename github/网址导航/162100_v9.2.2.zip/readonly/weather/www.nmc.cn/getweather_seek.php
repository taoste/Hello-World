<?php


$seek['china'] = 


array (

  '北京'=>array(
      '北京|beijing|ABJ'=>array('昌平|changping|ABJ','大兴|daxing|ABJ','房山|fangshan|ABJ','怀柔|huairou|ABJ','门头沟|mentougou|ABJ','密云|miyun|ABJ','平谷|pinggu|ABJ','顺义|shunyi|ABJ','通州|tongzhou1|ABJ','延庆|yanqing|ABJ',),
  ),

  '上海'=>array(
      '上海|shanghai|ASH'=>array('宝山|baoshan|ASH','崇明|chongming|ASH','奉贤|fengxian1|ASH','嘉定|jiading|ASH','金山|jinshan|ASH','南汇|nanhui|ASH','浦东|pudong|ASH','青浦|qingpu|ASH','松江|songjiang|ASH','闵行|minxing|ASH',),
  ),

  '天津'=>array(
      '天津|tianjin|ATJ'=>array('西青|xiqing|ATJ','宝坻|baodi|ATJ','北辰|beichen|ATJ','东丽|dongli|ATJ','蓟县|jixian2|ATJ','津南|jinnan|ATJ','静海|jinghai|ATJ','宁河|ninghe|ATJ','武清|wuqing|ATJ','滨海新区|binhaixinqu|ATJ','大港|dagang|ATJ','汉沽|hangu|ATJ',),
  ),

  '重庆'=>array(
      '重庆|chongqing|ACQ'=>array('奉节|fengjie|ACQ','涪陵|fuling|ACQ','黔江|qianjiang2|ACQ','北碚|beibei|ACQ','长寿|changshou|ACQ','城口|chengkou|ACQ','大足|dazu|ACQ','垫江|dianjiang|ACQ','丰都|fengdou|ACQ','合川|hechuan|ACQ','江津|jiangjin|ACQ','开县|kaixian|ACQ','梁平|liangping|ACQ','南川|nanchuan|ACQ','彭水|pengshui|ACQ','荣昌|rongchang|ACQ','石柱|shizhu|ACQ','铜梁|tongliang|ACQ','万州|wanzhou|ACQ','巫山|wushan1|ACQ','巫溪|wuxi1|ACQ','武隆|wulong|ACQ','秀山|xiushan|ACQ','永川|yongchuan|ACQ','酉阳|youyang|ACQ','忠县|zhongxian|ACQ','潼南|tongnan|ACQ','璧山|bishan|ACQ','綦江|qijiang|ACQ','巴南|banan|ACQ','万盛|wansheng|ACQ','渝北|yubei|ACQ','云阳|yunyang|ACQ',),
  ),

  '安徽'=>array(
      '合肥|hefei|AAH'=>array('长丰|changfeng|AAH','肥东|feidong|AAH','肥西|feixi|AAH',),
      '安庆|anqing|AAH'=>array('怀宁|huaining|AAH','潜山|qianshan2|AAH','宿松|susong|AAH','太湖|taihu|AAH','桐城|tongcheng1|AAH','望江|wangjiang|AAH','岳西|yuexi2|AAH','枞阳|zongyang|AAH',),
      '蚌埠|bengbu|AAH'=>array('固镇|guzhen|AAH','怀远|huaiyuan|AAH','五河|wuhe|AAH',),
      '巢湖|chaohu|AAH'=>array('含山|hanshan|AAH','和县|hexian|AAH','庐江|lujiang|AAH','无为|wuwei2|AAH',),
      '池州|chizhou|AAH'=>array('东至|dongzhi|AAH','青阳|qingyang|AAH','石台|shitai|AAH','九华|jiuhua|AAH',),
      '滁州|chuzhou_|AAH'=>array('定远|dingyuan|AAH','凤阳|fengyang|AAH','来安|laian|AAH','明光|mingguang|AAH','全椒|quanjiao|AAH','天长|tianchang|AAH',),
      '阜阳|fuyang1|AAH'=>array('阜南|funan|AAH','界首|jieshou|AAH','临泉|linquan|AAH','太和|taihe1|AAH','颍上|yingshang|AAH',),
      '淮北|huaibei|AAH'=>array('濉溪|suixi1|AAH',),
      '淮南|huainan|AAH'=>array('凤台|fengtai_|AAH',),
      '黄山市|huangshanshi|AAH'=>array('黄山风景区|huangshanfengjingqu|AAH','祁门|qimen|AAH','休宁|xiuning|AAH','歙县|shexian2|AAH','黟县|yixian2|AAH','黄山区|huangshanqu|AAH',),
      '六安|luan|AAH'=>array('霍邱|huoqiu|AAH','霍山|huoshan|AAH','金寨|jinzhai|AAH','寿县|shouxian|AAH','舒城|shucheng|AAH',),
      '马鞍山|maanshan|AAH'=>array('当涂|dangtu|AAH',),
      '宿州|suzhou1|AAH'=>array('灵璧|lingbi|AAH','萧县|xiaoxian|AAH','泗县|sixian|AAH','砀山|dangshan|AAH',),
      '铜陵|tongling|AAH'=>array(),
      '芜湖|wuhuxian|AAH'=>array('芜湖县|wuhuxian|AAH','繁昌|fanchang|AAH','南陵|nanling|AAH',),
      '宣城|xuancheng|AAH'=>array('广德|guangde|AAH','绩溪|jixi1|AAH','郎溪|langxi|AAH','宁国|ningguo|AAH','泾县|jingxian2|AAH','旌德|jingde|AAH',),
      '亳州|bozhou|AAH'=>array('利辛|lixin|AAH','蒙城|mengcheng|AAH','涡阳|woyang|AAH',),
  ),

  '福建'=>array(
      '福州|fuzhou3|AFJ'=>array('长乐|changle_|AFJ','福清|fuqing|AFJ','连江|lianjiang1|AFJ','罗源|luoyuan|AFJ','闽侯|minhou|AFJ','闽清|minqing|AFJ','平潭|pingtan|AFJ','永泰|yongtai|AFJ',),
      '龙岩|longyan|AFJ'=>array('长汀|changting|AFJ','连城|liancheng|AFJ','上杭|shanghang|AFJ','武平|wuping|AFJ','永定|yongding|AFJ','漳平|zhangping|AFJ',),
      '南平|nanping2|AFJ'=>array('浦城|pucheng2|AFJ','光泽|guangze|AFJ','建阳|jianyang2|AFJ','建瓯|jianou|AFJ','邵武|shaowu|AFJ','顺昌|shunchang|AFJ','松溪|songxi|AFJ','武夷山|wuyishan|AFJ','政和|zhenghe|AFJ',),
      '宁德|ningde|AFJ'=>array('福安|fuan|AFJ','福鼎|fuding|AFJ','古田|gutian|AFJ','屏南|pingnan1|AFJ','寿宁|shouning|AFJ','霞浦|xiapu|AFJ','周宁|zhouning|AFJ','柘荣|zherong|AFJ',),
      '莆田|putian|AFJ'=>array('仙游|xianyou|AFJ','秀屿港|xiuyugang|AFJ',),
      '三明|sanming|AFJ'=>array('大田|datian|AFJ','建宁|jianning|AFJ','将乐|jiangle|AFJ','明溪|mingxi|AFJ','宁化|ninghua|AFJ','清流|qingliu|AFJ','沙县|shaxian|AFJ','泰宁|taining|AFJ','永安|yongan|AFJ','尤溪|youxi|AFJ',),
      '厦门|xiamen|AFJ'=>array('同安|tongan|AFJ',),
      '漳州|zhangzhou|AFJ'=>array('长泰|changtai|AFJ','东山|dongshan|AFJ','华安|huaan|AFJ','龙海|longhai|AFJ','南靖|nanjing2|AFJ','平和|pinghe|AFJ','云霄|yunxiao|AFJ','漳浦|zhangpu|AFJ','诏安|zhaoan|AFJ',),
      '泉州|quanzhou1|AFJ'=>array('晋江|jinjiang|AFJ','安溪|anxi|AFJ','崇武|chongwu|AFJ','德化|dehua|AFJ','南安|nanan|AFJ','永春|yongchun|AFJ',),
      '钓鱼岛|diaoyudao|AFJ'=>array(),
  ),

  '甘肃'=>array(
      '兰州|lanzhou|AGS'=>array('皋兰|gaolan|AGS','永登|yongdeng|AGS','榆中|yuzhong|AGS',),
      '白银|baiyin|AGS'=>array('会宁|huining2|AGS','景泰|jingtai|AGS','靖远|jingyuan1|AGS',),
      '嘉峪关|jiayuguan|AGS'=>array(),
      '酒泉|jiuquan|AGS'=>array('敦煌|dunhuang|AGS','瓜州|guazhou|AGS','金塔|jinta|AGS','肃北|subei|AGS','玉门|yumen|AGS',),
      '临夏|linxia|AGS'=>array('广河|guanghe|AGS','和政|hezheng|AGS','康乐|kangle|AGS','永靖|yongjing|AGS',),
      '天水|tianshui|AGS'=>array('甘谷|gangu|AGS','麦积|maiji|AGS','秦安|qinan|AGS','清水|qingshui|AGS','武山|wushan2|AGS','张家川|zhangjiachuan|AGS',),
      '武威|wuwei1|AGS'=>array('古浪|gulang|AGS','民勤|minqin|AGS','天祝|tianzhu1|AGS',),
      '张掖|zhangye|AGS'=>array('高台|gaotai|AGS','临泽|linze|AGS','民乐|minle|AGS','山丹|shandan|AGS','肃南|sunan|AGS',),
      '金昌|jinchang|AGS'=>array('永昌|yongchang|AGS',),
  ),

  '广东'=>array(
      '广州|guangzhou|AGD'=>array('从化|conghua|AGD','番禺|fanyu|AGD','花都|huadou|AGD','增城|zengcheng|AGD',),
      '深圳|shenzhen|AGD'=>array(),
      '潮州|chaozhou|AGD'=>array('饶平|raoping|AGD',),
      '东莞|dongguan|AGD'=>array(),
      '佛山|foshan|AGD'=>array('顺德|shunde|AGD','三水|sanshui|AGD',),
      '河源|heyuan|AGD'=>array('和平|heping|AGD','连平|lianping|AGD','龙川|longchuan2|AGD','紫金|zijin|AGD',),
      '惠州|huizhou|AGD'=>array('博罗|boluo|AGD','惠东|huidong1|AGD','龙门|longmen|AGD',),
      '揭阳|jieyang|AGD'=>array('惠来|huilai|AGD','揭西|jiexi|AGD','普宁|puning|AGD',),
      '茂名|maoming|AGD'=>array('电白|dianbai|AGD','高州|gaozhou|AGD','化州|huazhou|AGD','信宜|xinyi2|AGD',),
      '清远|qingyuan1|AGD'=>array('佛冈|fogang|AGD','连南|liannan|AGD','连山|lianshan|AGD','连州|lianzhou|AGD','阳山|yangshan|AGD','英德|yingde|AGD',),
      '汕头|shantou|AGD'=>array('潮阳|chaoyang2|AGD','澄海|chenghai|AGD','南澳|nanao|AGD',),
      '汕尾|shanwei|AGD'=>array('海丰|haifeng|AGD','陆丰|lufeng2|AGD',),
      '韶关|shaoguan|AGD'=>array('南雄|nanxiong|AGD','乐昌|lechang|AGD','曲江|qujiang|AGD','仁化|renhua|AGD','乳源|ruyuan|AGD','始兴|shixing|AGD','翁源|wengyuan|AGD','新丰|xinfeng2|AGD',),
      '阳江|yangjiang|AGD'=>array('阳春|yangchun|AGD',),
      '云浮|yunfu|AGD'=>array('罗定|luoding|AGD','新兴|xinxing|AGD','郁南|yunan|AGD',),
      '湛江|zhanjiang|AGD'=>array('雷州|leizhou|AGD','廉江|lianjiang2|AGD','遂溪|suixi2|AGD','吴川|wuchuan6|AGD','徐闻|xuwen|AGD',),
      '中山|zhongshan1|AGD'=>array(),
      '珠海|zhuhai|AGD'=>array('斗门|doumen|AGD',),
  ),

  '广西'=>array(
      '百色|baise|AGX'=>array('田阳|tianyang|AGX','德保|debao|AGX','靖西|jingxi|AGX','乐业|leye|AGX','凌云|lingyun|AGX','隆林|longlin|AGX','那坡|napo|AGX','平果|pingguo|AGX','田东|tiandong|AGX','田林|tianlin|AGX','西林|xilin|AGX',),
      '北海|beihai|AGX'=>array('合浦|hepu|AGX','涠洲|weizhou|AGX',),
      '崇左|chongzuo|AGX'=>array('大新|daxin|AGX','扶绥|fusui|AGX','龙州|longzhou|AGX','宁明|ningming|AGX','凭祥|pingxiang3|AGX','天等|tiandeng|AGX',),
      '防城港|fangchenggang|AGX'=>array('东兴|dongxing|AGX','防城|fangcheng_|AGX','上思|shangsi|AGX',),
      '桂林|guilin|AGX'=>array('恭城|gongcheng|AGX','灌阳|guanyang|AGX','荔浦|lipu|AGX','临桂|lingui|AGX','灵川|lingchuan2|AGX','龙胜|longsheng|AGX','平乐|pingle|AGX','全州|quanzhou2|AGX','兴安|xingan2|AGX','阳朔|yangshuo|AGX','永福|yongfu|AGX','资源|ziyuan|AGX',),
      '贵港|guigang|AGX'=>array('桂平|guiping|AGX','平南|pingnan2|AGX',),
      '河池|hechi|AGX'=>array('巴马|bama|AGX','东兰|donglan|AGX','都安|douan|AGX','凤山|fengshan|AGX','环江|huanjiang|AGX','罗城|luocheng|AGX','南丹|nandan|AGX','天峨|tiane|AGX','宜州|yizhou|AGX',),
      '贺州|hezhou|AGX'=>array('富川|fuchuan|AGX','昭平|zhaoping|AGX','钟山|zhongshan2|AGX',),
      '来宾|laibin|AGX'=>array('金秀|jinxiu|AGX','武宣|wuxuan|AGX','象州|xiangzhou|AGX','忻城|xincheng|AGX',),
      '柳州|liuzhou|AGX'=>array('柳城|liucheng|AGX','柳江|liujiang|AGX','鹿寨|luzhai|AGX','融安|rongan|AGX','融水|rongshui|AGX','三江|sanjiang|AGX',),
      '钦州|qinzhou|AGX'=>array('灵山|lingshan|AGX','浦北|pubei|AGX',),
      '梧州|wuzhou|AGX'=>array('苍梧|cangwu|AGX','蒙山|mengshan|AGX','藤县|tengxian|AGX','岑溪|cenxi|AGX',),
      '玉林|yulin4|AGX'=>array('北流|beiliu|AGX','博白|bobai|AGX','陆川|luchuan|AGX','容县|rongxian1|AGX',),
      '南宁|nanningchengqu|AGX'=>array('宾阳|binyang|AGX','横县|hengxian|AGX','隆安|longan|AGX','马山|mashan|AGX','上林|shanglin|AGX','武鸣|wuming|AGX','邕宁|yongning2|AGX',),
  ),

  '贵州'=>array(
      '贵阳|guiyang|AGZ'=>array('白云|baiyun|AGZ','花溪|huaxi|AGZ','开阳|kaiyang|AGZ','清镇|qingzhen|AGZ','乌当|wudang|AGZ','息烽|xifeng2|AGZ','修文|xiuwen|AGZ',),
      '安顺|anshun|AGZ'=>array('关岭|guanling|AGZ','平坝|pingba|AGZ','普定|puding|AGZ','镇宁|zhenning|AGZ','紫云|ziyun|AGZ',),
      '毕节|bijie|AGZ'=>array('黔西|qianxi2|AGZ','大方|dafang|AGZ','赫章|hezhang|AGZ','金沙|jinsha|AGZ','纳雍|nayong|AGZ','威宁|weining|AGZ','织金|zhijin|AGZ',),
      '铜仁|tongren1|AGZ'=>array('德江|dejiang|AGZ','江口|jiangkou|AGZ','石阡|shiqian|AGZ','思南|sinan|AGZ','松桃|songtao|AGZ','万山|wanshan|AGZ','沿河|yanhe|AGZ','印江|yinjiang|AGZ','玉屏|yuping|AGZ',),
      '遵义|zunyixian|AGZ'=>array('赤水|chishui|AGZ','道真|daozhen|AGZ','凤冈|fenggang|AGZ','汇川|huichuan|AGZ','仁怀|renhuai|AGZ','绥阳|suiyang|AGZ','桐梓|tongzi|AGZ','务川|wuchuan5|AGZ','习水|xishui1|AGZ','余庆|yuqing|AGZ','正安|zhengan|AGZ','湄潭|meitan|AGZ',),
      '遵义县|zunyixian|AGZ'=>array(),
  ),

  '海南'=>array(
      '海口|haikou|AHI'=>array(),
      '白沙|baisha|AHI'=>array(),
      '保亭|baoting|AHI'=>array(),
      '澄迈|chengmai|AHI'=>array(),
      '定安|dingan|AHI'=>array(),
      '东方|dongfang|AHI'=>array(),
      '乐东|ledong|AHI'=>array(),
      '临高|lingao|AHI'=>array(),
      '陵水|lingshui|AHI'=>array(),
      '琼海|qionghai|AHI'=>array(),
      '琼中|qiongzhong|AHI'=>array(),
      '三亚|sanya|AHI'=>array(),
      '屯昌|tunchang|AHI'=>array(),
      '万宁|wanning|AHI'=>array(),
      '文昌|wenchang|AHI'=>array(),
      '儋州|danzhou|AHI'=>array(),
      '昌江|changjiang|AHI'=>array(),
      '五指山|wuzhishan|AHI'=>array(),
  ),

  '河北'=>array(
      '石家庄|shijiazhuang|AHE'=>array('高邑|gaoyi|AHE','晋州|jinzhou5|AHE','井陉|jingxing|AHE','灵寿|lingshou|AHE','平山|pingshan1|AHE','深泽|shenze|AHE','无极|wuji|AHE','辛集|xinji|AHE','新乐|xinle|AHE','行唐|xingtang|AHE','元氏|yuanshi|AHE','赞皇|zanhuang|AHE','赵县|zhaoxian|AHE','正定|zhengding|AHE','藁城|gaocheng|AHE','栾城|luancheng|AHE',),
      '保定|baoding|AHE'=>array('安国|anguo|AHE','安新|anxin|AHE','定州|dingzhou|AHE','阜平|fuping4|AHE','高碑店|gaobeidian|AHE','高阳|gaoyang|AHE','满城|mancheng|AHE','曲阳|quyang|AHE','顺平|shunping|AHE','唐县|tangxian|AHE','望都|wangdu|AHE','雄县|xiongxian|AHE','徐水|xushui|AHE','易县|yixian3|AHE','涞源|laiyuan|AHE','涿州|zhuozhou|AHE','蠡县|lixian3|AHE',),
      '沧州|cangzhou|AHE'=>array('任丘|renqiu|AHE','泊头|botou|AHE','东光|dongguang|AHE','海兴|haixing|AHE','河间|hejian|AHE','黄骅|huanghua|AHE','孟村|mengcun|AHE','南皮|nanpi|AHE','青县|qingxian|AHE','肃宁|suning|AHE','吴桥|wuqiao|AHE','献县|xianxian|AHE','盐山|yanshan1|AHE',),
      '承德|chengdexian|AHE'=>array('丰宁|fengning|AHE','宽城|kuancheng|AHE','隆化|longhua|AHE','滦平|luanping|AHE','平泉|pingquan|AHE','围场|weichang|AHE','兴隆|xinglong|AHE',),
      '邯郸|handan|AHE'=>array('成安|chengan|AHE','磁县|cixian|AHE','大名|daming|AHE','肥乡|feixiang|AHE','峰峰|fengfeng|AHE','馆陶|guantao|AHE','广平|guangping|AHE','鸡泽|jize|AHE','临漳|linzhang|AHE','邱县|qiuxian|AHE','曲周|quzhou2|AHE','涉县|shexian1|AHE','魏县|weixian1|AHE','武安|wuan|AHE','永年|yongnian|AHE',),
      '衡水|hengshui|AHE'=>array('安平|anping|AHE','阜城|fucheng|AHE','故城|gucheng|AHE','冀州|jizhou|AHE','景县|jingxian1|AHE','饶阳|raoyang|AHE','深州|shenzhou|AHE','武强|wuqiang|AHE','武邑|wuyi4|AHE','枣强|zaoqiang|AHE',),
      '廊坊|langfang|AHE'=>array('霸州|bazhou|AHE','大厂|dachang|AHE','大城|daicheng|AHE','固安|guan|AHE','三河|sanhe|AHE','文安|wenan|AHE','香河|xianghe|AHE','永清|yongqing|AHE',),
      '秦皇岛|qinhuangdao|AHE'=>array('昌黎|changli|AHE','抚宁|funing3|AHE','卢龙|lulong|AHE','青龙|qinglong2|AHE',),
      '唐山|tangshan|AHE'=>array('曹妃甸|caofeidian|AHE','丰南|fengnan|AHE','丰润|fengrun|AHE','乐亭|leting|AHE','滦南|luannan|AHE','滦县|luanxian|AHE','迁安|qianan2|AHE','迁西|qianxi1|AHE','唐海|tanghai|AHE','玉田|yutian4|AHE','遵化|zunhua|AHE',),
      '邢台|xingtai|AHE'=>array('柏乡|baixiang|AHE','广宗|guangzong|AHE','巨鹿|julu|AHE','临城|lincheng|AHE','临西|linxi1|AHE','隆尧|longyao|AHE','南宫|nangong|AHE','南和|nanhe|AHE','内邱|neiqiu|AHE','宁晋|ningjin1|AHE','平乡|pingxiang2|AHE','清河|qinghe2|AHE','任县|renxian|AHE','沙河|shahe|AHE','威县|weixian2|AHE','新河|xinhe1|AHE',),
      '张家口|zhangjiakou|AHE'=>array('赤城|chicheng|AHE','崇礼|chongli|AHE','沽源|guyuan|AHE','怀安|huaian2|AHE','怀来|huailai|AHE','康保|kangbao|AHE','尚义|shangyi|AHE','万全|wanquan|AHE','蔚县|yuxian5|AHE','宣化|xuanhua|AHE','阳原|yangyuan|AHE','张北|zhangbei|AHE','涿鹿|zhuolu|AHE',),
      '承德县|chengdexian|AHE'=>array(),
  ),

  '河南'=>array(
      '郑州|zhengzhou|AHA'=>array('登封市|dengfengshi|AHA','巩义市|gongyishi|AHA','新密市|xinmishi|AHA','新郑市|xinzhengshi|AHA','中牟县|zhongmuxian|AHA','荥阳市|xingyangshi|AHA',),
      '安阳市|anyangshi|AHA'=>array('滑县|huaxian1|AHA','林州市|linzhoushi|AHA','内黄县|neihuangxian|AHA','汤阴县|tangyinxian|AHA',),
      '鹤壁|hebi|AHA'=>array('浚县|junxian|AHA','淇县|qixian1|AHA',),
      '济源|jiyuan|AHA'=>array(),
      '焦作市|jiaozuoshi|AHA'=>array('博爱县|boaixian|AHA','孟州市|mengzhoushi|AHA','沁阳市|qinyangshi|AHA','温县|wenxian3|AHA','武陟县|wuzhixian|AHA','修武县|xiuwuxian|AHA',),
      '开封市|kaifengshi|AHA'=>array('兰考|lankao|AHA','通许|tongxu|AHA','尉氏|weishi|AHA','杞县|qixian3|AHA',),
      '洛阳市|luoyangshi|AHA'=>array('洛宁县|luoningxian|AHA','孟津县|mengjinxian|AHA','汝阳县|ruyangxian|AHA','新安县|xinanxian|AHA','伊川县|yichuanxian|AHA','宜阳县|yiyangxian|AHA','偃师市|yanshishi|AHA','嵩县|songxian|AHA','栾川县|luanchuanxian|AHA',),
      '南阳市|nanyangshi|AHA'=>array('邓州|dengzhou|AHA','方城|fangcheng|AHA','南召|nanzhao|AHA','内乡|neixiang|AHA','社旗|sheqi|AHA','唐河|tanghe|AHA','桐柏|tongbai|AHA','西峡|xixia|AHA','新野|xinye|AHA','镇平|zhenping2|AHA','淅川|xichuan|AHA',),
      '平顶山|pingdingshan|AHA'=>array('宝丰|baofeng|AHA','鲁山|lushan2|AHA','汝州|ruzhou|AHA','舞钢|wugang1|AHA','叶县|yexian|AHA','郏县|jiaxian1|AHA',),
      '三门峡|sanmenxia|AHA'=>array('灵宝|lingbao|AHA','卢氏|lushi|AHA','渑池|mianchi|AHA',),
      '商丘|shangqiu|AHA'=>array('民权|minquan|AHA','宁陵|ningling|AHA','夏邑|xiayi|AHA','永城|yongcheng|AHA','虞城|yucheng1|AHA','柘城|zhecheng|AHA','睢县|huixian2|AHA',),
      '新乡市|xinxiangshi|AHA'=>array('长垣县|changyuanxian|AHA','封丘县|fengqiuxian|AHA','辉县市|huixianshi|AHA','获嘉县|huojiaxian|AHA','卫辉市|weihuishi|AHA','延津县|yanjinxian|AHA','原阳县|yuanyangxian|AHA',),
      '信阳市|xinyangshi|AHA'=>array('潢川|huangchuan|AHA','固始|gushi|AHA','光山|guangshan|AHA','淮滨|huaibin|AHA','罗山|luoshan|AHA','商城|shangcheng|AHA','息县|xixian3|AHA','新县|xinxian|AHA',),
      '许昌|xuchang|AHA'=>array('长葛|changge|AHA','襄城|xiangcheng2|AHA','禹州|yuzhou|AHA','鄢陵|yanling1|AHA',),
      '周口|zhoukou|AHA'=>array('郸城县|danchengxian|AHA','扶沟县|fugouxian|AHA','淮阳县|huaiyangxian|AHA','鹿邑县|luyixian|AHA','商水县|shangshuixian|AHA','沈丘县|shenqiuxian|AHA','太康县|taikangxian|AHA','西华县|xihuaxian|AHA','项城市|xiangchengshi|AHA',),
      '驻马店市|zhumadianshi|AHA'=>array('泌阳县|biyangxian|AHA','平舆县|pingyuxian|AHA','确山县|queshanxian|AHA','汝南县|runanxian|AHA','上蔡县|shangcaixian|AHA','遂平县|suipingxian|AHA','西平县|xipingxian|AHA','新蔡县|xincaixian|AHA','正阳县|zhengyangxian|AHA',),
      '漯河市|luoheshi|AHA'=>array('临颍县|linyingxian|AHA','舞阳县|wuyangxian|AHA',),
  ),

  '黑龙江'=>array(
      '哈尔滨|haerbin|AHL'=>array('阿城|acheng|AHL','巴彦|bayan|AHL','宾县|binxian_|AHL','方正|fangzheng|AHL','呼兰|hulan|AHL','木兰|mulan|AHL','尚志|shangzhi|AHL','双城|shuangcheng|AHL','通河|tonghe|AHL','五常|wuchang|AHL','延寿|yanshou|AHL','依兰|yilan|AHL',),
      '大庆|daqing|AHL'=>array('杜蒙|dumeng|AHL','林甸|lindian|AHL','肇源|zhaoyuan1|AHL','肇州|zhaozhou|AHL',),
      '鹤岗|hegang|AHL'=>array('萝北|luobei|AHL','绥滨|suibin|AHL',),
      '黑河|heihe|AHL'=>array('北安|beian|AHL','嫩江|nenjiang|AHL','孙吴|sunwu|AHL','五大连池|wudalianchi|AHL','逊克|xunke|AHL',),
      '鸡西|jixi2|AHL'=>array('虎林|hulin|AHL','鸡东|jidong|AHL','密山|mishan|AHL',),
      '佳木斯|jiamusi|AHL'=>array('抚远|fuyuan3|AHL','富锦|fujin|AHL','汤原|tangyuan|AHL','同江|tongjiang1|AHL','桦川|huachuan|AHL','桦南|huanan|AHL',),
      '牡丹江|mudanjiang|AHL'=>array('绥芬河|suifenhe|AHL','东宁|dongning|AHL','海林|hailin|AHL','林口|linkou|AHL','穆棱|muleng|AHL','宁安|ningan|AHL',),
      '七台河|qitaihe|AHL'=>array('勃利|boli|AHL',),
      '齐齐哈尔|qiqihaer|AHL'=>array('甘南|gannan|AHL','拜泉|baiquan|AHL','富裕|fuyu_|AHL','克东|kedong|AHL','克山|keshan|AHL','龙江|longjiang|AHL','泰来|tailai|AHL','依安|yian|AHL','讷河|nehe|AHL',),
      '双鸭山|shuangyashan|AHL'=>array('宝清|baoqing|AHL','集贤|jixian3|AHL','饶河|raohe|AHL',),
      '绥化|suihua|AHL'=>array('安达|anda|AHL','海伦|hailun|AHL','兰西|lanxi1|AHL','明水|mingshui|AHL','青冈|qinggang|AHL','庆安|qingan|AHL','绥棱|suileng|AHL','望奎|wangkui|AHL','肇东|zhaodong|AHL',),
      '伊春|yichun1|AHL'=>array('嘉荫|jiayin|AHL','铁力|tieli|AHL','乌伊岭|wuyiling|AHL','五营|wuying|AHL',),
  ),

  '湖北'=>array(
      '武汉|wuhan|AHB'=>array('蔡甸|caidian|AHB','黄陂|huangbei|AHB','江夏|jiangxia|AHB','新洲|xinzhou2|AHB',),
      '鄂州|ezhou|AHB'=>array(),
      '恩施|enshi|AHB'=>array('巴东|badong|AHB','鹤峰|hefeng1|AHB','建始|jianshi|AHB','来凤|laifeng|AHB','利川|lichuan2|AHB','咸丰|xianfeng|AHB','宣恩|xuanen|AHB',),
      '黄冈|huanggang|AHB'=>array('麻城|macheng|AHB','红安|hongan|AHB','黄梅|huangmei|AHB','罗田|luotian|AHB','武穴|wuxue|AHB','英山|yingshan1|AHB','蕲春|qichun|AHB','浠水|xishui2|AHB',),
      '黄石|huangshi|AHB'=>array('大冶|daye|AHB','阳新|yangxin1|AHB',),
      '荆门|jingmen|AHB'=>array('京山|jingshan|AHB','钟祥|zhongxiang|AHB',),
      '荆州|jingzhou3|AHB'=>array('公安|gongan|AHB','洪湖|honghu|AHB','监利|jianli|AHB','石首|shishou|AHB','松滋|songzi|AHB',),
      '潜江|qianjiang1|AHB'=>array(),
      '神农架|shennongjia|AHB'=>array(),
      '十堰|shiyan|AHB'=>array('丹江口|danjiangkou|AHB','房县|fangxian|AHB','郧西|yunxi|AHB','郧县|yunxian2|AHB','竹山|zhushan|AHB','竹溪|zhuxi|AHB',),
      '随州|suizhou|AHB'=>array('广水|guangshui|AHB',),
      '天门|tianmen|AHB'=>array(),
      '仙桃|xiantao|AHB'=>array(),
      '咸宁|xianning|AHB'=>array('赤壁|chibi|AHB','崇阳|chongyang|AHB','嘉鱼|jiayu|AHB','通城|tongcheng2|AHB','通山|tongshan|AHB',),
      '襄阳|xiangyang|AHB'=>array('宜城|yicheng3|AHB','枣阳|zaoyang|AHB','保康|baokang|AHB','谷城|gucheng_|AHB','老河口|laohekou|AHB','南漳|nanzhang|AHB',),
      '孝感|xiaogan|AHB'=>array('安陆|anlu|AHB','大悟|dawu|AHB','汉川|hanchuan|AHB','应城|yingcheng|AHB','云梦|yunmeng|AHB',),
      '宜昌|yichang|AHB'=>array('长阳|changyang|AHB','当阳|dangyang|AHB','三峡|sanxia|AHB','五峰|wufeng|AHB','兴山|xingshan|AHB','夷陵|yiling|AHB','宜都|yidou|AHB','远安|yuanan|AHB','枝江|zhijiang1|AHB','秭归|zigui|AHB',),
  ),

  '湖南'=>array(
      '长沙|changsha|AHN'=>array('宁乡|ningxiang|AHN','浏阳|liuyang|AHN',),
      '常德|changde|AHN'=>array('安乡|anxiang|AHN','汉寿|hanshou|AHN','临澧|linli|AHN','石门|shimen|AHN','桃源|taoyuan|AHN','澧县|lixian1|AHN',),
      '郴州|chenzhou|AHN'=>array('临武|linwu|AHN','安仁|anren|AHN','桂东|guidong|AHN','桂阳|guiyang_|AHN','嘉禾|jiahe|AHN','汝城|rucheng|AHN','宜章|yizhang|AHN','永兴|yongxing|AHN','资兴|zixing|AHN',),
      '衡阳市|hengyangshi|AHN'=>array('南岳|nanyue|AHN','常宁|changning2|AHN','衡东|hengdong|AHN','衡南|hengnan|AHN','衡山|hengshan1|AHN','祁东|qidong1|AHN','耒阳|leiyang|AHN',),
      '怀化|huaihua|AHN'=>array('沅陵|yuanling|AHN','辰溪|chenxi|AHN','洪江|hongjiang|AHN','会同|huitong|AHN','靖州|jingzhou4|AHN','麻阳|mayang|AHN','通道|tongdao|AHN','新晃|xinhuang|AHN','芷江|zhijiang2|AHN','溆浦|xupu|AHN',),
      '娄底|loudi|AHN'=>array('冷水江|lengshuijiang|AHN','涟源|lianyuan|AHN','双峰|shuangfeng|AHN','新化|xinhua|AHN',),
      '邵阳市|shaoyangshi|AHN'=>array('城步|chengbu|AHN','洞口|dongkou|AHN','隆回|longhui|AHN','邵东|shaodong|AHN','绥宁|suining1|AHN','武冈|wugang2|AHN','新宁|xinning|AHN','新邵|xinshao|AHN',),
      '湘潭|xiangtan|AHN'=>array('韶山|shaoshan|AHN','湘乡|xiangxiang|AHN',),
      '益阳|yiyang1|AHN'=>array('安化|anhua|AHN','南县|nanxian|AHN','桃江|taojiang|AHN','沅江|yuanjiang4|AHN',),
      '永州|yongzhou|AHN'=>array('道县|daoxian|AHN','东安|dongan|AHN','江华|jianghua|AHN','江永|jiangyong|AHN','蓝山|lanshan|AHN','冷水滩|lengshuitan|AHN','宁远|ningyuan|AHN','祁阳|qiyang|AHN','双牌|shuangpai|AHN','新田|xintian|AHN',),
      '岳阳|yueyang|AHN'=>array('华容|huarong|AHN','临湘|linxiang|AHN','平江|pingjiang|AHN','湘阴|xiangyin|AHN','汨罗|miluo|AHN',),
      '张家界|zhangjiajie|AHN'=>array('桑植|sangzhi|AHN','慈利|cili|AHN',),
      '株洲|zhuzhou|AHN'=>array('茶陵|chaling|AHN','炎陵|yanling2|AHN','攸县|youxian|AHN','醴陵|liling|AHN',),
      '衡阳县|hengyangxian|AHN'=>array(),
      '邵阳县|shaoyangxian|AHN'=>array(),
  ),

  '吉林'=>array(
      '长春|changchun|AJL'=>array('德惠|dehui|AJL','九台|jiutai|AJL','农安|nongan|AJL','双阳|shuangyang|AJL','榆树|yushu2|AJL',),
      '白城|baicheng|AJL'=>array('大安|daan|AJL','通榆|tongyu|AJL','镇赉|zhenlai|AJL','洮南|taonan|AJL',),
      '白山|baishan|AJL'=>array('长白|changbai|AJL','东岗|donggang|AJL','靖宇|jingyu|AJL','临江|linjiang|AJL',),
      '吉林|jilin|AJL'=>array('桦甸|huadian|AJL','磐石|panshi|AJL','舒兰|shulan|AJL','永吉|yongji1|AJL','蛟河|jiaohe|AJL',),
      '辽源|liaoyuan|AJL'=>array('东丰|dongfeng|AJL',),
      '四平|siping|AJL'=>array('公主岭|gongzhuling|AJL','梨树|lishu|AJL','双辽|shuangliao|AJL','伊通|yitong|AJL',),
      '松原|songyuan|AJL'=>array('长岭|changling|AJL','扶余|fuyu|AJL','乾安|qianan1|AJL','前郭|qianguo|AJL',),
      '通化|tonghuaxian|AJL'=>array('集安|jian1|AJL','梅河口|meihekou|AJL','辉南|huinan|AJL','柳河|liuhe2|AJL',),
      '通化县|tonghuaxian|AJL'=>array(),
  ),

  '江苏'=>array(
      '南京|nanjing1|AJS'=>array('高淳|gaochun|AJS','江宁|jiangning|AJS','六合|liuhe1|AJS','浦口|pukou|AJS','溧水|lishui2|AJS',),
      '常州|changzhou|AJS'=>array('金坛|jintan|AJS','溧阳|liyang|AJS',),
      '连云港|lianyungang|AJS'=>array('赣榆|ganyu|AJS','东海|donghai|AJS','灌南|guannan|AJS','灌云|guanyun|AJS',),
      '南通|nantong|AJS'=>array('海安|haian|AJS','海门|haimen|AJS','启东|qidong2|AJS','如东|rudong|AJS','如皋|rugao|AJS',),
      '苏州|suzhou3|AJS'=>array('常熟|changshu|AJS','昆山|kunshan|AJS','太仓|taicang|AJS','吴江|wujiang|AJS','张家港|zhangjiagang|AJS',),
      '宿迁|suqian|AJS'=>array('沭阳|shuyang|AJS','泗洪|sihong|AJS','泗阳|siyang|AJS',),
      '泰州|taizhou|AJS'=>array('姜堰|jiangyan|AJS','靖江|jingjiang|AJS','泰兴|taixing|AJS','兴化|xinghua|AJS',),
      '无锡|wuxi2|AJS'=>array('江阴|jiangyin|AJS','宜兴|yixing|AJS',),
      '徐州|xuzhou|AJS'=>array('丰县|fengxian3|AJS','沛县|peixian|AJS','新沂|xinyi1|AJS','邳州|pizhou|AJS','睢宁|huining1|AJS',),
      '盐城|yancheng2|AJS'=>array('东台|dongtai|AJS','滨海|binhai|AJS','大丰|dafeng|AJS','阜宁|funing1|AJS','建湖|jianhu|AJS','射阳|sheyang|AJS','响水|xiangshui|AJS',),
      '扬州|yangzhou|AJS'=>array('高邮|gaoyou|AJS','宝应|baoying|AJS','江都|jiangdou|AJS','仪征|yizheng|AJS',),
      '镇江|zhenjiang|AJS'=>array('丹阳|danyang|AJS','句容|jurong|AJS','扬中|yangzhong|AJS',),
      '淮安|huaian1|AJS'=>array('盱眙|xuyi|AJS','洪泽|hongze|AJS','金湖|jinhu|AJS','涟水|lianshui|AJS',),
  ),

  '江西'=>array(
      '南昌|nanchang|AJX'=>array('安义|anyi|AJX','进贤|jinxian|AJX','新建|xinjian|AJX',),
      '抚州|fuzhou2|AJX'=>array('广昌|guangchang|AJX','崇仁|chongren|AJX','东乡|dongxiang1|AJX','金溪|jinxi|AJX','乐安|lean|AJX','黎川|lichuan1|AJX','南城|nancheng|AJX','南丰|nanfeng|AJX','宜黄|yihuang|AJX','资溪|zixi|AJX',),
      '赣州|ganzhou|AJX'=>array('安远|anyuan|AJX','崇义|chongyi|AJX','大余|dayu|AJX','定南|dingnan|AJX','会昌|huichang|AJX','龙南|longnan|AJX','南康|nankang|AJX','宁都|ningdou|AJX','全南|quannan|AJX','瑞金|ruijin|AJX','上犹|shangyou|AJX','石城|shicheng|AJX','信丰|xinfeng1|AJX','兴国|xingguo|AJX','寻乌|xunwu|AJX','于都|yudou|AJX',),
      '吉安|jian2|AJX'=>array('安福|anfu|AJX','吉水|jishui|AJX','井冈山|jinggangshan|AJX','宁冈|ninggang|AJX','遂川|suichuan|AJX','泰和|taihe2|AJX','万安|wanan|AJX','峡江|xiajiang|AJX','新干|xingan1|AJX','永丰|yongfeng|AJX','永新|yongxin|AJX',),
      '景德镇|jingdezhen|AJX'=>array('乐平|leping|AJX',),
      '九江|jiujiang|AJX'=>array('庐山|lushan3|AJX','德安|dean|AJX','都昌|douchang|AJX','湖口|hukou|AJX','彭泽|pengze|AJX','瑞昌|ruichang|AJX','武宁|wuning|AJX','星子|xingzi|AJX','修水|xiushui|AJX','永修|yongxiu|AJX',),
      '萍乡|pingxiang1|AJX'=>array('莲花|lianhua|AJX',),
      '上饶|shangraoxian|AJX'=>array('玉山|yushan|AJX','德兴|dexing|AJX','广丰|guangfeng|AJX','横峰|hengfeng|AJX','铅山|qianshan1|AJX','万年|wannian|AJX','余干|yugan|AJX','弋阳|yiyang2|AJX','婺源|wuyuan2|AJX',),
      '新余|xinyu|AJX'=>array('分宜|fenyi|AJX',),
      '宜春|yichun2|AJX'=>array('丰城|fengcheng_|AJX','奉新|fengxin|AJX','高安|gaoan|AJX','靖安|jingan|AJX','上高|shanggao|AJX','铜鼓|tonggu|AJX','万载|wanzai|AJX','宜丰|yifeng|AJX','樟树|zhangshu|AJX',),
      '鹰潭|yingtan|AJX'=>array('贵溪|guixi|AJX','余江|yujiang|AJX',),
      '上饶县|shangraoxian|AJX'=>array(),
  ),

  '辽宁'=>array(
      '沈阳|shenyang|ALN'=>array('法库|faku|ALN','康平|kangping|ALN','辽中|liaozhong|ALN','新民|xinmin|ALN',),
      '鞍山|anshan|ALN'=>array('海城|haicheng|ALN','台安|taian1|ALN','岫岩|xiuyan|ALN',),
      '本溪|benxi|ALN'=>array('桓仁|huanren|ALN',),
      '朝阳|chaoyang1|ALN'=>array('北票|beipiao|ALN','建平|jianping|ALN','喀左|kazuo|ALN','凌源|lingyuan|ALN',),
      '大连|dalian|ALN'=>array('瓦房店|wafangdian|ALN','长海|changhai|ALN','金州|jinzhou4|ALN','旅顺|lvshun|ALN','普兰店|pulandian|ALN','庄河|zhuanghe|ALN',),
      '丹东|dandong|ALN'=>array('东港|donggang_|ALN','凤城|fengcheng|ALN','宽甸|kuandian|ALN',),
      '阜新|fuxin|ALN'=>array('彰武|zhangwu|ALN',),
      '葫芦岛|huludao|ALN'=>array('建昌|jianchang|ALN','绥中|suizhong|ALN','兴城|xingcheng|ALN',),
      '锦州|jinzhou3|ALN'=>array('北镇|beizhen|ALN','黑山|heishan|ALN','凌海|linghai|ALN','义县|yixian1|ALN',),
      '辽阳|liaoyangxian|ALN'=>array('灯塔|dengta|ALN',),
      '铁岭|tieling|ALN'=>array('昌图|changtu|ALN','开原|kaiyuan1|ALN','西丰|xifeng1|ALN',),
      '营口|yingkou|ALN'=>array('大石桥|dashiqiao|ALN','盖州|gaizhou|ALN',),
      '本溪县|benxixian|ALN'=>array(),
      '抚顺|fushun4|ALN'=>array('新宾|xinbin|ALN','清原|qingyuan2|ALN',),
      '辽阳县|liaoyangxian|ALN'=>array(),
      '盘锦|panjin|ALN'=>array(),
  ),

  '内蒙古'=>array(
      '呼和浩特|huhehaote|ANM'=>array('和林格尔|helingeer|ANM','清水河|qingshuihe|ANM','土默特左旗|tumotezuoqi|ANM','托克托|tuoketuo|ANM','武川|wuchuan7|ANM',),
      '包头|baotou|ANM'=>array('白云鄂博|baiyunebo|ANM','达尔罕茂明安联合旗|daerhanmaominganlianheqi|ANM','固阳|guyang|ANM','满都拉|mandoula|ANM','土默特右旗|tumoteyouqi|ANM','希拉穆仁|xilamuren|ANM',),
      '赤峰|chifeng|ANM'=>array('巴林右旗|balinyouqi|ANM','阿鲁科尔沁旗|alukeerqinqi|ANM','敖汉旗|aohanqi|ANM','八里罕|balihan|ANM','巴林左旗|balinzuoqi|ANM','岗子|gangzi|ANM','浩尔吐|haoertu|ANM','喀喇沁旗|kalaqinqi|ANM','克什克腾旗|keshenketengqi|ANM','林西|linxi2|ANM','宁城|ningcheng|ANM','翁牛特旗|wengniuteqi|ANM',),
      '通辽|tongliao|ANM'=>array('巴雅尔吐胡硕|bayaertuhushuo|ANM','霍林郭勒|huolinguole|ANM','开鲁|kailu|ANM','科尔沁左翼后旗|keerqinzuoyihouqi|ANM','科尔沁左翼中旗|keerqinzuoyizhongqi|ANM','库伦旗|kulunqi|ANM','奈曼旗|naimanqi|ANM','青龙山|qinglongshan|ANM','舍伯吐|shebotu|ANM','扎鲁特旗|zaluteqi|ANM',),
      '乌海|wuhai|ANM'=>array(),
  ),

  '宁夏'=>array(
      '银川|yinchuan|ANX'=>array('贺兰|helan|ANX','灵武|lingwu|ANX','永宁|yongning1|ANX',),
      '固原|guyuan_|ANX'=>array('隆德|longde|ANX','彭阳|pengyang|ANX','西吉|xiji|ANX','泾源|jingyuan2|ANX',),
      '吴忠|wuzhong|ANX'=>array('青铜峡|qingtongxia|ANX','同心|tongxin|ANX','盐池|yanchi|ANX',),
      '中卫|zhongwei|ANX'=>array('海原|haiyuan|ANX','中宁|zhongning|ANX',),
  ),

  '青海'=>array(
      '西宁|xining|AQH'=>array('大通|datong_|AQH','湟源|huangyuan|AQH','湟中|huangzhong|AQH',),
      '格尔木|geermu|AQH'=>array('都兰|doulan|AQH',),
      '玉树|yushu1|AQH'=>array('囊谦|nangqian|AQH','曲麻莱|qumalai|AQH','杂多|zaduo|AQH','治多|zhiduo|AQH','称多|chengduo|AQH',),
  ),

  '山东'=>array(
      '济南|jinan|ASD'=>array('长清|changqing|ASD','济阳|jiyang|ASD','平阴|pingyin|ASD','商河|shanghe|ASD','章丘|zhangqiu|ASD',),
      '滨州|binzhou|ASD'=>array('博兴|boxing|ASD','惠民|huimin|ASD','无棣|wudi|ASD','阳信|yangxin2|ASD','沾化|zhanhua|ASD','邹平|zouping|ASD',),
      '德州|dezhou|ASD'=>array('乐陵|leling|ASD','临邑|linyi2|ASD','陵县|lingxian|ASD','宁津|ningjin2|ASD','平原|pingyuan1|ASD','齐河|qihe|ASD','庆云|qingyun|ASD','武城|wucheng|ASD','夏津|xiajin|ASD','禹城|yucheng2|ASD',),
      '东营|dongying|ASD'=>array('广饶|guangrao|ASD','垦利|kenli|ASD','利津|lijin|ASD',),
      '菏泽|heze|ASD'=>array('曹县|caoxian|ASD','成武|chengwu|ASD','单县|shanxian|ASD','定陶|dingtao|ASD','东明|dongming|ASD','巨野|juye|ASD','郓城|yuncheng1|ASD','鄄城|juancheng|ASD',),
      '济宁|jining2|ASD'=>array('嘉祥|jiaxiang|ASD','金乡|jinxiang|ASD','梁山|liangshan|ASD','曲阜|qufu|ASD','微山|weishan2|ASD','鱼台|yutai|ASD','邹城|zoucheng|ASD','兖州|yanzhou|ASD','汶上|wenshang|ASD','泗水|sishui|ASD',),
      '莱芜|laiwu|ASD'=>array(),
      '聊城|liaocheng|ASD'=>array('东阿|donge|ASD','高唐|gaotang|ASD','冠县|guanxian|ASD','临清|linqing|ASD','阳谷|yanggu|ASD','茌平|chiping|ASD','莘县|shenxian|ASD',),
      '临沂|linyi4|ASD'=>array('苍山|cangshan|ASD','费县|feixian|ASD','临沭|linshu|ASD','蒙阴|mengyin|ASD','平邑|pingyi|ASD','沂南|yinan|ASD','沂水|yishui|ASD','郯城|tancheng|ASD','莒南|junan|ASD',),
      '青岛|qingdao|ASD'=>array('即墨|jimo|ASD','胶南|jiaonan|ASD','胶州|jiaozhou|ASD','莱西|laixi|ASD','平度|pingdu|ASD','崂山|laoshan|ASD',),
      '日照|rizhao|ASD'=>array('五莲|wulian|ASD','莒县|juxian|ASD',),
      '泰安|taian2|ASD'=>array('东平|dongping|ASD','肥城|feicheng|ASD','宁阳|ningyang|ASD','新泰|xintai|ASD',),
      '威海|weihai|ASD'=>array('成山头|chengshantou|ASD','荣成|rongcheng2|ASD','乳山|rushan|ASD','文登|wendeng|ASD',),
      '潍坊|weifang|ASD'=>array('安丘|anqiu|ASD','昌乐|changle|ASD','昌邑|changyi|ASD','高密|gaomi|ASD','临朐|linqu|ASD','青州|qingzhou|ASD','寿光|shouguang|ASD','诸城|zhucheng|ASD',),
      '烟台|yantai|ASD'=>array('长岛|changdao|ASD','福山|fushan2|ASD','海阳|haiyang|ASD','莱阳|laiyang|ASD','莱州|laizhou|ASD','龙口|longkou|ASD','牟平|mouping|ASD','蓬莱|penglai|ASD','栖霞|qixia|ASD','招远|zhaoyuan2|ASD',),
      '枣庄|zaozhuang|ASD'=>array('台儿庄|taierzhuang|ASD','薛城|xuecheng|ASD','峄城|yicheng2|ASD','滕州|tengzhou|ASD',),
      '淄博|zibo|ASD'=>array('博山|boshan|ASD','高青|gaoqing|ASD','桓台|huantai|ASD','临淄|linzi|ASD','沂源|yiyuan|ASD','周村|zhoucun|ASD','淄川|zichuan|ASD',),
  ),

  '山西'=>array(
      '太原|taiyuan|ASX'=>array('娄烦|loufan|ASX','清徐|qingxu|ASX','阳曲|yangqu|ASX',),
      '长治|changzhi|ASX'=>array('黎城|licheng|ASX','长子|changzi|ASX','壶关|huguan|ASX','潞城|lucheng|ASX','平顺|pingshun|ASX','沁县|qinxian|ASX','沁源|qinyuan|ASX','屯留|tunliu|ASX','武乡|wuxiang|ASX','襄垣|xiangyuan|ASX',),
      '大同|datongxian|ASX'=>array('广灵|guangling|ASX','浑源|hunyuan|ASX','灵丘|lingqiu|ASX','天镇|tianzhen|ASX','阳高|yanggao|ASX','左云|zuoyun|ASX',),
      '晋城|jincheng|ASX'=>array('高平|gaoping|ASX','陵川|lingchuan1|ASX','沁水|qinshui|ASX','阳城|yangcheng|ASX',),
      '临汾|linfen|ASX'=>array('安泽|anze|ASX','大宁|daning|ASX','汾西|fenxi|ASX','浮山|fushan1|ASX','古县|guxian|ASX','洪洞|hongdong|ASX','侯马|houma|ASX','霍州|huozhou|ASX','吉县|jixian1|ASX','蒲县|puxian|ASX','曲沃|quwo|ASX','襄汾|xiangfen|ASX','乡宁|xiangning|ASX','翼城|yicheng1|ASX','永和|yonghe|ASX','隰县|xixian4|ASX',),
      '吕梁|lvliang|ASX'=>array('文水|wenshui|ASX','方山|fangshan_|ASX','汾阳|fenyang|ASX','交城|jiaocheng|ASX','交口|jiaokou|ASX','临县|linxian|ASX','柳林|liulin|ASX','石楼|shilou|ASX','孝义|xiaoyi|ASX','兴县|xingxian|ASX','中阳|zhongyang|ASX','岚县|lanxian|ASX',),
      '朔州|shuozhou|ASX'=>array('怀仁|huairen|ASX','平鲁|pinglu1|ASX','山阴|shanyin|ASX','应县|yingxian|ASX','右玉|youyu|ASX',),
      '忻州|xinzhou1|ASX'=>array('五台山|wutaishan|ASX','保德|baode|ASX','代县|daixian|ASX','定襄|dingxiang|ASX','繁峙|fanzhi|ASX','河曲|hequ|ASX','静乐|jingle|ASX','宁武|ningwu|ASX','偏关|pianguan|ASX','神池|shenchi|ASX','五寨|wuzhai|ASX','原平|yuanping|ASX','岢岚|kelan|ASX',),
      '阳泉|yangquan|ASX'=>array('平定|pingding|ASX','盂县|yuxian6|ASX',),
      '运城|yuncheng2|ASX'=>array('河津|hejin|ASX','临猗|linyi3|ASX','平陆|pinglu2|ASX','万荣|wanrong|ASX','闻喜|wenxi|ASX','夏县|xiaxian|ASX','新绛|xinjiang|ASX','永济|yongji2|ASX','垣曲|yuanqu|ASX','芮城|ruicheng|ASX','绛县|jiangxian|ASX','稷山|jishan|ASX',),
      '大同县|datongxian|ASX'=>array(),
      '晋中|jinzhong|ASX'=>array('平遥|pingyao|ASX','和顺|heshun|ASX','介休|jiexiu|ASX','灵石|lingshi|ASX','祁县|qixian2|ASX','寿阳|shouyang|ASX','昔阳|xiyang|ASX','榆社|yushe|ASX','左权|zuoquan|ASX',),
  ),

  '陕西'=>array(
      '西安|xian|ASN'=>array('长安|changan|ASN','高陵|gaoling|ASN','户县|huxian|ASN','蓝田|lantian|ASN','临潼|lintong|ASN','周至|zhouzhi|ASN',),
      '安康|ankang|ASN'=>array('白河|baihe|ASN','汉阴|hanyin|ASN','宁陕|ningshan|ASN','平利|pingli|ASN','石泉|shiquan|ASN','旬阳|xunyang|ASN','镇坪|zhenping1|ASN','紫阳|ziyang1|ASN','岚皋|langao|ASN',),
      '宝鸡|baoji|ASN'=>array('陈仓|chencang|ASN','凤县|fengxian2|ASN','凤翔|fengxiang|ASN','扶风|fufeng|ASN','陇县|longxian|ASN','眉县|meixian1|ASN','千阳|qianyang|ASN','太白|taibai|ASN','岐山|qishan|ASN','麟游|linyou|ASN',),
      '汉中|hanzhong|ASN'=>array('城固|chenggu|ASN','佛坪|foping|ASN','留坝|liuba|ASN','略阳|lveyang|ASN','勉县|mianxian|ASN','南郑|nanzheng|ASN','宁强|ningqiang|ASN','西乡|xixiang|ASN','洋县|yangxian|ASN','镇巴|zhenba|ASN',),
      '商洛|shangluo|ASN'=>array('丹凤|danfeng|ASN','洛南|luonan|ASN','山阳|shanyang|ASN','商南|shangnan|ASN','镇安|zhenan|ASN','柞水|zhashui|ASN',),
      '铜川|tongchuan|ASN'=>array('宜君|yijun|ASN',),
      '渭南|weinan|ASN'=>array('白水|baishui|ASN','澄城|chengcheng|ASN','大荔|dali_|ASN','富平|fuping5|ASN','韩城|hancheng|ASN','合阳|heyang|ASN','华县|huaxian2|ASN','华阴|huayin|ASN','蒲城|pucheng1|ASN','潼关|tongguan|ASN',),
      '咸阳|xianyang|ASN'=>array('彬县|binxian|ASN','长武|changwu|ASN','淳化|chunhua|ASN','礼泉|liquan|ASN','乾县|qianxian|ASN','三原|sanyuan|ASN','武功|wugong|ASN','兴平|xingping|ASN','旬邑|xunyi|ASN','永寿|yongshou|ASN','泾阳|jingyang|ASN',),
      '延安|yanan|ASN'=>array('安塞|ansai|ASN','富县|fuxian|ASN','甘泉|ganquan|ASN','黄陵|huangling|ASN','黄龙|huanglong|ASN','洛川|luochuan|ASN','延长|yanchang|ASN','延川|yanchuan|ASN','宜川|yichuan|ASN','志丹|zhidan|ASN','子长|zichang|ASN',),
      '榆林|yulin3|ASN'=>array('定边|dingbian|ASN','府谷|fugu|ASN','横山|hengshan2|ASN','佳县|jiaxian2|ASN','靖边|jingbian|ASN','米脂|mizhi|ASN','清涧|qingjian|ASN','神木|shenmu|ASN','绥德|suide|ASN','吴堡|wubu|ASN','子洲|zizhou|ASN',),
      '杨凌|yangling|ASN'=>array(),
  ),

  '四川'=>array(
      '成都|chengdu|ASC'=>array('大邑|dayi|ASC','都江堰|doujiangyan|ASC','金堂|jintang|ASC','龙泉驿|longquanyi|ASC','蒲江|pujiang2|ASC','双流|shuangliu|ASC','温江|wenjiang|ASC','新都|xindou|ASC','新津|xinjin|ASC','邛崃|qionglai|ASC','郫县|pixian|ASC',),
      '阿坝|aba|ASC'=>array('黑水|heishui|ASC','红原|hongyuan|ASC','金川|jinchuan|ASC','理县|lixian4|ASC','马尔康|maerkang|ASC','茂县|maoxian|ASC','南坪|nanping1|ASC','壤塘|rangtang|ASC','若尔盖|ruoergai|ASC','松潘|songpan|ASC','小金|xiaojin|ASC','汶川|wenchuan|ASC',),
      '巴中|bazhong|ASC'=>array('南江|nanjiang|ASC','平昌|pingchang|ASC','通江|tongjiang2|ASC',),
      '达州|dazhou|ASC'=>array('大竹|dazhu|ASC','开江|kaijiang|ASC','渠县|quxian|ASC','万源|wanyuan|ASC','宣汉|xuanhan|ASC',),
      '德阳|deyang|ASC'=>array('广汉|guanghan|ASC','罗江|luojiang|ASC','绵竹|mianzhu|ASC','什邡|shenfang|ASC','中江|zhongjiang|ASC',),
      '甘孜|ganzi|ASC'=>array('巴塘|batang|ASC','白玉|baiyu|ASC','丹巴|danba|ASC','稻城|daocheng|ASC','道孚|daofu|ASC','德格|dege|ASC','得荣|derong|ASC','九龙|jiulong|ASC','康定|kangding|ASC','理塘|litang|ASC','炉霍|luhuo|ASC','色达|seda|ASC','石渠|shiqu|ASC','乡城|xiangcheng1|ASC','新龙|xinlong|ASC','雅江|yajiang|ASC','泸定|luding|ASC',),
      '广安|guangan|ASC'=>array('邻水|linshui|ASC','武胜|wusheng|ASC','岳池|yuechi|ASC',),
      '广元|guangyuan|ASC'=>array('苍溪|cangxi|ASC','剑阁|jiange|ASC','青川|qingchuan|ASC','旺苍|wangcang|ASC',),
      '乐山|leshan|ASC'=>array('峨眉山|emeishan|ASC','峨边|ebian|ASC','夹江|jiajiang|ASC','井研|jingyan|ASC','马边|mabian|ASC','沐川|muchuan|ASC','犍为|jianwei|ASC',),
      '眉山|meishan|ASC'=>array('丹棱|danleng|ASC','洪雅|hongya|ASC','彭山|pengshan|ASC','青神|qingshen|ASC','仁寿|renshou|ASC',),
      '绵阳|mianyang|ASC'=>array('安县|anxian|ASC','北川|beichuan|ASC','江油|jiangyou|ASC','平武|pingwu|ASC','三台|santai|ASC','盐亭|yanting|ASC','梓潼|zitong|ASC',),
      '南充|nanchong|ASC'=>array('南部|nanbu|ASC','蓬安|pengan|ASC','西充|xichong|ASC','仪陇|yilong|ASC','营山|yingshan2|ASC','阆中|langzhong|ASC',),
      '内江|neijiang|ASC'=>array('隆昌|longchang|ASC','威远|weiyuan1|ASC','资中|zizhong|ASC',),
      '攀枝花|panzhihua|ASC'=>array('米易|miyi|ASC','仁和|renhe|ASC','盐边|yanbian|ASC',),
      '遂宁|suining2|ASC'=>array('蓬溪|pengxi|ASC','射洪|shehong|ASC',),
      '雅安|yaan|ASC'=>array('宝兴|baoxing|ASC','汉源|hanyuan|ASC','芦山|lushan1|ASC','名山|mingshan|ASC','石棉|shimian|ASC','天全|tianquan|ASC',),
      '宜宾|yibinxian|ASC'=>array('长宁|changning3|ASC','高县|gaoxian|ASC','江安|jiangan|ASC','南溪|nanxi|ASC','屏山|pingshan2|ASC','兴文|xingwen|ASC','珙县|gongxian|ASC','筠连|yunlian|ASC',),
      '资阳|ziyang2|ASC'=>array('安岳|anyue|ASC','简阳|jianyang1|ASC','乐至|lezhi|ASC',),
      '自贡|zigong|ASC'=>array('富顺|fushun3|ASC','荣县|rongxian2|ASC',),
      '泸州|luzhou|ASC'=>array('泸县|luxian|ASC','古蔺|gulin|ASC','合江|hejiang|ASC','纳溪|naxi|ASC','叙永|xuyong|ASC',),
      '宜宾县|yibinxian|ASC'=>array(),
  ),

  '西藏'=>array(
      '拉萨|lasa|AXZ'=>array('当雄|dangxiong|AXZ','尼木|nimu|AXZ',),
      '昌都|changdou|AXZ'=>array('丁青|dingqing|AXZ','洛隆|luolong|AXZ','芒康|mangkang|AXZ','左贡|zuogong|AXZ',),
      '林芝|linzhi|AXZ'=>array('波密|bomi|AXZ','察隅|chayu|AXZ','米林|milin|AXZ',),
      '那曲|naqu|AXZ'=>array('安多|anduo|AXZ','班戈|bange|AXZ','嘉黎|jiali|AXZ','申扎|shenza|AXZ','索县|suoxian|AXZ',),
      '日喀则|rikaze|AXZ'=>array('定日|dingri|AXZ','江孜|jiangzi|AXZ','拉孜|lazi|AXZ','南木林|nanmulin|AXZ','聂拉木|nielamu|AXZ','帕里|pali|AXZ',),
  ),

  '新疆'=>array(
      '乌鲁木齐|wulumuqi|AXJ'=>array('白杨沟|baiyanggou|AXJ','达坂城|dabancheng|AXJ','天池|tianchi|AXJ','小渠子|xiaoquzi|AXJ',),
      '阿克苏|akesu|AXJ'=>array('阿瓦提|awati|AXJ','拜城|baicheng_|AXJ','柯坪|keping|AXJ','库车|kuche|AXJ','沙雅|shaya|AXJ','温宿|wensu|AXJ','乌什|wushen|AXJ','新和|xinhe2|AXJ',),
      '阿拉尔|alaer|AXJ'=>array(),
      '阿勒泰|aletai|AXJ'=>array('布尔津|buerjin|AXJ','福海|fuhai|AXJ','富蕴|fuyun|AXJ','哈巴河|habahe|AXJ','吉木乃|jimunai|AXJ','青河|qinghe1|AXJ',),
      '昌吉|changji|AXJ'=>array('奇台|qitai|AXJ','蔡家湖|caijiahu|AXJ','阜康|fukang|AXJ','呼图壁|hutubi|AXJ','吉木萨尔|jimusaer|AXJ','玛纳斯|manasi|AXJ','米泉|miquan|AXJ','木垒|mulei|AXJ',),
      '哈密|hami|AXJ'=>array('巴里坤|balikun|AXJ','伊吾|yiwu1|AXJ',),
      '和田|hetian|AXJ'=>array('策勒|cele|AXJ','洛浦|luopu|AXJ','民丰|minfeng|AXJ','墨玉|moyu|AXJ','皮山|pishan|AXJ','于田|yutian3|AXJ',),
      '喀什|kashi|AXJ'=>array('巴楚|bachu|AXJ','麦盖提|maigaiti|AXJ','莎车|suoche|AXJ','塔什库尔干|tashenkuergan|AXJ','叶城|yecheng|AXJ','英吉沙|yingjisha|AXJ','岳普湖|yuepuhu|AXJ','泽普|zepu|AXJ','伽师|jiashi|AXJ',),
      '克拉玛依|kelamayi|AXJ'=>array(),
      '石河子|shihezi|AXJ'=>array('莫索湾|mosuowan|AXJ','炮台|paotai|AXJ',),
      '塔城|tacheng|AXJ'=>array('沙湾|shawan|AXJ','额敏|emin|AXJ','托里|tuoli|AXJ','乌苏|wusu|AXJ','裕民|yumin|AXJ',),
      '吐鲁番|tulufan|AXJ'=>array('托克逊|tuokexun|AXJ','鄯善|shanshan|AXJ',),
  ),

  '云南'=>array(
      '昆明|kunming|AYN'=>array('安宁|anning|AYN','呈贡|chenggong|AYN','东川|dongchuan|AYN','富民|fumin|AYN','晋宁|jinning|AYN','禄劝|luquan|AYN','石林|shilin|AYN','太华山|taihuashan|AYN','寻甸|xundian|AYN','宜良|yiliang1|AYN','嵩明|songming|AYN',),
      '保山|baoshan_|AYN'=>array('昌宁|changning1|AYN','龙陵|longling|AYN','施甸|shidian|AYN','腾冲|tengchong|AYN',),
      '楚雄|chuxiong|AYN'=>array('大姚|dayao|AYN','禄丰|lufeng1|AYN','牟定|mouding|AYN','南华|nanhua|AYN','双柏|shuangbai|AYN','武定|wuding|AYN','姚安|yaoan|AYN','永仁|yongren|AYN','元谋|yuanmou|AYN',),
      '大理|dali|AYN'=>array('宾川|binchuan|AYN','洱源|eryuan|AYN','鹤庆|heqing|AYN','剑川|jianchuan|AYN','弥渡|midu|AYN','南涧|nanjian|AYN','巍山|weishan1|AYN','祥云|xiangyun|AYN','漾濞|yangbi|AYN','永平|yongping|AYN','云龙|yunlong|AYN',),
      '红河|honghe|AYN'=>array('个旧|gejiu|AYN','河口县|hekouxian|AYN','建水|jianshui|AYN','金平|jinping2|AYN','开远|kaiyuan2|AYN','绿春|lvchun|AYN','蒙自|mengzi|AYN','弥勒|mile|AYN','屏边|pingbian|AYN','石屏|shiping|AYN','元阳|yuanyang|AYN','泸西|luxi3|AYN',),
      '丽江|lijiang|AYN'=>array('华坪|huaping|AYN','宁蒗|ninglang|AYN','永胜|yongsheng|AYN',),
      '临沧|lincang|AYN'=>array('沧源|cangyuan|AYN','凤庆|fengqing|AYN','耿马|gengma|AYN','双江|shuangjiang|AYN','永德|yongde|AYN','云县|yunxian1|AYN','镇康|zhenkang|AYN',),
      '文山|wenshan|AYN'=>array('富宁|funing2|AYN','广南|guangnan|AYN','麻栗坡|malipo|AYN','马关|maguan|AYN','丘北|qiubei|AYN','西畴|xichou|AYN','砚山|yanshan2|AYN',),
      '玉溪|yuxi|AYN'=>array('澄江|chengjiang|AYN','峨山|eshan|AYN','华宁|huaning|AYN','江川|jiangchuan|AYN','通海|tonghai|AYN','新平|xinping|AYN','易门|yimen|AYN','元江|yuanjiang3|AYN',),
      '昭通|zhaotong|AYN'=>array('大关|daguan|AYN','鲁甸|ludian|AYN','巧家|qiaojia|AYN','绥江|suijiang|AYN','威信|weixin|AYN','盐津|yanjin|AYN','彝良|yiliang2|AYN','永善|yongshan|AYN','镇雄|zhenxiong|AYN',),
      '曲靖|qujing|AYN'=>array('富源|fuyuan1|AYN','会泽|huize|AYN','陆良|luliang|AYN','罗平|luoping|AYN','马龙|malong|AYN','师宗|shizong|AYN','宣威|xuanwei|AYN',),
  ),

  '浙江'=>array(
      '杭州|hangzhou|AZJ'=>array('临安|linan|AZJ','淳安|chunan|AZJ','富阳|fuyang2|AZJ','建德|jiande|AZJ','桐庐|tonglu|AZJ','萧山|xiaoshan|AZJ',),
      '湖州|huzhou|AZJ'=>array('安吉|anji|AZJ','长兴|changxing|AZJ','德清|deqing_|AZJ',),
      '嘉兴|jiaxing|AZJ'=>array('平湖|pinghu|AZJ','海宁|haining|AZJ','海盐|haiyan2|AZJ','嘉善|jiashan|AZJ','桐乡|tongxiang|AZJ',),
      '金华|jinhua|AZJ'=>array('东阳|dongyang|AZJ','兰溪|lanxi2|AZJ','浦江|pujiang1|AZJ','武义|wuyi3|AZJ','义乌|yiwu2|AZJ','永康|yongkang|AZJ',),
      '丽水|lishui1|AZJ'=>array('龙泉|longquan|AZJ','青田|qingtian|AZJ','庆元|qingyuan3|AZJ','遂昌|suichang|AZJ','云和|yunhe|AZJ','缙云|jinyun|AZJ',),
      '宁波|ningbo|AZJ'=>array('宁海|ninghai|AZJ','北仑|beilun|AZJ','慈溪|cixi|AZJ','奉化|fenghua|AZJ','象山|xiangshan|AZJ','余姚|yuyao|AZJ',),
      '绍兴|shaoxing2|AZJ'=>array('嵊州|shengzhou|AZJ','上虞|shangyu|AZJ','新昌|xinchang|AZJ','诸暨|zhuji|AZJ',),
      '温州|wenzhou|AZJ'=>array('洞头|dongtou|AZJ','乐清|leqing|AZJ','平阳|pingyang|AZJ','瑞安|ruian|AZJ','泰顺|taishun|AZJ','文成|wencheng|AZJ','永嘉|yongjia|AZJ',),
      '衢州|quzhou1|AZJ'=>array('常山|changshan|AZJ','江山|jiangshan|AZJ','开化|kaihua|AZJ','龙游|longyou|AZJ',),
      '台州|tai-zhou|AZJ'=>array('临海|linhai|AZJ','三门|sanmen|AZJ','天台|tiantai|AZJ','温岭|wenling|AZJ','仙居|xianju|AZJ','玉环|yuhuan|AZJ',),
  ),

  '香港'=>array(
      '香港|xianggang|AXG'=>array(),
  ),

  '澳门'=>array(
      '澳门|aomen|AAM'=>array(),
  ),

  '台湾'=>array(
      '台北|taibei|ATW'=>array(),
      '高雄|gaoxiong|ATW'=>array(),
      '台中|taizhong|ATW'=>array(),
  ),

);



/*
header("content-type: text/html; charset=utf-8");
//echo var_export($seek['china'], true);

//查重复县
$url = 'getweather_seek.php';
$f = file_get_contents($url);
$n = $n2 = array();

$word = '县'; //区|镇|县|盟|旗|市
preg_match_all('/\'([^\'\|]+)'.$word.'\|/isU', $f, $m);
foreach ($m[1] as $k=>$v) {
  if (!preg_match('/\''.preg_quote($v, '/').'\|/', $f, $xian)){
    $n[] = $v;
  } else {
    $n2[] = $v;
  }
}
if (count($n) > 0) {
  //echo implode("|", $n);
  echo implode("|", $n2);
} else {
  echo '没有查到县';
}


//查重复 require '../../function/read_file.php';
$url = 'getweather_seek.php';
$f = read_file($url);
$n = $arr = array();
preg_match_all('/\'(.+)县\|(.+)\|(.+)\'/isU', $f, $m);
foreach ($m[1] as $k=>$v) {


}
if (count($n) > 0) {
  echo implode("\n", $n);
} else {
  echo '没有重复的城市';
}
*/

/*
//定期修正城市、拼音、代码等
ini_set('display_errors', false);
ini_set('default_charset', 'utf-8');
error_reporting(E_ERROR | E_WARNING | E_PARSE);
set_time_limit(0); require '../../function/read_file.php';
$text = '$seek[\'china\'] = array (
';
foreach ($seek['china'] as $sheng=>$shis) {
  $text .= '
  \''.$sheng.'\'=>array(';
  foreach ($shis as $shi => $xians) {
    list($shi1, $shi2, $shi3) = explode('|', $shi);
    $url = 'http://www.nmc.cn/publish/forecast/'.$shi3.'.html';
    if ($f = read_file($url)) {
      if (preg_match('/<a [^>]*href="\/publish\/forecast\/([A-Z-]+)\/([\w-]+)\.html">'.$shi1.'/', $f, $m)) {
        $text .= '
      \''.$shi1.'|'.$m[2].'|'.$m[1].'\'=>array(';
        unset($m);
        foreach ($xians as $xian) {
          list($xian1, , ) = explode('|', $xian);
          if (preg_match('/<a [^>]*href="\/publish\/forecast\/([A-Z-]+)\/([\w-]+)\.html">'.$xian1.'/', $f, $m)) {
            $text .= '\''.$xian1.'|'.$m[2].'|'.$m[1].'\',';
            unset($m);
          }
        }
        $text .= '),';
    
      }
    }
  }
  $text .= '
  ),
';
}
$text .= '
);
';
echo $text;
*/



?>