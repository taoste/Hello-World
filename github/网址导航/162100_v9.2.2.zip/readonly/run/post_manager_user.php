<?php require 'authentication_manager.php'; ?>
<?php

if (POWER != 5) {
  err('该命令必须以基本管理员身份登陆！请重登陆');
}


if (!(is_numeric($_POST['class_iron']) && $_POST['class_iron'] > 0) ||
    !(is_numeric($_POST['class_silver']) && $_POST['class_silver'] > 0) ||
    !(is_numeric($_POST['class_gold']) && $_POST['class_gold'] > 0)) {
  err('等级分必须为大于0的数字');
}

if ($_POST['class_iron'] >= $_POST['class_silver']) {
  err('银级分要大于铁级分');
}
if ($_POST['class_silver'] >= $_POST['class_gold']) {
  err('金级分要大于银级分');
}

$text = '<?php
@ini_set(\'default_charset\', \'utf-8\');
@ini_set(\'display_errors\', false);
error_reporting(E_ERROR | E_WARNING | E_PARSE);
';
if (PHP_VERSION < '4.1.0') {
  $text .= '
$_GET = &$HTTP_GET_VARS;
$_POST = &$HTTP_POST_VARS;
$_COOKIE = &$HTTP_COOKIE_VARS;
$_SERVER = &$HTTP_SERVER_VARS;
$_ENV = &$HTTP_ENV_VARS;
$_FILES = &$HTTP_POST_FILES;
';
}
$text .= '
$_GET = preg_replace(\'/[\r\n\\\'\"\>\<\&]+/i\', \'\', $_GET);

/* ----------【网站设置】能不用尽量不要用特殊符号，如 \ / : ; * ? \' < > | ，必免导致错误--------- */

if (!isset($GLOBALS[\'WEATHER_DATA\'])) {
  if (file_exists(\'writable/set/set.php\')) {
    $GLOBALS[\'WEATHER_DATA\'] = \'\';
  } else {
    $GLOBALS[\'WEATHER_DATA\'] = \'../../\';
  }
}

//基本参数设置：

$web[\'manager\'] = \''.$web['manager'].'\';  //基础管理员名称
$web[\'password\'] = \''.$web['password'].'\';  //基础管理员密码，注：系统出现一切故障时以基础管理员名称和密码为准
$web[\'sitehttp\'] = \'http://\'.(!empty($_SERVER[\'HTTP_X_FORWARDED_HOST\']) ? $_SERVER[\'HTTP_X_FORWARDED_HOST\'] : $_SERVER[\'HTTP_HOST\']).\'/\';  //站点网址
$web[\'root\'] = \'\';
$web[\'path\'] = dirname(trim($web[\'sitehttp\'], \'/\').$_SERVER[\'REQUEST_URI\'].\'.abc\').\'/\';  //路径
$web[\'sitename\'] = \''.$web['sitename'].'\';  //站点名称
$web[\'sitename2\'] = \''.$web['sitename2'].'\';  //站点简称
$web[\'description\'] = \''.$web['description'].'\';  //站点描述
$web[\'keywords\'] = \''.$web['keywords'].'\';  //关键字
$web[\'slogan\'] = \''.$web['slogan'].'\';  //口号
$web[\'link_type\'] = '.$web['link_type'].';  //通过export.php?url=链接路径 中转链接
$web[\'d_type\'] = '.$web['d_type'].';  //关于首页网址弹出简介？0弹出1不弹
$web[\'login_key\'] = '.var_export($web['login_key'], true).';
$web[\'chmod\'] = \''.$web['chmod'].'\';  //权限
$web[\'time_pos\'] = \''.$web['time_pos'].'\';  //服务器时区调整
$web[\'cssfile\'] = \''.$web['cssfile'].'\';  //站点默认风格
$web[\'search_bar\'] = '.$web['search_bar'].';  //默认搜索引擎样式
$web[\'newinfo_url\'] = array("'.$web['newinfo_url'][0].'","'.$web['newinfo_url'][1].'"); //信息窗调用地址

//用户控制设置：

$web[\'stop_reg\'] = '.($_POST['stop_reg'] != 1 && $_POST['stop_reg'] != 2 ? 0 : $_POST['stop_reg']).';  //用户注册 1禁止 0不禁止 2注册需审核
$web[\'mail_send\'] = '.(abs((int)$_POST['mail_send']) != 1 ? 0 : 1).';  //1发送邮件 0不发送
$web[\'stop_login\'] = '.abs($_POST['stop_login']).';  //用户登录密码错误限数 0不限
$web[\'addfunds\'] = '.(abs((int)$_POST['addfunds']) != 1 || !file_exists('addfunds.php') ? 0 : 1).';  //1开启用户创收模式
$web[\'loginadd\'] = '.round((float)$_POST['loginadd'], 3).';  //用户登陆（含注册）、推广URL来访本站赠送货币值
$web[\'loginadd2\'] = '.round((float)$_POST['loginadd2'], 4).';  //从上线分成
$web[\'loginadd_limit_ip\'] = '.abs($_POST['loginadd_limit_ip']).';  //每IP每日限注册次数计赠货币值
$web[\'cash\'] = '.round((float)$_POST['cash'], 2).';  //用户提现需达到
$web[\'class_iron\'] = '.((int)$_POST['class_iron']).'; //铁级用户等级分标准
$web[\'class_silver\'] = '.((int)$_POST['class_silver']).'; //银级用户等级分标准
$web[\'class_gold\'] = '.((int)$_POST['class_gold']).'; //金级用户等级分标准，大于此数量的为钻级用户

if (!function_exists(\'get_root_domain\')) {
  if (file_exists($GLOBALS[\'WEATHER_DATA\'].\'readonly/function/get_root_domain.php\')) {
    @ require ($GLOBALS[\'WEATHER_DATA\'].\'readonly/function/get_root_domain.php\');
  }
}
$web[\'root\'] = get_root_domain($web[\'sitehttp\']);

?>';

@ require_once 'readonly/function/write_file.php';
write_file('writable/set/set.php', $text);

if (isset($_POST['reg_statement']) && $_POST['reg_statement'] == 1) {
  rename('writable/require/statement_block.txt', 'writable/require/statement.txt');
} else {
  rename('writable/require/statement.txt', 'writable/require/statement_block.txt');
}












alert('设置系统参数成功！'.$sqlaccess, 'webmaster_central.php?get=user');



?>