<?php require 'authentication_manager.php'; ?>
<?php

@ require 'writable/set/set_html.php';
@ require_once 'readonly/function/filter.php';

if (POWER != 5) {
  err('该命令必须以基本管理员身份登陆！请重登陆');
}


  
if (!preg_match('/^[\x80-\xff\w]{3,45}$/', $_POST['manager'])) {
  err('基础管理员名称不能空且请用汉字、数字、英文及下划线组成！长度范围为3-45字符！');
}
$_POST['manager'] = strtolower($_POST['manager']);
/*
$no_ad = '';
$f = @file_get_contents('v.txt');
$v = '7.9';
if ($f && preg_match('/\$v\s*\=\s*\'(.*)\';/iU', $f, $matches)) {
  $v = base64_decode($matches[1]);
}
$v_162100 = '9.0.1';
  $v_162100_ = abs(preg_replace('/[^\d]+/', '', $v_162100));
  $v_        = abs(preg_replace('/[^\d]+/', '', $v));
  $len = strlen($v_162100_) >= strlen($v_) ? strlen($v_162100_) : strlen($v_);
  $v_162100_ = str_pad($v_162100_, $len, 0);
  $v_        = str_pad($v_, $len, 0);
  if ($v_ >= $v_162100_) {
  } else {
*/

$_POST['password'] = strtolower($_POST['password']);
/*
  }
*/

if ($_POST['password'] == '') {
  $psw = $web['password'];
} else {
  if (preg_match('/[\s\r\n]+/', $_POST['password'])) {
    err('基础管理员密码不能有空格。');
  }
  if (strlen($_POST['password']) > 30 || strlen($_POST['password']) < 3) {
    err('基础管理员密码长度是3-30字符。');
  }
  $psw = md162100($_POST['password']);
}

$_POST['goto_iphone_url'] = filter1($_POST['goto_iphone_url']);
if ($_POST['goto_iphone'] == 1) {
  if (empty($_POST['goto_iphone_url']) || !preg_match('/^https?\:\/\/.+/i', $_POST['goto_iphone_url'])) {
    err('若开启转向手机站，则手机站网址不能空！');
  }
}

function md162100($str) {
  return substr(sha1(md5($str)), 4, 32);
}
function strback($str) {
  return strrev(preg_replace('/(.{1}).{1}/', '$1', $str));
}
function filter3($text) {
  $text = trim($text);
  if (get_magic_quotes_gpc()) { //get_magic_quotes_runtime()
    $text = stripslashes($text);
  }
  $text = str_replace('[','&#091;', $text);
  $text = str_replace(']', '&#093;', $text);
  $text = preg_replace('/<\?.*\?>/sU', '', $text);
  $text = preg_replace('/<\!DOCTYPE[^>]*>/i', '', $text);
  $text = preg_replace('/<\/?(html|head|body|title|style|form|iframe|frame|frameset|noframes)[^>]*>/i', '', $text);
  $text=preg_replace('/<(hr|br|nobr|img|input|area|isindex|param)([^>]*)>/i','[\1\2]',$text); //单个使用的标记处理
  while(preg_match('/<(\w+)[^>]*>[^<>]*<\/\1>/i',$text,$mat)) {
    $text=str_replace($mat[0],str_replace('>',']',str_replace('<','[',$mat[0])),$text);
    unset($mat);
  }
  $text = preg_replace('/(\[br\]){2,}/i', '[br][br]', $text);
  while (preg_match('/(\[[^\]]*=\s*)(\"|\')([^=\2\]]+)\2([^\]]*\])/i', $text, $mat)) {
    $text=str_replace($mat[0], $mat[1].'|'.$mat[3].'|'.$mat[4], $text);
    unset($mat);
  }
  while (preg_match('/(\[[^\"\'\]]*)(\"|\')([^\]]*\])/i', $text, $mat)) {
    $text = str_replace($mat[0], $mat[1].$mat[3], $text);
    unset($mat);
  }
  $text = str_replace('\'', '\\\'', $text);
  $text = str_replace('[', '<', $text);
  $text = str_replace(']', '>', $text);
  return $text;
}

$text = '<?php
@ini_set(\'default_charset\', \'utf-8\');
@ini_set(\'display_errors\', false);
error_reporting(E_ERROR | E_WARNING | E_PARSE);
';
if (PHP_VERSION < '4.1.0') {
  $text .= '
$_GET = &$HTTP_GET_VARS;
$_POST = &$HTTP_POST_VARS;
$_COOKIE = &$HTTP_COOKIE_VARS;
$_SERVER = &$HTTP_SERVER_VARS;
$_ENV = &$HTTP_ENV_VARS;
$_FILES = &$HTTP_POST_FILES;
';
}
$text .= '
$_GET = preg_replace(\'/[\r\n\\\'\"\>\<\&]+/i\', \'\', $_GET);

/* ----------【网站设置】能不用尽量不要用特殊符号，如 \ / : ; * ? \' < > | ，必免导致错误--------- */

if (!isset($GLOBALS[\'WEATHER_DATA\'])) {
  if (file_exists(\'writable/set/set.php\')) {
    $GLOBALS[\'WEATHER_DATA\'] = \'\';
  } else {
    $GLOBALS[\'WEATHER_DATA\'] = \'../../\';
  }
}

//基本参数设置：

$web[\'manager\'] = \''.$_POST['manager'].'\';  //基础管理员名称
$web[\'password\'] = \''.$psw.'\';  //基础管理员密码，注：系统出现一切故障时以基础管理员名称和密码为准
$web[\'code_author\'] = strrev(\''.strrev(filter1($_POST['code_author'])).'\');  //作者
$web[\'sitehttp\'] = \'http://\'.(!empty($_SERVER[\'HTTP_X_FORWARDED_HOST\']) ? $_SERVER[\'HTTP_X_FORWARDED_HOST\'] : $_SERVER[\'HTTP_HOST\']).\'/\';  //站点网址
$web[\'root\'] = \'\';
$web[\'path\'] = dirname(trim($web[\'sitehttp\'], \'/\').$_SERVER[\'REQUEST_URI\'].\'.abc\').\'/\';  //路径
$web[\'sitename\'] = \''.(!empty($_POST['sitename']) ? filter1($_POST['sitename'], true) : '我的网站').'\';  //站点名称
$web[\'sitename2\'] = \''.(!empty($_POST['sitename2']) ? filter1($_POST['sitename2'], true) : '我的网站').'\';  //站点简称
$web[\'description\'] = \''.filter1($_POST['description'], true).'\';  //站点描述
$web[\'keywords\'] = \''.filter1($_POST['keywords'], true).'\';  //关键字
$web[\'slogan\'] = \''.filter3($_POST['slogan']).'\';  //口号
$web[\'link_type\'] = '.(isset($web['link_type']) ? abs($web['link_type']) : 0).';  //通过export.php?url=链接路径 中转链接
$web[\'d_type\'] = '.(isset($web['d_type']) ? abs($web['d_type']) : 0).';  //关于首页网址弹出简介？0弹出1不弹
$web[\'login_key\'] = '.var_export($_POST['login_key'], true).';
$web[\'chmod\'] = \''.(!preg_match('/^0?([0-7]{3})$/', $_POST['chmod'], $matches_chmod) ? '777' : $matches_chmod[1]).'\';  //权限
$web[\'time_pos\'] = \''.$_POST['time_pos'].'\';  //服务器时区调整
$web[\'cssfile\'] = \''.(isset($web['cssfile']) && file_exists('readonly/css/'.$web['cssfile'].'') ? $web['cssfile'] : 'default/1').'\';  //站点默认风格
$web[\'search_bar\'] = '.(isset($web['search_bar']) ? abs($web['search_bar']) : 1).';  //默认搜索引擎样式
$web[\'newinfo_url\'] = array("'.$web['newinfo_url'][0].'","'.$web['newinfo_url'][1].'"); //信息窗调用地址

//用户控制设置：

$web[\'stop_reg\'] = '.$web['stop_reg'].';  //用户注册 1禁止 0不禁止 2注册需审核
$web[\'mail_send\'] = '.$web['mail_send'].';  //1发送邮件 0不发送
$web[\'stop_login\'] = '.$web['stop_login'].';  //用户登录密码错误限数 0不限
$web[\'addfunds\'] = '.$web['addfunds'].';  //1开启用户创收模式
$web[\'loginadd\'] = '.$web['loginadd'].';  //用户登陆（含注册）、推广URL来访本站赠送货币值
$web[\'loginadd2\'] = '.$web['loginadd2'].';  //从上线分成
$web[\'loginadd_limit_ip\'] = '.$web['loginadd_limit_ip'].';  //每IP每日限注册次数计赠货币值
$web[\'cash\'] = '.$web['cash'].';  //用户提现需达到
$web[\'class_iron\'] = '.(isset($web['class_iron']) && abs($web['class_iron']) > 0 ? $web['class_iron'] : 100).'; //铁级用户等级分标准
$web[\'class_silver\'] = '.(isset($web['class_silver']) && abs($web['class_silver']) > 0 ? $web['class_silver'] : 500).'; //银级用户等级分标准
$web[\'class_gold\'] = '.(isset($web['class_gold']) && abs($web['class_gold']) > 0 ? $web['class_gold'] : 1000).'; //金级用户等级分标准，大于此数量的为钻级用户

if (!function_exists(\'get_root_domain\')) {
  if (file_exists($GLOBALS[\'WEATHER_DATA\'].\'readonly/function/get_root_domain.php\')) {
    @ require ($GLOBALS[\'WEATHER_DATA\'].\'readonly/function/get_root_domain.php\');
  }
}
$web[\'root\'] = get_root_domain($web[\'sitehttp\']);


?>';

$sqlaccess = '';
if ($_POST['manager'] != $web['manager'] || $psw != $web['password']) {
  if (!isset($sql['db_err'])) {
    $db = db_conn();
  }
  if ($sql['db_err'] == '') {
    if (db_exec($db, 'UPDATE '.$sql['pref'].''.$sql['data']['承载成员档案的表名'].' SET username="'.$_POST['manager'].'",password="'.$psw.'" WHERE username="'.$web['manager'].'" LIMIT 1')) {
      $admin_c = 1;
    } else {
      if (db_exec($db, 'UPDATE '.$sql['pref'].''.$sql['data']['承载成员档案的表名'].' SET password="'.$psw.'" WHERE username="'.$_POST['manager'].'" LIMIT 1')) {
        $admin_c = 1;
      }
    }
    if (isset($admin_c) && $admin_c == 1) {
      if ($_POST['manager'] != $web['manager']) {
        db_exec($db, 'UPDATE '.$sql['pref'].''.$sql['data']['承载财务数据的表名'].' SET username="'.$_POST['manager'].'" WHERE username="'.$web['manager'].'"');
      }
      $sqlaccess = '<div style="background-color:#FF6600; color:#FFF;">数据库管理员名称和密码副本同时更新成功。由于管理员信息被改动，建议重新登陆以使新设置生效！</div>
      <script language="javascript" type="text/javascript">
      <!--
      //var expiration=new Date((new Date()).getTime()-31600000);
      //document.cookie="usercookie="+""+"; expires="+expiration.toGMTString()+"; path="+"/"+";";
      setCookie(\'usercookie\',\'\',-366);
      -->
      </script>';
    }
  }
  db_close($db);

  if ($sqlaccess == '') {
    err('由于基础管理员信息(如名称或密码)有变，但数据库连接不成功！拒绝此次修改。请先<a href="?get=sql">连接数据库</a>');
  }
}

@ require_once 'readonly/function/write_file.php';
write_file('writable/set/set.php', $text);


if (($text_s = @file_get_contents('writable/js/main.js')) && is_writable('writable/js/main.js')) {
  $text_s = preg_replace('/\/\* time_pos \*\/.+\/\* \/time_pos \*\//isU', '/* time_pos */
  var timePos = '.floatval($_POST['time_pos']).'; //时区
  /* /time_pos */', $text_s);
  write_file('writable/js/main.js', $text_s);
}
unset($text_s);

/*
if ($_POST['index_mod'] == 'search') {
  if (filesize('index_search.php') != filesize('index.php'))
    @ copy('index_search.php', 'index.php');
} else {
  if (filesize('index_complete.php') != filesize('index.php'))
    @ copy('index_complete.php', 'index.php');
}

if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
  @unlink('./.htaccess');
  @copy('readonly/data/web.config', './web.config');
} else {
  @unlink('./web.config');
  @copy('readonly/data/.htaccess', './.htaccess');
}
*/

if ($_POST['goto_iphone'] == 1) {
  //if (file_exists('addfunds.php')) {
    write_file('writable/js/goiphone.js', '(function() {
            var sUserAgent = navigator.userAgent.toLowerCase();
            var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
            var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
            var bIsMidp = sUserAgent.match(/midp/i) == "midp";
            var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
            var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
            var bIsAndroid = sUserAgent.match(/android/i) == "android";
            var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
            var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
 
            if (bIsIpad || bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
                location.href = "'.$_POST['goto_iphone_url'].'";
            } else {
            }
        })();');
  //} else {
    //err('此功能对商业用户开放！');
  //}
} else {
  @unlink('writable/js/goiphone.js');
}


$id = gmdate('YmdHis', time() + (floatval($web['time_pos']) * 3600));
write_file('writable/require/browse_reload.txt', $id);

if ($web['html'] == true) {
  $SET_RELOAD = 1;
  //$style_set_unset .= '<div style="background-color:#FF6600; color:#FFF;">你对系统设置进行了更改，因为你开启了全静态，建议重新<a href="?post=html">一键生成全静态</a></div>';
  echo '<div style="background-color:#FF6600; color:#FFF;">正在更新静态页面...</div>
<div style="height:150px; overflow:auto;">';
  @ require 'readonly/run/post_manager_html.php';
  echo '</div>';
} else {
  //reset_indexhtml('index.php', 'index.html');
}


if ($style_set_unset != '') {
  err('设置系统参数成功！'.$sqlaccess.$style_set_unset, 'ok');
} else {
  alert('设置系统参数成功！'.$sqlaccess, 'webmaster_central.php?get=set');
}



?>