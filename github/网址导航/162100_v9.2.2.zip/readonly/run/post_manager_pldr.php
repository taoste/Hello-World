<?php
require ('authentication_manager.php');
?>
<?php
if (POWER != 5) {
  err('<script> alert("该命令必须以基本管理员身份登陆！请重登陆"); </script>');
}
err('当前版本可能无法进行此项！<a href="http://www.162100.com/pay/for_s_162100.php" target="_blank">建议您升级到商业版，谢谢支持</a><script> alert("当前版本可能无法进行此项！但你可以使用第2步进行导入。建议您升级到商业版，谢谢支持"); window.open("http://www.162100.com/pay/for_s_162100.php"); </script>');

?>