<?php require 'authentication_manager.php'; ?>
<style type="text/css">
<!--
.newcolumn { width:100%; /*float:left;*/ margin-left:0; clear:both; }
.newclass { margin:0; padding:3px 0; clear:both; overflow:hidden; border-bottom:1px #EEEEEE dotted; }
.block_span { font-size:12px; vertical-align:middle; display:inline-block !important; display:inline; zoom:1; vertical-align:middle; line-height:normal; text-align:left; overflow:hidden; }
.bjcolor { height:32px; }
.n_nav td, .gray_err { line-height:normal; background-color:#A9B6D3; font-size:12px; color:#FFFFFF; }
a.caozuo { text-decoration:none; }
.column_name { width:78px; white-space:nowrap; }
.area_ { margin-bottom:10px; padding:5px; padding-top:10px; border:1px #99FF33 solid; }
.s_m_is { text-decoration:line-through; }
.tool_area { width:18px; height:18px; background-image:url(readonly/images/tool_area.gif); background-repeat:no-repeat; }
-->
</style>
<?php
$tool_area = array();
$tool_area['align_left'] = '<span class="block_span tool_area" style="background-position:0 0;" title="字靠左排列" onmouseover="sSD(this,event);"></span>';
$tool_area['align_center'] = '<span class="block_span tool_area" style="background-position:-18px 0;" title="字居中排列" onmouseover="sSD(this,event);"></span>';
$tool_area['align_justify'] = '<span class="block_span tool_area" style="background-position:-36px 0;" title="字两端对齐" onmouseover="sSD(this,event);"></span>';
$tool_area['align_right'] = '<span class="block_span tool_area" style="background-position:-54px 0;" title="字靠右排列" onmouseover="sSD(this,event);"></span>';

$tool_area['open_new'] = '<span class="block_span tool_area" style="background-position:-72px 0;" title="打开新页面" onmouseover="sSD(this,event);"></span>';
$tool_area['open_in'] = '<span class="block_span tool_area" style="background-position:-90px 0;" title="打开弹窗内容" onmouseover="sSD(this,event);"></span>';

?>
<script type="text/javascript">
<!--
//添加链接

function addClass(class_title){
  //class_title=parseInt(class_title);
  //var tar=obj.parentNode;
  var par=$('class_'+class_title+'');
  var num=(new Date()).valueOf();
  var newDiv=document.createElement('DIV');
  newDiv.id='class_'+class_title+'_'+num+'';
  newDiv.className='newclass';
  newDiv.title=num;
  newDiv.innerHTML=' <input type="hidden" name="class['+class_title+']" title="'+num+'" /> \
<span class="block_span" style="width:100px;"><textarea rows="2" class="column_name" name="class_name['+class_title+']['+num+']"></textarea></span> \
<span class="block_span" style="width:50px;"><span class="block_span orangeword"><input onclick="addClassHttpNum(this,\''+class_title+'_'+num+'\');" type="checkbox" class="checkbox" name="class_index_show['+class_title+']['+num+']" id="class_index_show_'+class_title+'_'+num+'" value="1" checked="checked" /><strong>⇑</strong></span></span> \
<span class="block_span" style="width:200px;"> \
  <span name="class_http_num_'+class_title+'[]" id="class_http_num_'+class_title+'_'+num+'"> \
    <input type="radio" class="radio" id="class_http_num'+class_title+'_'+num+'" name="class_http_num['+class_title+']['+num+']" value="1" checked="checked" />自动截取展示<input type="text" name="class_http_num_['+class_title+']['+num+']" style="width:20px; height:20px; padding:0;" value="1" title="限填正整数" onmouseover="sSD(this,event);" onfocus="$(\'class_http_num'+class_title+'_'+num+'\').checked=true;" onblur="isDigit(this,1,0);" />行<br /> \
    <input type="radio" class="radio" name="class_http_num['+class_title+']['+num+']" value="-2" />按分页数(如分)否则<input type="radio" class="radio" name="class_http_num['+class_title+']['+num+']" value="0" />展示所有 \
  </span> \
</span> \
<span class="block_span" style="width:180px;"> \
  <label class="block_span bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="0" checked="checked" /><br />无</label><label title="白" class="block_span qd10 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="10" /></label><label class="block_span qd1 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="1" /></label><label class="block_span qd2 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="2" /></label><label class="block_span qd3 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="3" /></label><label class="block_span qd4 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="4" /></label><label class="block_span qd5 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="5" /></label><label class="block_span qd6 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="6" /></label><label class="block_span qd7 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="7" /></label><label class="block_span qd8 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="8" /></label><label class="block_span qd9 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="9" /></label> \
</span> \
<span class="block_span" style="width:120px;"> \
  <input type="radio" class="radio" name="class_http_type['+class_title+']['+num+']" value="0" checked="checked" />站名排列 <br /> \
  <input type="radio" class="radio" name="class_http_type['+class_title+']['+num+']" value="1" />弹窗简介 <br /> \
  <input type="radio" class="radio" name="class_http_type['+class_title+']['+num+']" value="2" />流布局详细显示 \
</span> \
<a class="caozuo" href="javascript:void(0)" onclick="removeOption(this);return false;" title="删除">╳</a> \
<a class="caozuo" href="javascript:void(0);" title="插入" onclick="insertClass(this,\''+class_title+'\');return false;">↖</a> \
<a class="caozuo" href="javascript:void(0);" title="上移" onclick="upClass(this,\''+class_title+'\');return false;">↑</a> \
<a class="caozuo" href="javascript:void(0);" title="上移" onclick="downClass(this,\''+class_title+'\');return false;">↓</a> \
';
  par.insertBefore(newDiv, null);
  num=num+1;
}

//插入
function insertClass(obj,class_title){
  var tar=obj.parentNode;
  var par=$('class_'+class_title+'');
  var num=(new Date()).valueOf();
  var newDiv=document.createElement('DIV');
  newDiv.id='class_'+class_title+'_'+num+'';
  newDiv.className='newclass';
  newDiv.title=num;
  newDiv.innerHTML=' <input type="hidden" name="class['+class_title+']" title="'+num+'" /> \
<span class="block_span" style="width:100px;"><textarea rows="2" class="column_name" name="class_name['+class_title+']['+num+']"></textarea></span> \
<span class="block_span" style="width:50px;"><span class="block_span orangeword"><input onclick="addClassHttpNum(this,\''+class_title+'_'+num+'\');" type="checkbox" class="checkbox" name="class_index_show['+class_title+']['+num+']" id="class_index_show_'+class_title+'_'+num+'" value="1" checked="checked" /><strong>⇑</strong></span></span> \
<span class="block_span" style="width:200px;"> \
  <span name="class_http_num_'+class_title+'[]" id="class_http_num_'+class_title+'_'+num+'"> \
    <input type="radio" class="radio" id="class_http_num'+class_title+'_'+num+'" name="class_http_num['+class_title+']['+num+']" value="1" checked="checked" />自动截取展示<input type="text" name="class_http_num_['+class_title+']['+num+']" style="width:20px; height:20px; padding:0;" value="1" title="限填正整数" onmouseover="sSD(this,event);" onfocus="$(\'class_http_num'+class_title+'_'+num+'\').checked=true;" onblur="isDigit(this,1,0);" />行<br /> \
    <input type="radio" class="radio" name="class_http_num['+class_title+']['+num+']" value="-2" />按分页数(如分)否则<input type="radio" class="radio" name="class_http_num['+class_title+']['+num+']" value="0" />展示所有 \
  </span> \
</span> \
<span class="block_span" style="width:180px;"> \
  <label class="block_span bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="0" checked="checked" /><br />无</label><label title="白" class="block_span qd10 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="10" /></label><label class="block_span qd1 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="1" /></label><label class="block_span qd2 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="2" /></label><label class="block_span qd3 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="3" /></label><label class="block_span qd4 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="4" /></label><label class="block_span qd5 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="5" /></label><label class="block_span qd6 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="6" /></label><label class="block_span qd7 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="7" /></label><label class="block_span qd8 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="8" /></label><label class="block_span qd9 bjcolor"><input type="radio" class="radio" name="class_bj['+class_title+']['+num+']" value="9" /></label> \
</span> \
<span class="block_span" style="width:120px;"> \
  <input type="radio" class="radio" name="class_http_type['+class_title+']['+num+']" value="0" checked="checked" />站名排列 <br /> \
  <input type="radio" class="radio" name="class_http_type['+class_title+']['+num+']" value="1" />弹窗简介 <br /> \
  <input type="radio" class="radio" name="class_http_type['+class_title+']['+num+']" value="2" />流布局详细显示 \
</span> \
<a class="caozuo" href="javascript:void(0)" onclick="removeOption(this);return false;" title="删除">╳</a> \
<a class="caozuo" href="javascript:void(0);" title="插入" onclick="insertClass(this,\''+class_title+'\');return false;">↖</a> \
<a class="caozuo" href="javascript:void(0);" title="上移" onclick="upClass(this,\''+class_title+'\');return false;">↑</a> \
<a class="caozuo" href="javascript:void(0);" title="上移" onclick="downClass(this,\''+class_title+'\');return false;">↓</a> \
';
  par.insertBefore(newDiv,tar);
}

//排序：链接 向上
function upClass(obj,class_title){
  var tar=obj.parentNode;
  var par=$('class_'+class_title+'');
  var prevObj=tar.previousSibling;
  while(prevObj!=null && prevObj.nodeType!=1){
    prevObj=prevObj.previousSibling;
  }
  if(prevObj==null){
    alert('已是最上级！');
    return;
  }else{
    try{par.insertBefore(tar,prevObj);}catch(err){alert('向上移动失败！请稍候再试');return;}
    //par.removeChild(tar);
  }
}

//排序：链接 向下
function downClass(obj,class_title){
  var tar=obj.parentNode;
  var par=$('class_'+class_title+'');
  var nextObj=tar.nextSibling;
  while(nextObj!=null && nextObj.nodeType!=1){
    nextObj=nextObj.nextSibling;
  }
  if(nextObj==null){
    alert('已是最下级！');
    return;
  }
  var endObj;
  if(nextObj!=null){
    var nextnextObj=nextObj.nextSibling;
    while(nextnextObj!=null && nextnextObj.nodeType!=1){
      nextnextObj=nextnextObj.nextSibling;
    }
    var endObj=nextnextObj!=null?nextnextObj:null;
  }else{
    endObj=null;
  }
  try{par.insertBefore(tar,endObj);}catch(err){alert('向下移动失败！请稍候再试');return;}
  //par.removeChild(tar);
}















//添加频道
function addColumn(cid){
  var par=$('area'+cid);
  var date=new Date();
  var num1=date.getFullYear()+''+(date.getMonth()+1).toString().replace(/^(\d{1})$/,'0$1')+''+date.getDate().toString().replace(/^(\d{1})$/,'0$1')+''+date.getHours().toString().replace(/^(\d{1})$/,'0$1')+''+date.getMinutes().toString().replace(/^(\d{1})$/,'0$1')+'';
  var num2=date.getSeconds().toString().replace(/^(\d{1})$/,'0$1');
  if($('class_'+num1+num2+'')==null){
    num=num1+num2;
  }else{
    num=num1+((parseInt(num2)+1).toString().replace(/^(\d{1})$/,'0$1'));
  }
  
  if (cid != '') {
    num = cid;
  }
/*
  var tar=document.getElementsByName("column[]");
  var end=tar.length;
  num=(end>0) ? parseInt(tar[end-3].title)+1 : 0;
*/


  var newDiv=document.createElement('DIV');
  newDiv.id='column_'+num+'';
  newDiv.style.marginBottom='7px';
  newDiv.title=num;
  newDiv.innerHTML='<input type="hidden" name="column[]" title="'+num+'" />\
  <b>频道</b> <input type="text" name="column_name['+num+']" style="width:150px;" /> \
<div class="gray_err"> <input type="checkbox" class="checkbox" name="column_atside['+num+']" value="1" onclick="runClassSide(this, \''+num+'\')" />置于边栏（——对齐方式：<label><input type="radio"  class="radio" name="column_atside_align['+num+']" value="1" checked="checked" /><?php echo $tool_area['align_left']; ?></label> \
<label><input type="radio"  class="radio" name="column_atside_align['+num+']" value="2" /><?php echo $tool_area['align_center']; ?></label> \
<label><input type="radio"  class="radio" name="column_atside_align['+num+']" value="3" /><?php echo $tool_area['align_justify']; ?></label> \
<label><input type="radio"  class="radio" name="column_atside_align['+num+']" value="4" /><?php echo $tool_area['align_right']; ?></label> \
    ——打开方式：<label><input type="radio"  class="radio" name="column_atside_type['+num+']" value="2" checked="checked" /><?php echo $tool_area['open_new']; ?></label>[<a href="login.php" target="_blank" title="注意：别在意进入什么页面，这只是示例" onmouseover="sSD(this,event);">示例</a>] \
<label><input type="radio"  class="radio" name="column_atside_type['+num+']" value="1" /><?php echo $tool_area['open_in']; ?></label>[<a href="login_current.php" onclick="addSubmitSafe(1);$(\'addCFrame\').style.display=\'block\';" target="addCFrame" title="注意：别在意进入什么页面，这只是示例" onmouseover="sSD(this,event);">示例</a>] ）</div> \
<table width="100%" border="0" cellspacing="1" cellpadding="0" class="n_nav">\
  <tr>\
    <td width="100" align="center">频道下属栏目<br />（可换行）</td>\
    <td width="50" align="center">首页<br />展示</td>\
    <td width="200" align="center">该栏目在首页推荐展示网址数量</td>\
    <td width="180" align="center">风格修饰<br />（背景着色）</td>\
    <td width="120" align="center">子页面网址排列模式<br />（<a href="?get=style#httpType" target="_blank">说明</a>）</td>\
    <td align="center">操作</td>\
  </tr>\
</table>\
  <div id="class_'+num+'" class="newcolumn"></div><div style="height:0px; overflow:hidden;clear:both;"></div>\
  <button type="button" onclick="javascript:addClass(\''+num+'\');">为此频道添加栏目</button> '+((cid!='homepage') ? '<button type="button" onclick="javascript:removeOption(this);">删除此频道</button>' : '')+' '+((cid=='')?'<button type="button" onclick="javascript:upColumn(this);" title="上移">↑</button> <button type="button" onclick="javascript:downColumn(this);" title="下移">↓</button>' : '')+'';
  par.insertBefore(newDiv, null);
  //num=num+1;
}

//排序：栏目分类 向上
function upColumn(obj){
  var par=$('area');
  var tar=obj.parentNode;
  var prevObj=tar.previousSibling;
  while(prevObj!=null && prevObj.nodeType!=1){
    prevObj=prevObj.previousSibling;
  }
  if(prevObj==null){
    alert('已是最上级！');
    return;
  }
/*
  var O_id=tar.title;
  var A_id=prevObj.title;

  tar.id='column_'+A_id+'';
  tar.title=''+A_id+'';

  tar.innerHTML=tar.innerHTML.replace(new RegExp('name="column_name\\\['+O_id+'\\\]','g'),'name="column_name['+A_id+']');
  tar.innerHTML=tar.innerHTML.replace(new RegExp('name="class\\\['+O_id+'\\\]','g'),'name="class['+A_id+']');
  tar.innerHTML=tar.innerHTML.replace(new RegExp('name="class_name\\\['+O_id+'\\\]','g'),'name="class_name['+A_id+']');
  tar.innerHTML=tar.innerHTML.replace(new RegExp('id="class_'+O_id+'','g'),'id="class_'+A_id+'');
  tar.innerHTML=tar.innerHTML.replace(new RegExp('javascript:addClass\\\(\\\''+O_id+'\\\'\\\)','g'),'javascript:addClass(\''+A_id+'\')');

  prevObj.id='column_'+O_id+'';
  prevObj.title=''+O_id+'';
  prevObj.innerHTML=prevObj.innerHTML.replace(new RegExp('name="column_name\\\['+A_id+'\\\]','g'),'name="column_name['+O_id+']');
  prevObj.innerHTML=prevObj.innerHTML.replace(new RegExp('name="class\\\['+A_id+'\\\]','g'),'name="class['+O_id+']');
  prevObj.innerHTML=prevObj.innerHTML.replace(new RegExp('name="class_name\\\['+A_id+'\\\]','g'),'name="class_name['+O_id+']');
  prevObj.innerHTML=prevObj.innerHTML.replace(new RegExp('id="class_'+A_id+'','g'),'id="class_'+O_id+'');
  prevObj.innerHTML=prevObj.innerHTML.replace(new RegExp('javascript:addClass\\\(\\\''+A_id+'\\\'\\\)','g'),'javascript:addClass(\''+O_id+'\')');
*/
  try{par.insertBefore(tar,prevObj);}catch(err){alert('向上移动失败！请稍候再试');return;}
  //par.removeChild(tar);

}

//排序：栏目分类 向下
function downColumn(obj){
  var par=$('area');
  var tar=obj.parentNode;
  var nextObj=tar.nextSibling;
  while(nextObj!=null && nextObj.nodeType!=1){
    nextObj=nextObj.nextSibling;
  }
  if(nextObj==null){
    alert('已是最下级！');
    return;
  }
  var endObj;
  if(nextObj!=null){
    var nextnextObj=nextObj.nextSibling;
    while(nextnextObj!=null && nextnextObj.nodeType!=1){
      nextnextObj=nextnextObj.nextSibling;
    }
    var endObj=nextnextObj!=null?nextnextObj:null;
  }else{
    endObj=null;
  }
  try{par.insertBefore(tar,endObj);}catch(err){alert('向下移动失败！请稍候再试');return;}
  //par.removeChild(tar);
}

//删除栏目
function removeOption(obj){
  var tar=obj.parentNode;
  var par=tar.parentNode;
  //if(confirm('确定删除此频道吗？！')){
    try{
      par.removeChild(tar);
    }catch(err){
    }
  //}
}

function frTo(fid){
  if($('class_name_fr')==null || $('class_name_to')==null){
    alert('出错！暂停此项');
    return false;
  }
  var fr=$('class_name_fr').value;
  var to=$('class_name_to').value;
  if(fr==''){
    alert('请选择起始小类！');
    return false;
  }
  if(to==''){
    alert('请选择目标小类！');
    return false;
  }
  if(fr==to){
    alert('不能重名！');
    return false;
  }
  if($('class_'+fr+'')==null){
    alert('起始小类不存在！');
    return false;
  }
  if($('class_'+to+'')==null){
    alert('目标小类不存在！');
    return false;
  }
  return true;
}

-->
</script>
<script>
// 只允许输入4-8数字
function isDigit4_8(obj, starVal) {
  if (!/^[45678]$/.test(obj.value)) {
    alert('只允许输入4-8的整数');
    obj.value = starVal;
    //obj.focus();
  }
}

function addClassHttpNum(o, id) {
  if (o.checked==true){
    $('class_http_num_'+id+'').style.display = '';
    o.parentNode.className = 'block_span orangeword';
  } else {
    $('class_http_num_'+id+'').style.display = 'none';
    o.parentNode.className = 'block_span grayword';
  }
}

function runClassSide(o, id) {
  if (o.checked == true){
    var styleDis = 'none';
    o.parentNode.className = 'red_err';
  } else {
    var styleDis = '';
    o.parentNode.className = 'gray_err';
  }
  var a = document.getElementsByName('class_http_num_'+id+'[]');
  if (a != null && a.length > 0) {
    for (var i = 0; i < a.length; i++) {
      var reg = new RegExp('class_http_num_'+id+'_', 'ig');
      var selfId = a[i].id.replace(reg, '');
      if ($('class_index_show_'+id+'_'+selfId+'')!=null && $('class_index_show_'+id+'_'+selfId+'').checked == true) {
        if ($('class_http_num_'+id+'_'+selfId+'')!=null) {
          $('class_http_num_'+id+'_'+selfId+'').style.display = styleDis;
        }
      } else {
        continue;
      }
    }
  }
}

</script>




        <?php
@ require 'writable/set/set_area.php';
//unset($web['area']['mingz']);
//unset($web['area']['homepage']);

//@ksort($web['area']);

$text = array();
foreach ((array)$web['area'] as $fid => $f) {
  $indexclass_n = abs($f['name'][2]);
  $text[$fid] .= '
  <div id="column_'.$fid.'" style="margin-bottom:7px" title="'.$fid.'">
    <input type="hidden" name="column[]" title="'.$fid.'" value="'.$f['name'][0].'" />
    <b>频道</b> <input type="text" name="column_name['.$fid.']" value="'.$f['name'][0].'" style="width:150px;" /> ';
  if ($fid !== 'homepage') {
    $atsite = str_split($f['name'][3]);
    $text[$fid] .= '<div class="'.($f['name'][3]!=0?'red_err':'gray_err').'"> <input type="checkbox" class="checkbox" name="column_atside['.$fid.']" value="1" onclick="runClassSide(this, \''.$fid.'\')"'.($atsite[0]!=0 ? ' checked="checked"' : '').' />置于边栏（——对齐方式：<input type="radio"  class="radio" name="column_atside_align['.$fid.']" value="1"'.($atsite[1]!=2&&$atsite[1]!=3&&$atsite[1]!=4 ? ' checked="checked"':'').' />'.$tool_area['align_left'].'</label>
<label><input type="radio"  class="radio" name="column_atside_align['.$fid.']" value="2"'.($atsite[1]==2 ? ' checked="checked"':'').' />'.$tool_area['align_center'].'</label>
<label><input type="radio"  class="radio" name="column_atside_align['.$fid.']" value="3"'.($atsite[1]==3 ? ' checked="checked"':'').' />'.$tool_area['align_justify'].'</label>
<label><input type="radio"  class="radio" name="column_atside_align['.$fid.']" value="4"'.($atsite[1]==4 ? ' checked="checked"':'').' />'.$tool_area['align_right'].'</label>
    ——打开方式：<label><input type="radio"  class="radio" name="column_atside_type['.$fid.']" value="2"'.($atsite[0]!=1 ? ' checked="checked"':'').' />'.$tool_area['open_new'].'</label>[<a href="login.php" target="_blank" title="注意：别在意进入什么页面，这只是示例" onmouseover="sSD(this,event);">示例</a>]
<label><input type="radio"  class="radio" name="column_atside_type['.$fid.']" value="1"'.($atsite[0]==1 ? ' checked="checked"':'').' />'.$tool_area['open_in'].'</label>[<a href="login_current.php" onclick="addSubmitSafe(1);$(\'addCFrame\').style.display=\'block\';" target="addCFrame" title="注意：别在意进入什么页面，这只是示例" onmouseover="sSD(this,event);">示例</a>] ）</div>';
  }
  $text[$fid] .= '
<table width="100%" border="0" cellspacing="1" cellpadding="0" class="n_nav">
  <tr>
    <td width="100" align="center">频道下属栏目<br />（可换行）</td>
    <td width="50" align="center">首页<br />展示</td>
    <td width="200" align="center">该栏目在首页推荐展示网址数量</td>
    <td width="180" align="center">风格修饰<br />（背景着色）</td>
    <td width="120" align="center">子页面网址排列模式<br />（<a href="?get=style#httpType" target="_blank">说明</a>）</td>
    <td align="center">操作</td>
  </tr>
</table>

    <div id="class_'.$fid.'" class="newcolumn">';
  $opti .= '<optgroup label="'.$f['name'][0].'">';

  unset($web['area'][$fid]['name']);



/*
$web['area']['mingz']['name'] = array('0频道名', 1拼音, 2详展数量（新版被取消）, 3置于边栏（模式1|2）);
$web['area']['mingz']['1'] =    array('0栏目名', 1拼音, 2着色背景,               3列表模式, 4首页展示否（如展示，网址数量（-1不展示/-2按分页|0所有|1-n行））);
*/

  $step_indexclass_n = 0;
  foreach ((array)$web['area'][$fid] as $cid => $c) {
    $step_indexclass_n++;
    
    $text[$fid] .= '<div id="class_'.$fid.'_'.$cid.'" class="newclass" title="'.$cid.'">
	  <input type="hidden" name="class['.$fid.']" title="'.$cid.'" />';

    if ($c[4] != -1 || $step_indexclass_n<=$indexclass_n) {
      $class_http_num = !empty($f['name'][3]) ? 'none' : '';
      $class_index_is = '<span class="block_span orangeword" title="该频道被设置在首页主体展示" onmouseover="sSD(this,event);"><input onclick="addClassHttpNum(this,\''.$fid.'_'.$cid.'\');" type="checkbox" class="checkbox" name="class_index_show['.$fid.']['.$cid.']" id="class_index_show_'.$fid.'_'.$cid.'" value="1" checked="checked" /><strong>⇑</strong></span>';
    } else {
      $class_http_num = 'none';
      $class_index_is = '<span class="block_span grayword"><input onclick="addClassHttpNum(this,\''.$fid.'_'.$cid.'\');" type="checkbox" class="checkbox" name="class_index_show['.$fid.']['.$cid.']" id="class_index_show_'.$fid.'_'.$cid.'" value="1" /><strong>⇑</strong></span>';
    }

    $text[$fid] .= '
<span class="block_span" style="width:100px;"><textarea rows="2" class="column_name" name="class_name['.$fid.']['.$cid.']">'.($c[0]).'</textarea></span>

<span class="block_span" style="width:50px;">'.$class_index_is.'</span>

<span class="block_span" style="width:200px;">
  <span name="class_http_num_'.$fid.'[]" id="class_http_num_'.$fid.'_'.$cid.'" style="display:'.$class_http_num.';">
    <input type="radio" class="radio" id="class_http_num'.$fid.'_'.$cid.'" name="class_http_num['.$fid.']['.$cid.']" value="1"'.($c[4]!=0&&$c[4]!=-2?' checked="checked"':'').' />自动截取展示<input type="text" name="class_http_num_['.$fid.']['.$cid.']" style="width:20px; height:20px; padding:0;" value="'.(is_numeric($c[4]) && $c[4]>0?(int)$c[4]:1).'" title="限填正整数" onmouseover="sSD(this,event);" onfocus="$(\'class_http_num'.$fid.'_'.$cid.'\').checked=true;" onblur="isDigit(this,\''.(is_numeric($c[4]) && $c[4]>0 ? (int)$c[4] : 1).'\', 0);" />行<br />
    <input type="radio" class="radio" name="class_http_num['.$fid.']['.$cid.']" value="-2"'.($c[4]==-2?' checked="checked"':'').' />按分页数(如分)否则
    <input type="radio" class="radio" name="class_http_num['.$fid.']['.$cid.']" value="0"'.($c[4]==0?' checked="checked"':'').' />展示所有
  </span>
</span>

<span class="block_span" style="width:180px;">
  <label class="block_span bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="0"'.(empty($c[2]) ? ' checked="checked"':'').' /><br />
无</label><label title="白" class="block_span qd10 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="10"'.((isset($c[2]) && $c[2] == 10) ? ' checked="checked"':'').' /></label><label class="block_span qd1 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="1"'.((isset($c[2]) && $c[2] == 1) ? ' checked="checked"':'').' /></label><label class="block_span qd2 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="2"'.((isset($c[2]) && $c[2] == 2) ? ' checked="checked"':'').' /></label><label class="block_span qd3 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="3"'.((isset($c[2]) && $c[2] == 3) ? ' checked="checked"':'').' /></label><label class="block_span qd4 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="4"'.((isset($c[2]) && $c[2] == 4) ? ' checked="checked"':'').' /></label><label class="block_span qd5 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="5"'.((isset($c[2]) && $c[2] == 5) ? ' checked="checked"':'').' /></label><label class="block_span qd6 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="6"'.((isset($c[2]) && $c[2] == 6) ? ' checked="checked"':'').' /></label><label class="block_span qd7 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="7"'.((isset($c[2]) && $c[2] == 7) ? ' checked="checked"':'').' /></label><label class="block_span qd8 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="8"'.((isset($c[2]) && $c[2] == 8) ? ' checked="checked"':'').' /></label><label class="block_span qd9 bjcolor"><input type="radio" class="radio" name="class_bj['.$fid.']['.$cid.']" value="9"'.((isset($c[2]) && $c[2] == 9) ? ' checked="checked"':'').' /></label>
</span>

<span class="block_span" style="width:120px;">
  <input type="radio" class="radio" name="class_http_type['.$fid.']['.$cid.']" value="0"'.(($c[3]!=1&&$c[3]!=2)?' checked="checked"':'').' />站名排列<br />
  <input type="radio" class="radio" name="class_http_type['.$fid.']['.$cid.']" value="1"'.(($c[3]==1)?' checked="checked"':'').' />弹窗简介<br />
  <input type="radio" class="radio" name="class_http_type['.$fid.']['.$cid.']" value="2"'.(($c[3]==2)?' checked="checked"':'').' />流布局详细显示
</span>
<a class="caozuo" href="javascript:void(0)" onclick="removeOption(this);return false;" title="删除">╳</a>
<a class="caozuo" href="javascript:void(0);" title="插入" onclick="insertClass(this,\''.$fid.'\');return false;">↖</a>
<a class="caozuo" href="javascript:void(0);" title="上移" onclick="upClass(this,\''.$fid.'\');return false;">↑</a>
<a class="caozuo" href="javascript:void(0);" title="上移" onclick="downClass(this,\''.$fid.'\');return false;">↓</a>

<a class="caozuo" href="webmaster_central.php?get=http&column_id='.$fid.'&class_id='.$cid.'" title="管理此频道下的网址">&gt;</a>
         </div>';
    $opti .= '<option value="'.$fid.'_'.$cid.'">'.$c[0].'</option>';
  }
  $text[$fid] .= '
    </div>
    <div style="height:0px; overflow:hidden;clear:both;"></div>
    <button type="button" onclick="javascript:addClass(\''.$fid.'\');" style="clear:right">为此频道添加栏目</button>
    '.(/*is_numeric($fid)*/$fid !== 'homepage' ? '
    <button type="button" onclick="javascript:removeOption(this);">删除此频道</button>
    <button type="button" onclick="javascript:upColumn(this);" title="上移">↑</button>
    <button type="button" onclick="javascript:downColumn(this);" title="下移">↓</button>' : '').'
  </div>
';
  $opti .= '</optgroup>';
}

?>
<div class="note">提示：
  <ol>
      <li>网址分类数量及名称默认程序都已设置好，建议不要更改；如需更改，只更改名称即可。</li>
    <li>以下信息必须认真填写，尽量不要用特殊符号，如 \ : ; * ? ' &lt; &gt; | ，必免导致错误。</li>
    <li><form id="mainform2" action="?post=area_c" method="post" onsubmit="return frTo()" style="display:inline;">
      批量转移分类网址：
      <select name="class_name_fr" id="class_name_fr" style="width:100px">
        <option value="">请选择</option>
        <?php echo $opti; ?>
      </select>
      &harr;
      <select name="class_name_to" id="class_name_to" style="width:100px">
        <option value="">请选择</option>
        <?php echo $opti; ?>
      </select>
      <input type="checkbox" class="checkbox" name="type" value="1" checked="checked" />
      互换转移 <button type="submit">提交</button>
    </form></li>
  </ol>
</div>
<style>
.lik { border:1px green solid; width:400px; height:18px; overflow:hidden; padding:1px; text-align:center; line-height:normal; background-color:#FFFFFF; }
.lis { display:inline-block !important; display:inline; zoom:1; height:16px; text-align:left; padding:0 2px 0 1px; /*letter-spacing:-1px; white-space:nowrap;*/ overflow:hidden; font-size:10px; border:1px blue solid; }
.align_m { margin-left:10px; margin-right:10px; background-color:#ECECEC; }
.align_m td { background-color:#FFFFDC; padding-left:5px; padding-right:5px; }
</style>
<form id="mainform" action="?post=area" method="post" onsubmit="if($('subt').checked==true){this.target='_blank';}else{this.target='_self';}">
<div class="area_">
  <div class="qiangdiao"><b>首页版面「名站」对齐方式</b>：
<center><table border="0" cellspacing="1" cellpadding="0" align="center" class="align_m">
  <tr>
    <td rowspan="4">自然排列</td>
    <td><label><input type="radio" class="radio" name="mingz_align" value="NULL, LEFT" <?php echo empty($web['mingz_align'][0]) && $web['mingz_align'][1]=='LEFT' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_left']; ?></label></td>
    <td width="404">
<div class="lik" style="text-align:left;"> 
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  </div></td>
  </tr>
  <tr>
    <td><label><input type="radio" class="radio" name="mingz_align" value="NULL, CENTER" <?php echo empty($web['mingz_align'][0]) && $web['mingz_align'][1]=='CENTER' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_center']; ?></label></td>
    <td width="404">
<div class="lik"> 
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  </div></td>
  </tr>
  <tr>
    <td><label><input type="radio" class="radio" name="mingz_align" value="NULL, JUSTIFY" <?php echo empty($web['mingz_align'][0]) && $web['mingz_align'][1]=='JUSTIFY' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_justify']; ?></label><span class="grayword">（2行以上生效）</span></td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="br_line_100"></span></div></td>
  </tr>
  <tr>
    <td><label><input type="radio" class="radio" name="mingz_align" value="NULL, RIGHT" <?php echo empty($web['mingz_align'][0]) && $web['mingz_align'][1]=='RIGHT' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_right']; ?></label></td>
    <td width="404">
<div class="lik" style="text-align:right;"> 
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  </div></td>
  </tr>
  <tr>
    <td rowspan="4">定宽排列</td>
    <td><label><input id="mingz_NUM_LEFT" type="radio" class="radio" name="mingz_align" value="NUM, LEFT" <?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 && $web['mingz_align'][1]=='LEFT' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_left']; ?></label> 定宽<input type="text" name="mingz_align_[LEFT]" style="width:20px; height:20px; padding:0;" value="<?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 ? $web['mingz_align'][0] : '6'; ?>" title="限填4、5、6、7、8" onmouseover="sSD(this,event);" onfocus="$('mingz_NUM_LEFT').checked=true;" onblur="isDigit4_8(this,'<?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 ? $web['mingz_align'][0] : '6'; ?>');" />列</td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis" style="width:65px;">文字</span> 
  <span class="lis" style="width:65px;">文字</span> 
  <span class="lis" style="width:65px;">文字</span> 
  <span class="lis" style="width:65px;">文字</span>
  <span class="lis" style="width:65px;">文字</span>
  <span class="br_line_100"></span></div></td>
  </tr>
  <tr>
    <td><label><input id="mingz_NUM_CENTER" type="radio" class="radio" name="mingz_align" value="NUM, CENTER" <?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 && $web['mingz_align'][1]=='CENTER' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_center']; ?></label> 定宽<input type="text" name="mingz_align_[CENTER]" style="width:20px; height:20px; padding:0;" value="<?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 ? $web['mingz_align'][0] : '6'; ?>" title="限填4、5、6、7、8" onmouseover="sSD(this,event);" onfocus="$('mingz_NUM_CENTER').checked=true;" onblur="isDigit4_8(this,'<?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 ? $web['mingz_align'][0] : '6'; ?>');" />列</td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis" style="width:65px; text-align:center;">文字</span> 
  <span class="lis" style="width:65px; text-align:center;">文字</span> 
  <span class="lis" style="width:65px; text-align:center;">文字</span> 
  <span class="lis" style="width:65px; text-align:center;">文字</span>
  <span class="lis" style="width:65px; text-align:center;">文字</span>
  <span class="br_line_100"></span></div></td>
  </tr>
  <tr>
    <td><label><input id="mingz_NUM_JUSTIFY" type="radio" class="radio" name="mingz_align" value="NUM, JUSTIFY" <?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 && $web['mingz_align'][1]=='JUSTIFY' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_justify']; ?></label> 定宽<input type="text" name="mingz_align_[JUSTIFY]" style="width:20px; height:20px; padding:0;" value="<?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 ? $web['mingz_align'][0] : '6'; ?>" title="限填4、5、6、7、8" onmouseover="sSD(this,event);" onfocus="$('mingz_NUM_JUSTIFY').checked=true;" onblur="isDigit4_8(this,'<?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 ? $web['mingz_align'][0] : '6'; ?>');" />列</td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis" style="width:65px; text-align:justify; text-justify:inter-ideograph; letter-spacing:normal;">文字<span class="br_line_100"></span></span> 
  <span class="lis" style="width:65px; text-align:justify; text-justify:inter-ideograph; letter-spacing:normal;">文字<span class="br_line_100"></span></span> 
  <span class="lis" style="width:65px; text-align:justify; text-justify:inter-ideograph; letter-spacing:normal;">文字<span class="br_line_100"></span></span> 
  <span class="lis" style="width:65px; text-align:justify; text-justify:inter-ideograph; letter-spacing:normal;">文字<span class="br_line_100"></span></span>
  <span class="lis" style="width:65px; text-align:justify; text-justify:inter-ideograph; letter-spacing:normal;">文字<span class="br_line_100"></span></span>
  <span class="br_line_100"></span></div></td>
  </tr>
  <tr>
    <td><label><input id="mingz_NUM_RIGHT" type="radio" class="radio" name="mingz_align" value="NUM, RIGHT" <?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 && $web['mingz_align'][1]=='RIGHT' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_right']; ?></label> 定宽<input type="text" name="mingz_align_[RIGHT]" style="width:20px; height:20px; padding:0;" value="<?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 ? $web['mingz_align'][0] : '6'; ?>" title="限填4、5、6、7、8" onmouseover="sSD(this,event);" onfocus="$('mingz_NUM_RIGHT').checked=true;" onblur="isDigit4_8(this,'<?php echo is_numeric($web['mingz_align'][0]) && $web['mingz_align'][0]>=4 ? $web['mingz_align'][0] : '6'; ?>');" />列</td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis" style="width:65px; text-align:right;">文字</span> 
  <span class="lis" style="width:65px; text-align:right;">文字</span> 
  <span class="lis" style="width:65px; text-align:right;">文字</span> 
  <span class="lis" style="width:65px; text-align:right;">文字</span>
  <span class="lis" style="width:65px; text-align:right;">文字</span>
  <span class="br_line_100"></span></div></td>
  </tr>
</table></center>


</div>
<div id="areahomepage">
<?php echo $text['homepage'] ? $text['homepage'] : '<button type="button" onclick="addColumn(\'homepage\');this.style.display=\'none\';"  class="send2 send3"><b>添加频道[首页功能]</b></button>'; ?>
</div>

</div>


<div style="padding:10px; border:1px #99FF33 solid; margin-bottom:10px;">
<div class="qiangdiao"><b>分类区域「酷站」对齐方式：</b>
<center><table border="0" cellspacing="1" cellpadding="0" align="center" class="align_m">
  <tr>
    <td rowspan="4" title="自然排列不限类别数量，每行排满为止，如想多显示分类，请将分类名缩短" onmouseover="sSD(this,event);">自然排列</td>
    <td><label><input type="radio" class="radio" name="kuz_align" value="NULL, LEFT" <?php echo empty($web['kuz_align'][0]) && $web['kuz_align'][1]=='LEFT' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_left']; ?></label></td>
    <td width="404">
<div class="lik" style="text-align:left;">
  <span class="lis" style="width:40px; border:none; float:left; margin:0;">音乐</span>
  <span class="lis" style="width:40px; border:none; float:right; margin:0; text-align:right;">更多&raquo;</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
        </div></td>
  </tr>
  <tr>
    <td><label><input type="radio" class="radio" name="kuz_align" value="NULL, CENTER" <?php echo empty($web['kuz_align'][0]) && $web['kuz_align'][1]=='CENTER' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_center']; ?></label></td>
    <td width="404">
<div class="lik">
  <span class="lis" style="width:40px; border:none; float:left; margin:0;">音乐</span>
  <span class="lis" style="width:40px; border:none; float:right; margin:0; text-align:right;">更多&raquo;</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
        </div></td>
  </tr>
  <tr>
    <td><label><input type="radio" class="radio" name="kuz_align" value="NULL, JUSTIFY" <?php echo empty($web['kuz_align'][0]) && $web['kuz_align'][1]=='JUSTIFY' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_justify']; ?></label><span class="grayword">（2行以上生效）</span></td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis" style="width:40px; border:none; float:left; margin:0;">音乐</span>
  <span class="lis" style="width:40px; border:none; float:right; margin:0; text-align:right;">更多&raquo;</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="br_line_100"></span>        </div></td>
  </tr>
  <tr>
    <td><label><input type="radio" class="radio" name="kuz_align" value="NULL, RIGHT" <?php echo empty($web['kuz_align'][0]) && $web['kuz_align'][1]=='RIGHT' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_right']; ?></label></td>
    <td width="404">
<div class="lik" style="text-align:right;">
  <span class="lis" style="width:40px; border:none; float:left; margin:0;">音乐</span>
  <span class="lis" style="width:40px; border:none; float:right; margin:0; text-align:right;">更多&raquo;</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="lis">文字文字</span>
  <span class="lis">文</span>
  <span class="lis">文字</span>
  <span class="br_line_100"></span>        </div></td>
  </tr>
  <tr>
    <td rowspan="4">定宽排列</td>
    <td><label><input id="kuz_NUM_LEFT" type="radio" class="radio" name="kuz_align" value="NUM, LEFT" <?php echo is_numeric($web['kuz_align'][0]) && $web['kuz_align'][0]>=4 && $web['kuz_align'][1]=='LEFT' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_left']; ?></label> 定宽<input type="text" name="kuz_align_[LEFT]" style="width:20px; height:20px; padding:0;" value="<?php echo is_numeric($web['kuz_align'][0]) && $web['kuz_align'][0]>=4 ? $web['kuz_align'][0] : '6'; ?>" title="限填4、5、6、7、8" onmouseover="sSD(this,event);" onfocus="$('kuz_NUM_LEFT').checked=true;" onblur="isDigit4_8(this,'<?php echo is_numeric($web['mingz_align'][0]) && $web['kuz_align'][0]>=4 ? $web['kuz_align'][0] : '6'; ?>');" />列</td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis" style="width:40px; border:none; float:left; margin:0;">音乐</span>
  <span class="lis" style="width:40px; border:none; float:right; margin:0; text-align:right;">更多&raquo;</span>
  <span class="lis" style="width:50px;">文字</span>
  <span class="lis" style="width:50px;">文字</span>
  <span class="lis" style="width:50px;">文字</span>
  <span class="lis" style="width:50px;">文字</span>
  <span class="lis" style="width:50px;">文字</span>
  <span class="br_line_100"></span>        </div></td>
  </tr>
  <tr>
    <td><label><input id="kuz_NUM_CENTER" type="radio" class="radio" name="kuz_align" value="NUM, CENTER" <?php echo is_numeric($web['kuz_align'][0]) && $web['kuz_align'][0]>=4 && $web['kuz_align'][1]=='CENTER' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_center']; ?></label> 定宽<input type="text" name="kuz_align_[CENTER]" style="width:20px; height:20px; padding:0;" value="<?php echo is_numeric($web['kuz_align'][0]) && $web['kuz_align'][0]>=4 ? $web['kuz_align'][0] : '6'; ?>" title="限填4、5、6、7、8" onmouseover="sSD(this,event);" onfocus="$('kuz_NUM_CENTER').checked=true;" onblur="isDigit4_8(this,'<?php echo is_numeric($web['mingz_align'][0]) && $web['kuz_align'][0]>=4 ? $web['kuz_align'][0] : '6'; ?>');" />列</td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis" style="width:40px; border:none; float:left; margin:0;">音乐</span>
  <span class="lis" style="width:40px; border:none; float:right; margin:0; text-align:right;">更多&raquo;</span>
  <span class="lis" style="width:50px; text-align:center;">文字</span>
  <span class="lis" style="width:50px; text-align:center;">文字</span>
  <span class="lis" style="width:50px; text-align:center;">文字</span>
  <span class="lis" style="width:50px; text-align:center;">文字</span>
  <span class="lis" style="width:50px; text-align:center;">文字</span>
  <span class="br_line_100"></span>        </div></td>
  </tr>
  <tr>
    <td><label><input id="kuz_NUM_JUSTIFY" type="radio" class="radio" name="kuz_align" value="NUM, JUSTIFY" <?php echo is_numeric($web['kuz_align'][0]) && $web['kuz_align'][0]>=4 && $web['kuz_align'][1]=='JUSTIFY' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_justify']; ?></label> 定宽<input type="text" name="kuz_align_[JUSTIFY]" style="width:20px; height:20px; padding:0;" value="<?php echo is_numeric($web['kuz_align'][0]) && $web['kuz_align'][0]>=4 ? $web['kuz_align'][0] : '6'; ?>" title="限填4、5、6、7、8" onmouseover="sSD(this,event);" onfocus="$('kuz_NUM_JUSTIFY').checked=true;" onblur="isDigit4_8(this,'<?php echo is_numeric($web['mingz_align'][0]) && $web['kuz_align'][0]>=4 ? $web['kuz_align'][0] : '6'; ?>');" />列</td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis" style="width:40px; border:none; float:left; margin:0;">音乐</span>
  <span class="lis" style="width:40px; border:none; float:right; margin:0; text-align:right;">更多&raquo;</span>
  <span class="lis" style="width:50px; text-align:justify; text-justify:inter-ideograph;">文字<span class="br_line_100"></span></span>
  <span class="lis" style="width:50px; text-align:justify; text-justify:inter-ideograph;">文字<span class="br_line_100"></span></span>
  <span class="lis" style="width:50px; text-align:justify; text-justify:inter-ideograph;">文字<span class="br_line_100"></span></span>
  <span class="lis" style="width:50px; text-align:justify; text-justify:inter-ideograph;">文字<span class="br_line_100"></span></span>
  <span class="lis" style="width:50px; text-align:justify; text-justify:inter-ideograph;">文字<span class="br_line_100"></span></span>
  <span class="br_line_100"></span>        </div></td>
  </tr>
  <tr>
    <td><label><input id="kuz_NUM_RIGHT" type="radio" class="radio" name="kuz_align" value="NUM, RIGHT" <?php echo is_numeric($web['kuz_align'][0]) && $web['kuz_align'][0]>=4 && $web['kuz_align'][1]=='RIGHT' ? ' checked="checked"' : ''; ?> /><?php echo $tool_area['align_right']; ?></label> 定宽<input type="text" name="kuz_align_[RIGHT]" style="width:20px; height:20px; padding:0;" value="<?php echo is_numeric($web['kuz_align'][0]) && $web['kuz_align'][0]>=4 ? $web['kuz_align'][0] : '6'; ?>" title="限填4、5、6、7、8" onmouseover="sSD(this,event);" onfocus="$('kuz_NUM_RIGHT').checked=true;" onblur="isDigit4_8(this,'<?php echo is_numeric($web['mingz_align'][0]) && $web['kuz_align'][0]>=4 ? $web['kuz_align'][0] : '6'; ?>');" />列</td>
    <td width="404">
<div class="lik" style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">
  <span class="lis" style="width:40px; border:none; float:left; margin:0;">音乐</span>
  <span class="lis" style="width:40px; border:none; float:right; margin:0; text-align:right;">更多&raquo;</span>
  <span class="lis" style="width:50px; text-align:right;">文字</span>
  <span class="lis" style="width:50px; text-align:right;">文字</span>
  <span class="lis" style="width:50px; text-align:right;">文字</span>
  <span class="lis" style="width:50px; text-align:right;">文字</span>
  <span class="lis" style="width:50px; text-align:right;">文字</span>
  <span class="br_line_100"></span>        </div></td>
  </tr>
</table></center>
</div>      
<div id="area">
<?php
unset($text['homepage']);
echo count($text) > 0 ? @implode('', $text) : '<div style="color:#FF6600">您还未设置频道！请先添加频道</div>';
unset($web, $text);
?>
      </div>
      <br />
      <button type="button" onclick="addColumn('');" class="send3">添加频道</button> <a href="webmaster_central.php?get=http">管理频道、栏目及分类下的网址请点此&gt;&gt;</a>
	  </div>
  <div class="red_err">特别提示：提交前请确定set目录具备写权限，因为要将配置结果写入writable/set/set_area.php文件，否则虽提示成功，但实际仍配置失败。</div>
      <button type="submit" onclick="javascript:return confirm('确定提交吗？！');" class="send2">提交设置</button> <input type="checkbox" class="checkbox" id="subt" checked="checked" />在弹出的新页面提交，避免检查出填写错误而导致数据丧失，白写了</br />如果发现没有被改动，那十有八九是缓存在作怪，请刷新页面或清除浏览器缓存再观察
    </form>


