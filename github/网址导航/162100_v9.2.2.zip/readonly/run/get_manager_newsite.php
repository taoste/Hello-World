<?php require 'authentication_manager.php'; ?>
<?php
@ require 'writable/set/set_area.php';
$text = '';

$file = @file('writable/__temp__/newsite_list.txt');
$n = count($file);
if (is_array($file) && $n > 0) {
  foreach ($file as $key => $line) {
    $row = @explode('^', $line);
	$text .= '
    <tr>
    <td width="12"><input name="id[]" id="id[]" type="checkbox" class="checkbox" value="'.$key.'" /></td>
    <td><input type="hidden" id="siteurl['.$key.']" value="'.$row[0].'" /><a href="'.$row[0].'" target="_blank">'.$row[0].'</a><br />
<a href="?post=pr_alexa&siteurl='.urlencode($row[0]).'" target="lastFrame" style="font-family:宋体;font-size:12px;background-color:#EFEFEF;color:#FF9900;" id="site_'.urlencode($row[0]).'" onclick="this.innerHTML=\'检测中…\';">Alexa排名、百度收录检测</a></td>
    <td width="120"><input type="text" style="width:110px" id="sitename['.$key.']" value="'.$row[1].'" /></td>
    <td width="80"><input type="hidden" style="width:20px" id="siteclass['.$key.']" value="'.$row[2].'" /><input type="hidden" id="sitetitle['.$key.']" value="'.gettitle($row[3]).'" />'.getclass($row[2]).'&gt;'.gettitle_($row[3]).'</td>
    <td width="150"><input type="hidden" id="email['.$key.']" value="'.$row[4].'" />'.$row[4].'</td>
    <td width="80"><input type="hidden" id="date['.$key.']" value="'.trim($row[5]).'" />'.$row[5].'</td>
    </tr>';
    unset($row);
  }
}

function gettitle($v) {
  list($class_title, $class_title_mark) = @explode('_', $v);
  if ($class_title_mark && is_numeric($class_title_mark)) {
    return $v;
  } else {
    return urlencode($v);
  }
}
function gettitle_($v) {
  list($class_title, $class_title_mark) = @explode('_', $v);
  if ($class_title_mark && is_numeric($class_title_mark)) {
    return urldecode($class_title);
  } else {
    return $class_title;
  }
}


function getclass($v) {
  global $web;
  list($column_id, $class_id) = @explode('_', $v);
  return ''.$web['area'][$column_id]['name'][0].'&gt;<a href="class.php?column_id='.$column_id.'&class_id='.$class_id.'" target="_blank">'.$web['area'][$column_id][$class_id][0].'</a>';
}
?>


<!--h5 class="list_title"><a class="list_title_in">网站收录审核</a></h5-->
<div class="note">注：该功能显示在首页边栏为“新录网站”。</div>
<div class="note"><button type="button" class="send3" onclick="window.open('?get=modify&otherfile=<?php echo get_en_url('writable/require/newsite10.txt'); ?>', '_blank');">编辑最新收录前10条（首页，随着审核通过自动显示的）</button></div>

<div class="note"><a href="void(0)" onClick="javascript:allChoose('id[]',1,1);return false;">全选</a>- <a href="void(0)" onClick="javascript:allChoose('id[]',1,0);return false;">反选</a>- <a href="void(0)" onClick="javascript:allChoose('id[]',0,0);return false;">不选</a> 
</div>

<iframe id="lastFrame" name="lastFrame" style="display:none;"></iframe>
  <table width="100%" border="0" cellpadding="0" cellspacing="1" id="ad_table">
    <tr>
      <th width="12">&nbsp;</th>
      <th>网址（<?php echo $n; ?>条记录）</th>
      <th width="80">站名</th>
      <th width="120">类别</th>
      <th width="150">站长邮箱</th>
      <th width="80">提交日期</th>
    </tr>
    <?php echo !empty($text) ? $text : '
    <tr>
      <td width="12">&nbsp;</td>
      <td>暂无数据！</td>
      <td width="120">&nbsp;</td>
      <td width="80">&nbsp;</td>
      <td width="150">&nbsp;</td>
      <td width="80">&nbsp;</td>
    </tr>'; ?>
  </table>
<script language="javascript" type="text/javascript">

function allHttps(){
  addSubmitSafe();
  var a = document.getElementsByName('id[]');
  var n = '';
  var id = siteurl = sitename = siteclass = sitetitle = email = date = '';  
  for (var i = 0; i < a.length; i++) {
    if (a[i].checked == true) {
	  n = a[i].value;
	  id += n+"\n";
	  siteurl += $("siteurl["+n+"]").value+"\n";
	  sitename += $("sitename["+n+"]").value+"\n";
	  siteclass += $("siteclass["+n+"]").value+"\n";
	  sitetitle += $("sitetitle["+n+"]").value+"\n";
	  email += $("email["+n+"]").value+"\n";
	  date += $("date["+n+"]").value+"\n";
	}
  }
  if (n == '') {
    alert('数据为空或尚未点选！');
    delSubmitSafe();
	return false;
  }
  $("id_").value = trim(id);
  $("siteurl_").value = trim(siteurl);
  $("sitename_").value = trim(sitename);
  $("siteclass_").value = trim(siteclass);
  $("sitetitle_").value = trim(sitetitle);
  $("email_").value = trim(email);
  $("date_").value = trim(date);
  return true;
}

function trim(text){
  return text.replace(/^\s+|\s+$/g, '');
}


</script>
<form id="mainform" action="?post=newsite" method="post" onsubmit="return allHttps();">
  <input name="limit" type="hidden" />
  <textarea name="id_" id="id_" style="display:none;"></textarea>
  <textarea name="siteurl_" id="siteurl_" style="display:none;"></textarea>
  <textarea name="sitename_" id="sitename_" style="display:none;"></textarea>
  <textarea name="siteclass_" id="siteclass_" style="display:none;"></textarea>
  <textarea name="sitetitle_" id="sitetitle_" style="display:none;"></textarea>
  <textarea name="email_" id="email_" style="display:none;"></textarea>
  <textarea name="date_" id="date_" style="display:none;"></textarea>
<div class="note" style="margin-top:10px;"><a href="void(0)" onClick="javascript:allChoose('id[]',1,1);return false;">全选</a>- <a href="void(0)" onClick="javascript:allChoose('id[]',1,0);return false;">反选</a>- <a href="void(0)" onClick="javascript:allChoose('id[]',0,0);return false;">不选</a> 
  <button name="act" type="submit" onclick="this.form.limit.value='del';">删除记录</button> |
  <button name="act2" type="submit" class="send2" onclick="this.form.limit.value='pass';">通过</button> <input type="checkbox" class="checkbox" name="mailto" value="1" checked="checked" />
  审批通过群发邮件通知（注：若发邮件，一次性点选不要太多）
</div>
</form>
  
