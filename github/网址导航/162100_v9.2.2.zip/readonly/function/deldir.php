<?php

//删除目录
function deldir($dir, $keep_root=false) {
  if (empty($dir) || !file_exists($dir)) {
    return;
  }
  $n = 0;
  if (is_file($dir)) {
    @unlink($dir);
    $n++;
    return true;
  }
  if ($fp = @opendir($dir)) {
    while (false !== ($file = @readdir($fp))) {
      if ($file != '.' && $file != '..') {
        if (is_dir($dir.'/'.$file)) {
          deldir($dir.'/'.$file);
        } else {
          @unlink($dir.'/'.$file);
          $n++;
        }
      }
    }
    if (readdir($fp) == false) {
      @closedir($fp);
      if ($keep_root == false) {
        @rmdir($dir);
      }
      return $n;
    }
  }
}

?>