<?php
function ip() {
  $ip_long = array(
    array('607649792', '608174079'), // 36.56.0.0-36.63.255.255
    array('1038614528', '1039007743'), // 61.232.0.0-61.237.255.255
    array('1783627776', '1784676351'), // 106.80.0.0-106.95.255.255
    array('2035023872', '2035154943'), // 121.76.0.0-121.77.255.255
    array('2078801920', '2079064063'), // 123.232.0.0-123.235.255.255
    array('-1950089216', '-1948778497'), // 139.196.0.0-139.215.255.255
    array('-1425539072', '-1425014785'), // 171.8.0.0-171.15.255.255
    array('-1236271104', '-1235419137'), // 182.80.0.0-182.92.255.255
    array('-770113536', '-768606209'), // 210.25.0.0-210.47.255.255
    array('-569376768', '-564133889'), // 222.16.0.0-222.95.255.255
  );
  $rand_key = mt_rand(0, 9);
  return $ip = long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
}
/*
function ip() {
  $ip1 = round(rand(600000, 2550000) / 10000);
  $ip2 = round(rand(600000, 2550000) / 10000);
  $ip3 = round(rand(600000, 2550000) / 10000);
  $ip4 = round(rand(600000, 2550000) / 10000);
  return ''.$ip1.'.'.$ip2.''.$ip3.'.'.$ip4.'';
}
*/


if (!function_exists('read_file')) {
  function read_file($url) {
  $r = '';
  if (preg_match('/^https?\:\/\//i', $url)) {
    $ip = ip();
    $timeout = 10;                                           //设置一个超时时间，单位为秒
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);           //设置超时   
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_URL, $url);                   //设置访问的url地址   
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);        //返回结果
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);        //跟踪301 
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-FORWARDED-FOR:'.$ip.'', 'CLIENT-IP:'.$ip.''));
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11");    //用户访问代理 User-Agent   
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);       //禁止 cURL 验证对等证书
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSLVERSION, FALSE);
    curl_setopt($ch, CURLOPT_REFERER, $url);               //设置 referer 
    $r = curl_exec($ch);
    curl_close($ch);
    if(!$r){
      $ctx = stream_context_create(array('http' => array('timeout' => $timeout)));
      $r=file_get_contents($url, 0, $ctx);
    }
  } else {
    //if (file_exists($url)) {
      $r=file_get_contents($url);
    //}
  }
  return $r;
  }
}
?>