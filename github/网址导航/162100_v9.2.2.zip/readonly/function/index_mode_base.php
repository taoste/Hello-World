<?php
$web['font_format'] = array(
  //中文字节1/3宽，英文字节宽，空格宽
  12 => array(4,     7,  4),
  13 => array(4.333, 7,  4),
  14 => array(4.667, 8,  5),
  15 => array(5,     9,  5),
  16 => array(5.333, 10, 5),
  17 => array(5.667, 10, 5),
  18 => array(6,     11, 5),
);

function cut($v, $n, $p) {
  $v == (int)$v;
  if ($v == -1) return;
  $http_cut = $n;
  $line_cut = 1;
  if ($v == 0) {
    $http_cut = $n;
    $line_cut = 10000000;
  } elseif ($v == -2) {
    $http_cut = is_numeric($p) && $p <= $n ? $p : $n;
    $line_cut = 10000000;
  } else {
    $http_cut = $n;
    $line_cut = $v;
  }
  return array($http_cut, $line_cut);
}

function get_mingz_FLOW($http, $column_id, $class_id, $class_page) {
  global $web;
  $text = '';
  $http_step = $line_step = 0;
  $margin900 = 0;
  if ($http = trim($http)) {
    //$http_arr = @explode("\n", $http);
    $http_arr = @mb_split("[\n\r]+", $http);
    $n = count($http_arr);
    $stop = cut($web['area'][$column_id][$class_id][4], $n, $class_page);
    if ($n > 0) {
      $one_width = 0;
      $text .= '
      <ul>';
      foreach ($http_arr as $e) {
        $h = @explode("|", trim($e));
        $li_o = 10 + strlenth($h[1].$h[5]) + 10 + $web['font_format'][14][2];
        $one_width += $li_o;
        if ($one_width > 760 - 22) {
          $line_step += 1;
          $one_width = $li_o;
          $GLOBALS['margin_900_mm'] = getMax($margin900, 'mm');
          $margin900 = 0;
        }
        if ($line_step >= $stop[1]) {
          //$text .= $GLOBALS['line_br_mingz'];
          break;
        }
        $http_step += 1;
        $margin900 += 1;
        /*$text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' title="'.html_back($h[4]).'" onmouseover="sSD(this,event);"' : '').' onclick="addM(this)">'.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').'</li> ';*/
        $text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' onmouseover="sSD_(this,event);"><!--'.html_back($h[4]).'-->' : ' onclick="addM(this)">').''.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').'</li>';
        if ($http_step >= $stop[0]) {
          //$text .= $GLOBALS['line_br_mingz'];
          break;
        }
      }
      $text .= '
      </ul>';
    } else {
      $text .= '<ul><li class="grayword">没有数据导入！请管理员在后台/分类网址管理/首页版面「'.$web['area'][$column_id][$class_id][0].'」添加内容</li></ul>';
    }
  }
  return $text;
}

function get_mingz_COLUMN($http, $column_id, $class_id, $class_page, $align_ = '') {
  global $web;
  $text = '';
  $http_step = $line_step = 0;
  if ($http = trim($http)) {
    //$http_arr = @explode("\n", $http);
    $http_arr = @mb_split("[\n\r]+", $http);
    $n = count($http_arr);
    $stop = cut($web['area'][$column_id][$class_id][4], $n, $class_page);
    if ($n > 0) {
      $one_width = 0;
      $text .= '
      <ul>';
      foreach ($http_arr as $e) {
        $h = @explode("|", trim($e));
        $one_width += 1;
        if ($one_width > $web['mingz_align'][0]) {
          $line_step += 1;
          $one_width = 1;
        }
        if ($line_step >= $stop[1]) {
          $text .= $GLOBALS['line_br_mingz'];
          break;
        }
        $http_step += 1;
        /*$text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' title="'.html_back($h[4]).'" onmouseover="sSD(this,event);"' : '').' onclick="addM(this)">'.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').'</li> ';*/
        $text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' onmouseover="sSD_(this,event);"><!--'.html_back($h[4]).'-->' : ' onclick="addM(this)">').''.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').''.$align_.'</li>';
        if ($http_step >= $stop[0]) {
          $in = $http_step % $web['mingz_align'][0];
          if ($in !== 0) {
            $text .= str_repeat(' <li>&nbsp;</li> ', $web['mingz_align'][0] - $in);
          }
          unset($in);
          $text .= $GLOBALS['line_br_mingz'];
          break;
        }
      }
      $text .= '
      </ul>';
    } else {
      $text .= '<ul><li class="grayword">没有数据导入！请管理员在后台/分类网址管理/首页版面「'.$web['area'][$column_id][$class_id][0].'」添加内容</li></ul>';
    }
  }
  return $text;
}

function get_mingz_FLOW_($http, $column_id, $class_id, $class_page) {
  global $web;
  $text = '';
  $http_step = $line_step = 0;
  $margin900 = 0;
  if ($http = trim($http)) {
    //$http_arr = @explode("\n", $http);
    $http_arr = @mb_split("[\n\r]+", $http);
    $n = count($http_arr);
    $stop = cut($web['area'][$column_id][$class_id][4], $n, $class_page);
    if ($n > 0) {
      $one_width = 0;
      $text .= '
      <ul style="text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/">';
      foreach ($http_arr as $e) {
        $h = @explode("|", trim($e));
        $li_o = 10 + strlenth($h[1].$h[5], 12) + 10 + $web['font_format'][12][2];
        $one_width += $li_o;
        if ($one_width > 760 - 22 - (10 + strlenth($web['area'][$column_id][$class_id][0], 13) + 10)) {
          $line_step += 1;
          $one_width = $li_o;
          $GLOBALS['margin_900_mz'] = getMax($margin900, 'mz');
          $margin900 = 0;
        }
        if ($line_step >= $stop[1]) {
          //$text .= $GLOBALS['line_br_mingz'];
          break;
        }
        $http_step += 1;
        $margin900 +=1;
        /*$text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' title="'.html_back($h[4]).'" onmouseover="sSD(this,event);"' : '').' onclick="addM(this)">'.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').'</li> ';*/
        $text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' onmouseover="sSD_(this,event);"><!--'.html_back($h[4]).'-->' : ' onclick="addM(this)">').''.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').'</li>';
        if ($http_step >= $stop[0]) {
          //$text .= $GLOBALS['line_br_mingz'];
          break;
        }
      }
      $text .= '
      </ul>';
    } else {
      $text .= '<ul><li class="grayword">没有数据导入！请管理员在后台/分类网址管理/首页版面「'.$web['area'][$column_id][$class_id][0].'」添加内容</li></ul>';
    }
  }
  return $text;
}
function getMax($v, $t) {
  $GLOBALS['margin_900_'.$t.''] = $v > $GLOBALS['margin_900_'.$t.''] ? $v : $GLOBALS['margin_900_'.$t.''];
  return $GLOBALS['margin_900_'.$t.''];
}
function get_kuz_FLOW($http, $column_id, $class_id, $class_page) {
  global $web;
  $http_step = $line_step = 0;
  $margin900 = 0;
  if ($http = trim($http)) {
    //$http_arr = @explode("\n", $http);
    $http_arr = @mb_split("[\n\r]+", $http);
    $n = count($http_arr);
    $stop = cut($web['area'][$column_id][$class_id][4], $n, $class_page);
    if ($n > 0) {
      $one_width = 0;
      $text .= '
      <ul id="'.$web['area'][$column_id]['name'][1].'_'.$web['area'][$column_id][$class_id][1].'">';
      foreach ($http_arr as $e) {
        $h = @explode("|", trim($e));
        $li_o = 10 + strlenth($h[1].$h[5]) + 10 + $web['font_format'][14][2];
        $one_width += $li_o;
        if ($one_width > 760 - 22 - (10 + strlenth($web['area'][$column_id][$class_id][0]) + 20 + 20 + strlenth('更多»', 12) + 10)) {
          $line_step += 1;
          $one_width = $li_o;
/*
          $text___ .= $web['area'][$column_id][$class_id][0].' 第'.$line_step.'行: '.$GLOBALS['margin_900_kz'];
          $text___ .= '<br />';
          $GLOBALS['margin_900_kz'] = 0;
*/
          $GLOBALS['margin_900_kz'] = getMax($margin900, 'kz');
          $margin900 = 0;
        }
        if ($line_step >= $stop[1]) {
          $text .= $GLOBALS['line_br_kuz'];
          break;
        }
        $http_step += 1;
        $margin900 +=1;
        /*$text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' title="'.html_back($h[4]).'" onmouseover="sSD(this,event);"' : '').' onclick="addM(this)">'.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').'</li> ';*/
        $text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' onmouseover="sSD_(this,event);"><!--'.html_back($h[4]).'-->' : ' onclick="addM(this)">').''.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').'</li>';
        if ($http_step >= $stop[0]) {
          $text .= $GLOBALS['line_br_kuz'];
          break;
        }
      }
      $text .= '
      </ul>';
    } else {
      $text .= '<ul><li class="grayword">没有数据导入！请管理员在后台/分类网址管理/首页版面「'.$web['area'][$column_id][$class_id][0].'」添加内容</li></ul>';
    }
  }
  return $text;
}

function get_kuz_COLUMN($http, $column_id, $class_id, $class_page, $align__ = '') {
  global $web;
  $http_step = $line_step = 0;
  if ($http = trim($http)) {
    //$http_arr = @explode("\n", $http);
    $http_arr = @mb_split("[\n\r]+", $http);
    $n = count($http_arr);
    $stop = cut($web['area'][$column_id][$class_id][4], $n, $class_page);
    if ($n > 0) {
      $one_width = 0;
      $li_o = 10 + strlenth($web['area'][$column_id][$class_id][0]) + 20 + 20 + strlenth('更多»', 12) + 10;
      //$li_w = floor((760-22-$li_o) / $web['kuz_align'][0]) - $web['font_format'][14][2];
      $li_w = floor((760-22-$li_o-$web['kuz_align'][0]*20) / $web['kuz_align'][0]) - $web['font_format'][14][2];
      $id_o = $web['area'][$column_id]['name'][1].'_'.$web['area'][$column_id][$class_id][1];
      $text .= '
<style>
#'.$id_o.' li { width:'.$li_w.'px !important; }
#'.$id_o.' li img { max-width:'.$li_w.'px; }
</style>
<script type="text/javascript">
  var liW_'.$id_o.' = parseInt((rightWidth-22-'.$li_o.'-'.($web['kuz_align'][0]*20).') / '.$web['kuz_align'][0].') - '.$web['font_format'][14][2].';
  document.write(\'<style>\
#'.$id_o.' li { width:\'+liW_'.$id_o.'+\'px !important; }\
#'.$id_o.' li img { max-width:\'+liW_'.$id_o.'+\'px; }\
</style>\');
</script>
';
      $text .= '
      <ul id="'.$id_o.'">';
      unset($li_o, $li_w, $id_o);

      foreach ($http_arr as $e) {
        $h = @explode("|", trim($e));
        $one_width += 1;
        if ($one_width > $web['kuz_align'][0]) {
          $line_step += 1;
          $one_width = 1;
        }
        if ($line_step >= $stop[1]) {
          $text .= $GLOBALS['line_br_kuz'];
          break;
        }
        $http_step += 1;
        /*$text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' title="'.html_back($h[4]).'" onmouseover="sSD(this,event);"' : '').' onclick="addM(this)">'.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').'</li> ';*/
        $text .= '
        <li><a href="'.($web['link_type_i'] == 1 ? ($h[3] == 'js' ? $h[0] : 'export.php?url='.urlencode($h[0])) : ($h[3] == 'js' ? 'export.php?url='.urlencode($h[0]) : $h[0])).'"'.($h[2] != '' ? ' class="'.$h[2].'"' : '').''.($h[4] != '' && $web['d_type'] != 1 ? ' onmouseover="sSD_(this,event);"><!--'.html_back($h[4]).'-->' : ' onclick="addM(this)">').''.$h[1].'</a>'.(!empty($h[5]) ? $h[5] : '').''.$align__.'</li>';
        if ($http_step >= $stop[0]) {
          $in = $http_step % $web['kuz_align'][0];
          if ($in !== 0) {
            $text .= str_repeat(' <li>&nbsp;</li> ', $web['kuz_align'][0] - $in);
          }
          unset($in);
          $text .= $GLOBALS['line_br_kuz'];
          break;
        }
      }
      $text .= '
      </ul>';
    } else {
      $text .= '<ul><li class="grayword">没有数据导入！请管理员在后台/分类网址管理/首页版面「'.$web['area'][$column_id][$class_id][0].'」添加内容</li></ul>';
    }
  }
  return $text;
}

function strlenth_base($str, $fontsize=14) {
  global $web;
  if ($str == '') {
    return 0;
  }
  $len = 0;
  for ($i = 0; $i < strlen($str); $i++) {
    $len += ord(substr($str, $i, 1)) > 127 ? $web['font_format'][$fontsize][0] : $web['font_format'][$fontsize][1]; //14/3=5.333
  }
  return $len;
}

function get_classname_width($str, $fontsize=14) {
  $arr = @explode('
', $str);
  $max_width = 0;
  if (count($arr) > 0) {
    $max_width = strlenth_base($arr[0], $fontsize);
    unset($arr[0]);
    if (count($arr) > 0) {
      foreach ($arr as $v) {
        $max_width_temp = strlenth_base($v, $fontsize);
        if ($max_width < $max_width_temp) {
          $max_width = $max_width_temp;
        }
      }
    }
  }
  return $max_width;
}

function strlenth($str, $fontsize=14) {
  $len = $w = 0;
/*
  preg_match_all('/<img ([^>]+)>/i', $str, $m);
  if (is_array($m[1]) && count($m[1]) > 0) {
    foreach ($m[1] as $im) {
      if (preg_match('/width[^\d]+(\d+)/i', $im, $mm)) {
        $w += $mm[1];
      } else {
        if(preg_match('/src\s*=\s*[\"\']?([^\"\'\s\<\>]+)/i', $im, $mm)) {
          if (file_exists($mm[1]) && $img_info = getimagesize($mm[1])) {
            $w += $img_info[0];
          }
        }
      }
      unset($mm, $img_info);
    }
    unset($m);
  }
*/
  $str = preg_replace('/<script.+<\/script>/isU', '', $str);
  $str = preg_replace('/<style.+<\/style>/isU', '', $str);
  $str = preg_replace('/<\!--.+-->/isU', '', $str);
  $str = str_replace('&amp;', '&', $str);
  $str = str_replace('&quot;', '"', $str);
  $str = str_replace('&#039;', '\'', $str);
  $str = str_replace('&lt;', '<', $str);
  $str = str_replace('&gt;', '>', $str);
  $str = str_replace('&#124;', '|', $str);
  $str = preg_replace('/( |\&nbsp\;)+/', ' ', $str);
  $str = preg_replace('/<br\s*[^>]*>/i', '
', $str);
  $str = strip_tags($str);
  if ($str == '') {
    return 0;
  }
  return get_classname_width($str, $fontsize) + $w;
}

if (!function_exists('get_en_url')) {
  function get_en_url($d) {
    return urlencode(base64_encode($d));
  }
}

if (!function_exists('html_back')) {
  function html_back($str){
    //$str = preg_replace_callback('/<[^>]+>/', function($matches){return htmlspecialchars($matches[0]);}, $str);
    $str = preg_replace_callback('/<[^>]+>/', 'run_filter', $str);
    return $str;
  }
  function run_filter($matches) {
    return htmlspecialchars($matches[0]);
  }
}

if (!function_exists('get_link')) {
  function get_link($url) {
    global $web;
    return $web['link_type_i'] == 1 ? 'export.php?url='.urlencode($url) : $url;
  }
}

$text = $text_ = $text_side = $left_column = '';

$GLOBALS['line_br_mingz'] = $GLOBALS['line_br_kuz'] = $align_ = $align__ = $text900 = '';
$GLOBALS['margin_900_mm'] = $GLOBALS['margin_900_mz'] = $GLOBALS['margin_900_kz'] = 0;

//名站对齐
$web['mingz_align'][1] = strtoupper($web['mingz_align'][1]);
if (empty($web['mingz_align'][0])) { //自然排列
  $function_mingz = 'get_mingz_FLOW';
  switch ($web['mingz_align'][1]) {
    case 'CENTER':
      $text .= '
<style>
.mingz { text-align:center; }
</style>';
    break;
    case 'JUSTIFY':
      $GLOBALS['line_br_mingz'] = ' <li class="br_line_100"></li> ';
      $text .= '
<style>
.mingz { text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/ white-space:normal; letter-spacing:normal; }
</style>';           
    break;
    case 'RIGHT':
      $text .= '
<style>
.mingz { text-align:right; }
</style>';
    break;
    default:
      $text .= '
<style>
.mingz { text-align:left; }
</style>';
  }
  $text .= '
<script type="text/javascript">
if (rightWidth == 900) {
document.write(\'<style>#collection li, .qiangdiao li, .mingz li { padding-left:15px; padding-right:15px; }</style>\');
}
</script>
';
} else { //定宽排列
  //<li></li><li></li>紧连状态不能有空格时，有空格时宽度-6
  //前述风格中已定义 .mingz { padding:10px 0; }
  //.mingz_align li { width:'.(floor((760-2-20) / abs($web['mingz_align'][0]))).'px; }

  $mingz_align = ' mingz_align';
  $function_mingz = 'get_mingz_COLUMN';
  switch ($web['mingz_align'][1]) {
    case 'CENTER':
      $GLOBALS['line_br_mingz'] = ' <li class="br_line_100"></li> ';
      $li_w = floor((760-2-$web['mingz_align'][0]*20) / $web['mingz_align'][0]) - $web['font_format'][14][2];
      $text .= '
<style>
.mingz { padding-left:0; padding-right:0; }
.mingz_align li { text-align:center; }
.mingz_align li { width:'.$li_w.'px; }
.mingz_align li img { max-width:'.$li_w.'px; }
</style>';
      unset($li_w);
      $text .= '
<script type="text/javascript">
var liW_mingz = parseInt((rightWidth-2-'.($web['mingz_align'][0]*20).') / '.$web['mingz_align'][0].') - '.$web['font_format'][14][2].';
document.write(\'<style>\
.mingz_align li { width:\'+liW_mingz+\'px !important;}\
.mingz_align li img { max-width:\'+liW_mingz+\'px; }\
</style>\');
</script>';
    break;
    case 'JUSTIFY':
      $GLOBALS['line_br_mingz'] = ' <li class="br_line_100"></li> ';
      $align_ = ' <span class="br_line_100"></span> ';
      $li_w = floor((760-22-$web['mingz_align'][0]*20) / $web['mingz_align'][0]) - $web['font_format'][14][2];
      $text .= '
<style>
.mingz { }
.mingz_align li { text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/ white-space:normal; letter-spacing:normal; }
.mingz_align li { width:'.$li_w.'px; }
.mingz_align li img { max-width:'.$li_w.'px; }
</style>';
      unset($li_w);
      $text .= '
<script type="text/javascript">
var liW_mingz = parseInt((rightWidth-22-'.($web['mingz_align'][0]*20).') / '.$web['mingz_align'][0].') - '.$web['font_format'][14][2].';
document.write(\'<style>\
.mingz_align li { width:\'+liW_mingz+\'px !important;}\
.mingz_align li img { max-width:\'+liW_mingz+\'px; }\
</style>\');
</script>';
    break;
    case 'RIGHT':
      $GLOBALS['line_br_mingz'] = ' <li class="br_line_100"></li> ';
      $li_w = floor((760-22-$web['mingz_align'][0]*20) / $web['mingz_align'][0]) - $web['font_format'][14][2];
      $text .= '
<style>
.mingz { padding-left:5px; padding-right:15px; }
.mingz_align li { text-align:right; }
.mingz_align li { width:'.$li_w.'px; }
.mingz_align li img { max-width:'.$li_w.'px; }
</style>';
      unset($li_w);
      $text .= '
<script type="text/javascript">
var liW_mingz = parseInt((rightWidth-22-'.($web['mingz_align'][0]*20).') / '.$web['mingz_align'][0].') - '.$web['font_format'][14][2].';
document.write(\'<style>\
.mingz_align li { width:\'+liW_mingz+\'px !important;}\
.mingz_align li img { max-width:\'+liW_mingz+\'px; }\
</style>\');
</script>';
    break;
    default:
      $GLOBALS['line_br_mingz'] = ' <li class="br_line_100"></li> ';
      $li_w = floor((760-22-$web['mingz_align'][0]*20) / $web['mingz_align'][0]) - $web['font_format'][14][2];
      $text .= '
<style>
.mingz { padding-left:15px; padding-right:5px; }
.mingz_align li { text-align:left; }
.mingz_align li { width:'.$li_w.'px; }
.mingz_align li img { max-width:'.$li_w.'px; }
</style>';
      unset($li_w);
      $text .= '
<script type="text/javascript">
var liW_mingz = parseInt((rightWidth-22-'.($web['mingz_align'][0]*20).') / '.$web['mingz_align'][0].') - '.$web['font_format'][14][2].';
document.write(\'<style>\
.mingz_align li { width:\'+liW_mingz+\'px !important;}\
.mingz_align li img { max-width:\'+liW_mingz+\'px; }\
</style>\');
</script>';
  }
  $text .= '
<script type="text/javascript">
if (rightWidth == 900) {
document.write(\'<style>#collection li, .qiangdiao li { padding-left:15px; padding-right:15px; }</style>\');
}
</script>
';

}

//酷站对齐
$web['kuz_align'][1] = strtoupper($web['kuz_align'][1]);
if (empty($web['kuz_align'][0])) {
	$function_kuz = 'get_kuz_FLOW';
  switch ($web['kuz_align'][1]) {
    case 'CENTER':
      $text .= '
<style>
.right .class { text-align:center; }
</style>';
    break;
    case 'JUSTIFY':
      $GLOBALS['line_br_kuz'] = ' <li class="br_line_100"></li> ';
      $text .= '
<style>
.right .class { text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/ white-space:normal; letter-spacing:normal; }
</style>';           
    break;
    case 'RIGHT':
      $text .= '
<style>
.right .class { text-align:right; }
.class_title { padding-right:15px; }
.class_more { padding-left:25px; }
</style>';
    break;
    default:
      $text .= '
<style>
.right .class { text-align:left; }
.class_title { padding-right:25px; }
.class_more { padding-left:15px; }
</style>';
  }

} else {

  $function_kuz = 'get_kuz_COLUMN';
  switch ($web['kuz_align'][1]) {
    case 'CENTER':
      $GLOBALS['line_br_kuz'] = ' <li class="br_line_0"></li> ';
      $text .= '
<style>
.right .class li { text-align:center; }
</style>';
    break;
    case 'JUSTIFY':
      $GLOBALS['line_br_kuz'] = ' <li class="br_line_0"></li> ';
      $align__ = ' <span class="br_line_100"></span> ';
      $text .= '
<style>
.right .class li { text-align:justify; text-justify:inter-ideograph; /*text-align-last:justify;*/ white-space:normal; letter-spacing:normal; }
</style>';
    break;
    case 'RIGHT':
      $GLOBALS['line_br_kuz'] = ' <li class="br_line_0"></li> ';
      $text .= '
<style>
.right .class li { text-align:right; }
.class_title { padding-right:15px; }
.class_more { padding-left:25px; }
</style>';
    break;
    default:
      $GLOBALS['line_br_kuz'] = ' <li class="br_line_0"></li> ';
      $text .= '
<style>
.right .class li { text-align:left; }
.class_title { padding-right:25px; }
.class_more { padding-left:15px; }
</style>';
  }
  $text .= '
<style>
.right .class li a { padding-top:6px; padding-bottom:6px; line-height:normal; white-space:normal; }
</style>';
}


if (!isset($sql['db_err'])) {
  $db = db_conn();
}
if ($sql['db_err'] == '') {

  $column_show = 0;
  $text .= '
<div id="mingz">';
  //获取首页版面频道[名站]等
  if (!empty($web['area']['homepage'])) {
    $web['area']['homepage']['name'][2] = (is_numeric($web['area']['homepage']['name'][2]) && $web['area']['homepage']['name'][2] > 0) ? $web['area']['homepage']['name'][2] : 0;
    foreach ($web['area']['homepage'] as $class_id => $class) {
      if ($class_id === 'name') continue;
      $column_show++;
      //if ($class[4] != -1 || $column_show <= $web['area']['homepage']['name'][2]) {
      if ($class[4] != -1) {
        $result = db_query($db, 'SELECT * FROM `'.$sql['pref'].''.$sql['data']['承载网址数据的表名'].'` WHERE column_id="homepage" AND class_id="'.$class_id.'" AND class_title NOT LIKE "栏目头栏%" AND detail_title="" AND http_name_style<>"" ORDER BY id LIMIT 1'); // AND class_title NOT LIKE "栏目置顶%"
        if ($row = db_fetch($db, $result)) {
          list($class_title, $class_col, $class_page) = @explode("|", $row['class_title']);
          $cp = !empty($row['class_priority']) ? '<div class="priority" id="priority">'.$row['class_priority'].'</div>' : '';
          if (is_numeric($class[2]) && $class[2] > 0) {
            $text .= '
<div class="qiangdiao qd'.$class[2].'">
  '.$cp.'
  <table cellpadding="0" cellspacing="0" border="0" width="100%">
    <tr valign="middle">
      <td> <a class="class_name" href="'.get_class_html('homepage', $class_id).'">'.$class[0].'</a> </td>
      <td width="100%">
        '.get_mingz_FLOW_($row['http_name_style'], 'homepage', $class_id, $class_page).'
      </td>
    </tr>
  </table>
</div>';
          } else {
            $text .= '
<div class="mingz'.$mingz_align.'">
  '.$cp.'
  '.$function_mingz($row['http_name_style'], 'homepage', $class_id, $class_page, $align_).'
</div>';
          }
        } else {
          $text .= '<center class="grayword">没有数据导入！请管理员在后台/分类网址管理/首页版面「'.$class[0].'」添加内容</center>';
        }
        $result = NULL;
        unset($row, $cp);
        unset($class_id, $class);
      }
    }
  }
  //unset($web['area']['homepage']);
  $column_show = $tcolor = 0;

  $text .= '<script> document.write(myCollection); </script>';
  $text .= '
</div>';


  //获取其它频道栏目
  $array_color = array('red', 'orange', 'green', 'blue');
  foreach ((array)$web['area'] as $column_id => $column) {
    if ($column_id === 'homepage') {
      continue;
    }

    //置于边栏的（11/12/13/14，21/22/23/24）
    if ($column['name'][3] != 0) {
      $arr_column_side[$column_id] = $column;
      continue;
    }

    $column['name'][2] = (is_numeric($column['name'][2]) && $column['name'][2] > 0) ? $column['name'][2] : 0;
    $tcolor_key = $array_color[($tcolor + 4) % 4].'word';
    $tcolor ++;
    $c_title = $column['name'][0];
    $left_column .= '<div class="column_title"><a onmouseover="showLeftMenu(this, \''.$column_id.'\')" href="'.get_column_html($column_id).'" class="tcolor '.$tcolor_key.'">'.$column['name'][0].' &#8230;</a></div><div id="left_menu_'.$column_id.'" class="left_menu">'; //////////////////////////////////////////////////////////////////////
    $text_ .= '
  <div class="column"'.($tcolor==1?' style="margin-top:0;"':'').'>';
    $text_ .= '<div class="column_title">';
    $text_temp_ = '';
    foreach ((array)$column as $class_id => $class) {
      if ($class_id === 'name') continue;
      $column_show ++;
      //if ($class[4] != -1 || $column_show <= $column['name'][2]) {
      if ($class[4] != -1) {
        $c_c_name = get_class_html($column_id, $class_id);
        //$text_temp_ .= '<div class="class'.(is_numeric($class[2]) && $class[2] > 0 ? ' qiangdiao qd'.$class[2].'' : ' kuz_align').'">';
        $text_temp_ .= '
<div class="class'.(is_numeric($class[2]) && $class[2] > 0 ? ' qd'.$class[2].'' : ' kuz_align').'">';
        $text_temp_ .= '
  <table cellpadding="0" cellspacing="0" border="0" width="100%">
    <tr valign="middle">';
        $text_temp_ .= '
      <td><a class="class_title '.$tcolor_key.'" href="'.$c_c_name.'">'.$class[0].'</a></td>
      <td width="100%">';
        $result = db_query($db, 'SELECT * FROM `'.$sql['pref'].''.$sql['data']['承载网址数据的表名'].'` WHERE column_id="'.$column_id.'" AND class_id="'.$class_id.'" AND class_title NOT LIKE "栏目头栏%" AND detail_title="" AND http_name_style<>"" ORDER BY id LIMIT 1'); // AND class_title NOT LIKE "栏目置顶%"
        if ($row = db_fetch($db, $result)) {
          list($class_title, $class_col, $class_page) = @explode("|", $row['class_title']);
          $text_temp_ .= $function_kuz($row['http_name_style'], $column_id, $class_id, $class_page, $align_);
        } else {
          $text_temp_ .= '<center class="grayword">没有数据导入！请管理员在后台/分类网址管理/'.$c_title.'「'.$class[0].'」添加内容</center>';
        }
        $result = NULL;
        $text_temp_ .= '
      </td>
      <td><a class="class_more" href="'.$c_c_name.'">更多&raquo;</a></td>
    </tr>
  </table>';
        $text_temp_ .= '
</div>';
        unset($c_c_name);
        unset($row);
        unset($column[$class_id]);
        unset($class_id, $class);
      }
    }
    unset($column['name']);
    $_sy = count($column);
    if ($_sy > 0) {
      $sss = 0;
      $text_ .= '
      <div class="class_title_other">';
      foreach ($column as $class_id => $class) {
        $sss++;
        $text_ .= ' <a href="'.get_class_html($column_id, $class_id).'">'.$class[0].'</a> '.($sss == $_sy ? '' : ' | ').'';
        unset($class_id, $class);
      }
      $text_ .= '
      </div>';
    }
    $text_ .= ' <a href="'.get_column_html($column_id).'" class="tcolor '.$tcolor_key.'">'.$c_title.'</a> <div style="clear:both; height:0px; overflow:hidden;">&nbsp;</div></div>';
    $text_ .= $text_temp_;
    $text_ .= '</div>';
    unset($column_id, $column, $text_temp_, $c_title);
    $left_column .= '</div>'; //////////////////////////////////////////////////////////////////////
    $column_show = 0;
  }
} else {
  die($sql['db_err']);
}

db_close($db);

if (count($arr_column_side) > 0) :
  foreach ($arr_column_side as $column_id => $column) {
    $atsite = str_split($column['name'][3]);
    switch ($atsite[1]) {
      case 2:
      $atsite_ = ' style="text-align:center;"';
      break;
      case 3:
      $atsite_ = ' style="text-align:justify; text-justify:inter-ideograph;"';
      break;
      case 4:
      $atsite_ = ' style="text-align:right;"';
      break;
      default:
      $atsite_ = '';
    }
    $text_side .= '
    <div id="column_'.$column['name'][1].'" class="column"><div class="column_title"><a href="'.get_column_html($column_id).'">'.$web['area'][$column_id]['name'][0].'</a></div>
      <ul class="class class_side"'.$atsite_.'>';
    foreach ((array)$column as $class_id => $class) {
      if ((string)$class_id !== 'name') {
        $text_side .= '
		<li'.(is_numeric($class[2]) && $class[2] > 0 ? ' class="qd'.$class[2].'"' : '').'><a'.($atsite[0]!=2 ? ' href="class_current.php?column_id='.$column_id.'&class_id='.$class_id.'" onclick="addSubmitSafe(1);$(\'addCFrame\').style.display=\'block\';" target="addCFrame"' : ' href="'.get_class_html($column_id, $class_id).'"').'>'.$class[0].'</a></li> ';
      }
      unset($class_id, $class);
    }
    $text_side .= '
      </ul>
    </div>
';
    unset($atsite, $atsite_, $column_id, $column);
  }

endif;

unset($arr_column_side);

if ($GLOBALS['margin_900_mm'] > 0) {
    $text900 .= '
<script>
if (rightWidth == 900) {
  var m_mm = 10 + parseInt((900-760)/'.$GLOBALS['margin_900_mm'].'/2);
  document.write(\'<style> #mingz .mingz li { padding-left:\'+m_mm+\'px !important; padding-right:\'+m_mm+\'px !important; } </style>\');
}
</script>';

}

if ($GLOBALS['margin_900_mz'] > 0) {
    $text900 .= '
<script>
if (rightWidth == 900) {
  var m_mz = 10 + parseInt((900-760)/'.$GLOBALS['margin_900_mz'].'/2);
  document.write(\'<style> #mingz .qiangdiao li { padding-left:\'+m_mz+\'px !important; padding-right:\'+m_mz+\'px !important; } </style>\');
}
</script>';

}

if ($GLOBALS['margin_900_kz'] > 0) {
    $text900 .= '
<script>
if (rightWidth == 900) {
  var m_kz = 10 + parseInt((900-760)/'.$GLOBALS['margin_900_kz'].'/2);
  document.write(\'<style> .right .class li { padding-left:\'+m_kz+\'px !important; padding-right:\'+m_kz+\'px !important; } </style>\');
}
</script>';

}

?>