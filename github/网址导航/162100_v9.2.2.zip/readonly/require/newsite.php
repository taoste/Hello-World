    <div class="column column_side"><div class="column_title"><a href="write_newsite.php" class="send">网站加入</a>新录网站</div>
      <ul class="class" id="newsite">载入中…
      </ul>
    </div>
<iframe src="PseudoXMLHTTP.php?xml_id=newsite&xml_file=<?php echo get_en_url('writable/require/newsite10.txt'); ?>" style="display:none;"></iframe>
