<?php
@ini_set('default_charset', 'utf-8');
@ header("content-type: text/html; charset=utf-8");
@ini_set('display_errors', false);
error_reporting(E_ERROR | E_WARNING | E_PARSE);
@ require_once 'readonly/function/get_root_domain.php';
@ require_once 'readonly/function/read_file.php';

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<style>
body { margin:0; padding:0; background-color:#FFFFFF; text-align:center; color:#333333; font-size:14px; }
h4 { font-size:24px; color:#663399; }
h4, p, h6 { margin:10px auto; padding:0; line-height:normal; }
p, form { margin:0px auto; }
.body { background-color:#EEEEEE; padding:10px; }
.body h6 { font-size:16px; }
.ye {display:inline-block; *display:inline; *zoom:1; vertical-align:middle; font-size:32px; color:#FF9900; cursor:pointer; }
.no {display:inline-block; *display:inline; *zoom:1; vertical-align:middle; font-size:32px; color:#336699; cursor:pointer; }
button::-moz-focus-inner{ margin:0; padding:0 }
input, button { margin:2px auto; padding:2px; outline:none; border:1px #999999 solid; height:40px; font-size:14px; }
.ide_chk_bt { background:#FF9900; color:#FFFFFF; }
.ide_chk_bt_dis { background:#EEEEEE; color:#CCCCCC; }
#close_self {cursor:pointer; color:#999999;}
</style>
<script>
function closeIfr() {
  if(parent && parent!=self){
    document.getElementById('close_self').innerHTML = '[关闭]';
    document.getElementById('close_self').onclick=function(){
      parent.delSubmitSafe();
      parent.document.getElementById('addCFrame').style.display='none';
    }
  }
}
</script>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>升级到商业版</title>
</head>

<body>

<?php
if ($_POST['act'] == 'chk') :
  echo '<style> body { background-color:#EEEEEE; color:#FF6666; line-height:32px; } </style>';
  $ide = preg_replace('/\s+/', '', $_POST['ide']);
  if (!preg_match('/^[a-zA-Z0-9\_]{14,28}$/', $ide)) {
    die('请输入有效格式的授权码！</body></html>');
  }
  if ($rel = read_file('http://www.162100.com/s/ide_check.php?ide='.urlencode($ide).'')) {
    if (strstr($rel, '授权码')) {
      die($rel.'</body></html>');
    } else {
      //die(preg_replace('/^.*<body>|<\/body>.*$/isU', '', strip_tags($rel)).'验证失败！请稍后再试。<a href="javascript:window.history.back();">&lt;&lt;返回</a></body></html>');
      die(strip_tags($rel).'验证失败！请稍后再试。</body></html>');
    }
  } else {
    die('无法获取官方反馈数据，请稍后再试</body></html>');
  }
elseif ($_POST['act'] == 'run') :
  $ide = preg_replace('/\s+/', '', $_POST['ide']);
  if (!preg_match('/^[a-zA-Z0-9\_]{14,28}$/', $ide)) {
    die('请输入有效格式的授权码！</body></html>');
  }
  if ($rel = read_file('http://www.162100.com/s/ide_check.php?ide='.urlencode($ide).'')) {
    if (strstr($rel, '授权码')) {
      if ($rel == '授权码为真') {
        @ require_once 'readonly/function/write_file.php';
        write_file('writable/set/set_ide.php', $ide);
        die('<b>恭喜！激活成功。</b>可随时进行商业版在线升级了。马上<br />
<a href="webmaster_central.php?post=upgrade&r='.time().'" target="_parent">[一键升级商业版]</a> <p id="close_self" onclick="closeIfr()">[关闭]</p></body></html>');
      } else {
        die($rel.'<a href="javascript:window.history.back();">&lt;&lt;返回</a></body></html>');
      }
    } else {
      die(preg_replace('/^.*<body>|<\/body>.*$/isU', '', $rel).'验证失败！请稍后再试。<a href="javascript:window.history.back();">&lt;&lt;返回</a></body></html>');
    }
  } else {
    die('无法获取官方反馈数据，请稍后再试。<a href="javascript:window.history.back();">&lt;&lt;返回</a></body></html>');
  }



else :
?>


<div><h4>当前版本：<?php
$v = '7.9';

$f = @file_get_contents('v.txt');
if ($f && preg_match('/\$v\s*\=\s*\'(.*)\';/iU', $f, $matches)) {
  $v = base64_decode($matches[1]);
}

if (file_exists('addfunds.php')) {
  $v .= '（商业版）';
  $text = '当前已为商业版，更换授权码？';
} else {
  $text = '若启用商业版，请输入授权码提交激活——';
}

echo $v;


?></h4>
<script>
function chkWord(o) {
  var bt = document.getElementById('ide_chk_bt');
  var reg=/^[a-zA-Z0-9\_]{14,28}$/;   /*定义验证表达式*/
  if (reg.test(o.value)) {
    bt.disabled = false;
    bt.className = 'ide_chk_bt';
  } else {
    bt.disabled = true;
    bt.className = 'ide_chk_bt_dis';
  }
}

function getIde(o) {
  //return o.value.replace('/[^a-zA-Z0-9\_]+/g', '');
  return o.value.replace('/\s+/g', '');
}

function run(form, act, target) {
  var v = getIde(form.ide);
  if (!/^[a-zA-Z0-9\_]{14,28}$/.test(v)) {
    alert('请输入有效的授权码！');
    return false;
  }
  form.act.value = act;
  form.target = target;
  return true;
}


</script>
<div class="body">
  <h6><?php echo $text; ?></h6>
  <form action="for_s.php" method="post">
  授权码：<input type="text" name="ide" size="40" onpropertychange="chkWord(this)" oninput="chkWord(this)" onblur="chkWord(this)" />
  <input type="hidden" name="act" value="run" />
  <button type="submit" disabled="disabled" id="ide_chk_bt" class="ide_chk_bt_dis" onclick="return run(this.form, 'chk', 'chkFrame');">检验</button>
  <button type="submit" style="width:80px; background-color:#FFCC00; color:#FFFFFF;" onclick="return run(this.form, 'run', '_self');">提交</button>
  </form>
  <iframe id="chkFrame" name="chkFrame" width="494" height="64" allowtransparency="true" frameborder="0" marginwidth="0" marginheight="0" scrolling="No"></iframe>
</div>
</div>
<p id="close_self"></p>
<?php
endif;
?>
<script>
window.onload=function(){
  closeIfr();
}
</script>

</body>
</html>