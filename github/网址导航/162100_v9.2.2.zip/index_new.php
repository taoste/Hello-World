<?php /* 首页模式[爽洁版]此行勿动！ */

/*
* 程序名称：162100网址导航3号
* 作者：162100.com
* 邮箱：162100.com@163.com
* 网址：http://www.162100.com
* ＱＱ：184830962
* 声明：禁止侵犯版权或程序转发的行为，否则我方将追究法律责任
*/

$self = 'index_new.php';

@ require_once 'writable/set/set.php';
@ require_once 'writable/set/set_sql.php';
if (!isset($web['area'])) {
  @ require 'writable/set/set_area.php';
}
if (!isset($web['html'])) {
  @ require 'writable/set/set_html.php';
}
@ require_once 'readonly/function/index_mode_base.php';

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $web['sitename'], $web['code_author']; ?></title>
<meta name="description" content="<?php echo $web['description']; ?>">
<meta name="keywords" content="<?php echo $web['keywords']; ?>">
<base target="_blank" />
<?php echo $web['slogan']; ?>
<link href="readonly/css/style.css?<?php echo filemtime('readonly/css/style.css'); ?>" rel="stylesheet" type="text/css">
<link href="readonly/css/<?php echo $web['cssfile']; ?>/style.css?<?php echo filemtime('readonly/css/'.$web['cssfile'].'/style.css'); ?>" rel="stylesheet" type="text/css" id="my_style">
<script type="text/javascript" language="javascript">
<!--
var nowVersion='<?php @ include 'writable/require/browse_reload.txt'; ?>';
-->
</script>
<script type="text/javascript" language="javascript" src="writable/js/main.js?<?php echo filemtime('writable/js/main.js'); ?>"></script>
<?php
if (file_exists('writable/js/goiphone.js')) {
  echo '<script type="text/javascript" language="javascript" src="writable/js/goiphone.js"></script>';
}
?>
<script type="text/javascript" language="javascript">
<!--
var IframeOnload = 0;
var iframeScrollW = null;

function confiremFrame() {
	IframeOnload = 1
};

function sendMenuId(o, aid) {
	if (arguments[1]) {
		aid = arguments[1]
	} else {
		aid = ''
	}
	if ($('top_title_is' + aid) != null) {
		$('top_title_is' + aid).id = ''
	}
	try {
		o.id = 'top_title_is' + aid
	} catch (e) {}
};

function chanMenuBack(o) {
	sendMenuId(o);
	$('body1').style.display = 'none';
	$('body').style.display = 'block'
	if ($('search_bottom') != null) { $('search_bottom').style.display = 'block' }
	if ($('extra_bottom') != null) { $('extra_bottom').style.display = 'block' }
    window.scrollTo(0,0);
};

function getScrollWidth() {
	if (iframeScrollW == null) {
		if (IframeOnload == 0) {
			return 17
		}
		iframeScrollW = 17;
		if (iframeW = document.getElementById("confirmFrame").contentWindow.document.body.offsetWidth) {
			iframeScrollW = 1040 - parseInt(iframeW)
		}
	}
	return iframeScrollW
};

function chanMenu(o, w, h, ssV) {
	sendMenuId(o);
    var to = $('top_title_index');
    var old = to;
    var tTop;
    tTop=to.offsetTop;
	while (old = old.offsetParent) {
		tTop += old.offsetTop;
	}
	if ($('search_bottom') != null) { $('search_bottom').style.display = 'none' }
	if ($('extra_bottom') != null) { $('extra_bottom').style.display = 'none' }
	iframeScrollW = getScrollWidth();
	$('body').style.display = 'none';
	$('body1').style.display = 'block';
    $('body1').style.width = w;
    if (w == '100%'){
      $('body1').style.minWidth = '1000px';
    }
	$('bodyFrame').style.width = ($('body1').offsetWidth + iframeScrollW) +'px';
    $('bodyFrame').style.height = h;
	$('ifrSV').value = ssV;

	if (arguments[4]) {
      var bodyH = to.offsetWidth;
      if (bodyH >= 1170) {
        if (o.rel =='') {
          o.rel = o.href;
        }
        o.href = arguments[4];
        $('body1').style.width = arguments[5];
        if (arguments[5] == '100%'){
          $('body1').style.minWidth = '1170px';
        }
        $('bodyFrame').style.width = ($('body1').offsetWidth + iframeScrollW) +'px';
	    $('bodyFrame').style.height = arguments[6];
	    $('ifrSV').value = Math.abs(arguments[7]);
      }else{
        if (o.rel !='') {
          o.href = o.rel;
        }
      }
	}
    window.scrollTo(0,tTop);
};

function showScroll(o) {
	iframeScrollW = getScrollWidth();
	var body1W = $('body1').offsetWidth;
    $('bodyFrame').style.width = (body1W + iframeScrollW) + 'px';
	if ($('ifrSV').value != 1) {
        $('body1').style.overflow = 'visible';
	}
	o.onmouseout = function() {
        $('body1').style.overflow = 'hidden';
	};
};


-->
</script>
</head>
<body>

<?php @ include 'writable/require/notice.txt'; ?>
<?php @ include 'readonly/require/head.php'; ?>
<script type="text/javascript" language="JavaScript">
<!--
$('kw').focus();
function addFocus() {
  $('kw').focus();
  $('body').style.display = 'block';
};
if (document.all) {
  window.attachEvent('onload', addFocus);
} else {
  window.addEventListener('load', addFocus, false);
};
-->
</script>
<script type="text/javascript" language="JavaScript">
<!--
if(document.getElementById('date_time')!=null){document.getElementById('date_time').innerHTML='<a href="detail.php?column_id=1&class_id=15&detail_title=%E4%B8%87%E5%B9%B4%E5%8E%86" title="农历 '+solarDay2()+'" onmouseover="sSD(this,event);">'+YYMMDD()+' '+weekday()+' '+dateBox+'</a>'}
-->
</script>
<iframe id="addPFrame" name="addPFrame" style="display:none"></iframe><div id="site_d"></div>
<?php require 'writable/set/set_menu.php';
$text_menu = '';

if (isset($web['menu'][0]['open']) && !empty($web['menu'][0]['open'])) {
  unset($web['menu'][0]['open']);
  $text_menu = '<style type="text/css">
#top_title_index { display: block;}
</style>';
  $text_menu .= '<div id="top_title_index">
  <div id="top_title"><a href="javascript:void(0)" onclick="chanMenuBack(this);return false;" id="top_title_is"><img src="readonly/images/0_home.gif" />网址导航</a>
';
  foreach ((array)$web['menu'][0] as $k => $v) {
    $text_menu .= '<a href="'.get_link($v[1]).'" onclick="chanMenu(this, \''.(strstr($v[2],'%')?$v[2]:abs($v[2]).'px').'\', \''.(strstr($v[3],'%')?$v[3]:abs($v[3]).'px').'\', '.abs($v[4]).''.(!empty($v[5])&&$v[6]&&$v[7]?', \''.$v[5].'\', \''.(strstr($v[6],'%')?$v[6]:abs($v[6]).'px').'\', \''.(strstr($v[7],'%')?$v[7]:abs($v[7]).'px').'\', '.abs($v[8]).'':'').');" target="bodyFrame">'.(file_exists('writable/images/menu/0_'.$k.'.gif')?'<img src="writable/images/menu/0_'.$k.'.gif" />':'').''.$v[0].'</a>';
    unset($k, $v);
  }
  $text_menu .= '</div>
</div>
<div style="width:0; height:0; overflow:hidden;"><iframe id="confirmFrame" name="confirmFrame" src="about_blank.html" frameborder="0" scrolling="Yes" style="width:1040px; height:1px;"></iframe><input id="ifrSV" name="ifrSV" type="hidden" value="0" /></div>
<div id="body1" style="width:1000px; overflow:hidden; display:none; margin-bottom:10px;">
  <iframe id="bodyFrame" name="bodyFrame" allowtransparency="true" frameborder="0" scrolling="yes" style="width:1017px; margin-left:0;" onmouseover="showScroll(this);"></iframe>
</div>';
} else {
  $text_menu .= '<div id="top_title_index">
  <div id="top_title"><a href="./write_newsite.php" class="top_title_other">网站加入</a><a href="./member.php?get=collection" class="top_title_other">自定义网址</a><a href="./" id="top_title_is">首页</a></div>
</div>';
}
echo $text_menu;
unset($text_menu);

?>

<script type="text/javascript" language="javascript">
<!--
function getBodyW() {
  //return parseInt(document.getElementById('head').offsetWidth)>=1170?900:760;
  return parseInt(getStyle(document.getElementById('head'), 'width'))>=1170?900:760;
}
var rightWidth=getBodyW();
-->
</script>
<?php
if (is_array($GLOBALS['kz_margin']) && count($GLOBALS['kz_margin']) > 0) {
  $li_max = max($GLOBALS['kz_margin']);
  if (is_numeric($li_max) && $li_max > 0) {
    echo '
<script>
if (rightWidth == 900) {
 document.write(\'<style> .right .class li { margin:0 \'+(12+parseInt((900-760)/'.$li_max.'/2))+\'px !important; } </style>\');
}
</script>';
  }
}
?>
<div class="body" id="body">
  <div class="right" id="right">
<?php
echo $text900;
unset($text900);
echo $text;
unset($text);
?>
<?php
if (file_exists('writable/chuchuang/ad_central.txt')) {
  @ include 'writable/chuchuang/ad_central.txt';
}
?>
<?php
echo $text_;
unset($text_);
?>
  </div>
  <div class="left" id="left">
<?php
$open_img = $open_li = 0;
@ include 'writable/extra/inc/set/img.php';
$open_img = $extra['open'];
unset($extra);
@ include 'writable/extra/inc/set/li.php';
$open_li = $extra['open'];
unset($extra);
if ($open_img == 1 || $open_li == 1) {
?>
    <!-- 号外 -->
    <div id="extra" style="margin-bottom:10px;">
    <div id="column_extra" class="column" style="margin-bottom:0;"><div class="column_title" id="extra_title"><a id="more_news" href="http://news.baidu.com/" title="更多新闻">&gt;&gt;</a><a href="http://news.baidu.com/">新闻热点</a></div>
      <div class="class" id="extra_box">
<?php
  if ($open_img == 1) {
?>
        <iframe id="extraFrameImg" name="extraFrameImg" src="writable/extra/s_news_img.php" allowtransparency="true" frameborder="0" scrolling="no" style=""></iframe>
<?php
    unset($open_img);
  }
?>
<?php
  if ($open_li == 1) {
?>
        <div id="extraFrame">
          <iframe id="extraFrameLi" name="extraFrameLi" src="writable/extra/s_news_li.php" allowtransparency="true" frameborder="0" scrolling="Yes" style=""></iframe>
        </div>
<?php
    unset($open_li);
  }
?>
      </div>
    </div>
    </div>
    <!-- /号外 -->
<?php
}
?>
<?php
unset($left_column);
echo $text_side;
unset($text_side);
?>

<?php
if (@file_exists('writable/require/chongzhi.txt')) {
?>
    <div id="column_chongzhi" class="column column_side"><div class="column_title">手机充值</div>
      <div class="class" style="text-align:center;">
      <?php
@ include 'writable/require/chongzhi.txt';

?>
      </div>
    </div>

<?php
}
?>



    <?php @ include 'writable/require/newsite.php'; ?>
    <?php @ include 'writable/require/newinfo.php'; ?>
    <?php
if (file_exists('writable/chuchuang/ad_side.txt')) {
  @ include 'writable/chuchuang/ad_side.txt';
}
?>
  </div>
  <div style="clear:both; height:0px; overflow:hidden;">&nbsp;</div>
</div>
<?php
if (file_exists('writable/js/parallel.js')) {
  echo '<script type="text/javascript" language="javascript" src="writable/js/parallel.js"></script>';
}
?>
<?php
@ include 'writable/extra/inc/set/more.php';
if (isset($extra['open']) && $extra['open'] == 1) {
?>
<div class="body" id="extra_bottom">
<iframe id="extraFrameMore" name="extraFrameMore" src="writable/extra/s_news_more.php" width="100%" height="435" allowtransparency="true" frameborder="0" scrolling="No"></iframe>
</div>
<?php
  unset($extra);
}
?>

<?php
if (file_exists('writable/js/referrer_top.js') || file_exists('writable/require/foot_searchbox.php')) {
?>
<div class="body" id="search_bottom">
  <div class="bottom" style="clear:both;">
    <?php echo file_exists('writable/js/referrer_top.js') ? '<div class="bottom_in"'.(file_exists('writable/require/foot_searchbox.php')?' style="border-bottom:1px #CECECE dotted; margin-bottom:5px;"':'').'><span class="bottom_title">最新点入</span><script> document.write(\'<\'+\'sc\'+\'ript language="javascript" src="writable/js/referrer_top.js?\'+new Date().getTime()+\'" type="text/javascript"></\'+\'sc\'+\'ript>\'); </script></div>' : ''; ?>
    <?php
if (file_exists('writable/require/foot_searchbox.php')) {
  @ include 'writable/require/foot_searchbox.php';
}
    ?>
  </div>
</div>
<?php
}
?>
<?php
if (file_exists('writable/chuchuang/ad_bottom_index.txt')) {
  @ include 'writable/chuchuang/ad_bottom_index.txt';
}
?>
<?php @ include 'writable/require/foot_index.php'; ?>
<?php @ include 'writable/require/statistics.txt'; ?>

<!--bottom-->

</body>
<iframe src="PseudoXMLHTTP.php?xml_id=weather&xml_file=<?php echo get_en_url('readonly/weather/getweather.php'); ?>&char=utf-8" style="display:none;" id="sendWeather"></iframe>
<iframe src="PseudoXMLHTTP.php?xml_id=collection&xml_file=<?php echo get_en_url('readonly/run/post_member_collection_show.php'); ?>" style="display:none;"></iframe>

<script type="text/javascript" language="javascript">
var opensugV = getCookie("searchLenovo");
<?php echo file_exists('writable/js/opensug.js') ? '
var opensug = 1;
if (opensugV) {
  if (parseInt(opensugV.substr(0,1)) == 0) {
    opensug = 0;
  }
}
var opensugUrl = \'writable/js/opensug.js?'.filemtime('writable/js/opensug.js').'\';
' : '
var opensug = 0;
if (opensugV) {
  if (parseInt(opensugV.substr(0,1))==1) {
    opensug = 1;
  }
}
var opensugUrl = \'readonly/js/opensug.js\';
'; ?>
if (opensug == 1) {
  document.write('<scr'+'i'+'pt type="text/javascript" language="javascript" src="'+opensugUrl+'"></scr'+'i'+'pt>');
}
</script>
<script type="text/javascript" language="javascript" src="readonly/js/expires.php"></script>
<?php
if ($web['link_type_i'] == 0) {
  @ include 'writable/chuchuang/ad_juejinlian.txt';
}
?>
</html>
