<?php /* 首页模式[快捷版]此行勿动！ */

/*
* 程序名称：162100网址导航3号
* 作者：162100.com
* 邮箱：162100.com@163.com
* 网址：http://www.162100.com
* ＱＱ：184830962
* 声明：禁止侵犯版权或程序转发的行为，否则我方将追究法律责任
*/

$self = 'index_hiddenmenu.php';

@ require_once 'writable/set/set.php';
@ require_once 'writable/set/set_sql.php';
if (!isset($web['area'])) {
  @ require 'writable/set/set_area.php';
}
if (!isset($web['html'])) {
  @ require 'writable/set/set_html.php';
}
@ require_once 'readonly/function/index_mode_base.php';

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $web['sitename'], $web['code_author']; ?></title>
<meta name="description" content="<?php echo $web['description']; ?>">
<meta name="keywords" content="<?php echo $web['keywords']; ?>">
<base target="_blank" />
<?php echo $web['slogan']; ?>
<link href="readonly/css/style.css?<?php echo filemtime('readonly/css/style.css'); ?>" rel="stylesheet" type="text/css">
<link href="readonly/css/<?php echo $web['cssfile']; ?>/style.css?<?php echo filemtime('readonly/css/'.$web['cssfile'].'/style.css'); ?>" rel="stylesheet" type="text/css" id="my_style">
<style type="text/css">
<!--
.left { overflow:visible; }
.left_in { overflow:hidden; }
.left_menu { display:none; overflow:auto; font-weight:normal; text-align:left; position:absolute; top:-10px; left:209px; padding:10px; z-index:90;filter:progid:DXImageTransform.Microsoft.Alpha(opacity=90); -moz-opacity:0.9; -khtml-opacity:0.9; opacity:0.9; background:#F3FDC3 url(readonly/images/loading2.gif) 50% 50% no-repeat;}
.left_menu a { }
#left_menu_obj { position:relative; margin-left:0; margin-right:0; padding-left:0; padding-right:0;}
.left .column { }
.left #left_menu_obj .column_title { margin:0; padding:0; letter-spacing:10px; }
.left #left_menu_obj .column_title:hover {}
.left #left_menu_obj .column_title a  { margin:0; width:229px; display:block; text-align:center; padding-left:0; padding-right:0; border-top:none; border-bottom:none; }
.left #left_menu_obj .column_title a:hover  { background-color: #F3FDC3;  }
.left #left_menu_obj .column_title .tcolor { border-top:none; max-width:none; }
-->
</style>
<script type="text/javascript" language="javascript">
<!--
var nowVersion='<?php @ include 'writable/require/browse_reload.txt'; ?>';
-->
</script>
<script type="text/javascript" language="javascript" src="writable/js/main.js?<?php echo filemtime('writable/js/main.js'); ?>"></script>
<?php
if (file_exists('writable/js/goiphone.js')) {
  echo '<script type="text/javascript" language="javascript" src="writable/js/goiphone.js"></script>';
}
?>
  </head>
<body>

<?php @ include 'writable/require/notice.txt'; ?>
<?php @ include 'readonly/require/head.php'; ?>
<script type="text/javascript" language="JavaScript">
<!--
$('kw').focus();
function addFocus() {
  $('kw').focus();
  $('body').style.display = 'block';
};
if (document.all) {
  window.attachEvent('onload', addFocus);
} else {
  window.addEventListener('load', addFocus, false);
};
-->
</script>
<script type="text/javascript" language="JavaScript">
<!--
if(document.getElementById('date_time')!=null){document.getElementById('date_time').innerHTML='<a href="detail.php?column_id=1&class_id=15&detail_title=%E4%B8%87%E5%B9%B4%E5%8E%86" title="农历 '+solarDay2()+'" onmouseover="sSD(this,event);">'+YYMMDD()+' '+weekday()+' '+dateBox+'</a>'}
-->
</script>
<iframe id="addPFrame" name="addPFrame" style="display:none"></iframe><div id="site_d"></div>
<div id="top_title_index">
<div id="top_title"><a href="./write_newsite.php" class="top_title_other">网站加入</a><a href="./member.php?get=collection" class="top_title_other">自定义网址</a><a href="./" id="top_title_is">首页</a></div>
</div>
<script type="text/javascript" language="javascript">
<!--
function getBodyW() {
  //return parseInt(document.getElementById('head').offsetWidth)>=1170?900:760;
  return parseInt(getStyle(document.getElementById('head'), 'width'))>=1170?900:760;
}
var rightWidth=getBodyW();
-->
</script>
<?php
if (is_array($GLOBALS['kz_margin']) && count($GLOBALS['kz_margin']) > 0) {
  $li_max = max($GLOBALS['kz_margin']);
  if (is_numeric($li_max) && $li_max > 0) {
    echo '
<script>
if (rightWidth == 900) {
 document.write(\'<style> .right .class li { margin:0 \'+(12+parseInt((900-760)/'.$li_max.'/2))+\'px !important; } </style>\');
}
</script>';
  }
}
?>

<div class="body">
  <div class="right" id="right">
<?php
echo $text900;
unset($text900);
echo $text;
unset($text);
?>
<?php
if (file_exists('writable/chuchuang/ad_central.txt')) {
  @ include 'writable/chuchuang/ad_central.txt';
}
?>
<?php
echo $text_;
unset($text_);
?>
  </div>
  <div class="left" id="left"><div id="left_top">分类目录</div>
    <div class="column" id="left_menu_obj">
<?php
echo
$left_column;
unset($left_column);
?>
    </div>

<?php
echo $text_side;
unset($text_side);
?>

    <div class="left_in">
<?php
if (@file_exists('writable/require/chongzhi.txt')) {
?>
    <div id="column_chongzhi" class="column column_side"><div class="column_title">手机充值</div>
      <div class="class" style="text-align:center;">
      <?php
@ include 'writable/require/chongzhi.txt';

?>
      </div>
    </div>

<?php
}
?>

    <?php @ include 'writable/require/newsite.php'; ?>
    <?php @ include 'writable/require/newinfo.php'; ?>
    <?php
if (file_exists('writable/chuchuang/ad_side.txt')) {
  @ include 'writable/chuchuang/ad_side.txt';
}
?>
    </div>
  </div>
  <div style="clear:both; height:0px; overflow:hidden;">&nbsp;</div>
</div>
<?php
if (file_exists('writable/js/parallel.js')) {
  echo '<script type="text/javascript" language="javascript" src="writable/js/parallel.js"></script>';
}
?>

<?php
if (file_exists('writable/js/referrer_top.js') || file_exists('writable/require/foot_searchbox.php')) {
?>
<div class="body" id="search_bottom">
  <div class="bottom" style="clear:both;">
    <?php echo file_exists('writable/js/referrer_top.js') ? '<div class="bottom_in"'.(file_exists('writable/require/foot_searchbox.php')?' style="border-bottom:1px #CECECE dotted; margin-bottom:5px;"':'').'><span class="bottom_title">最新点入</span><script> document.write(\'<\'+\'sc\'+\'ript language="javascript" src="writable/js/referrer_top.js?\'+new Date().getTime()+\'" type="text/javascript"></\'+\'sc\'+\'ript>\'); </script></div>' : ''; ?>
    <?php
if (file_exists('writable/require/foot_searchbox.php')) {
  @ include 'writable/require/foot_searchbox.php';
}
    ?>
  </div>
</div>
<?php
}
?>
<?php
if (file_exists('writable/chuchuang/ad_bottom_index.txt')) {
  @ include 'writable/chuchuang/ad_bottom_index.txt';
}
?>
<?php @ include 'writable/require/foot_index.php'; ?>
<?php @ include 'writable/require/statistics.txt'; ?>

<!--bottom-->
<?php
//加载天气
//$_GET['from'] = 'index.php';
// include 'readonly/weather/getweather.php';
?>
<script type="text/javascript" language="javascript">
<!--

var cssSet = nowStyle ? nowStyle.toString() : '<?php echo $web['cssfile']; ?>';
var cssCookie = getCookie('myStyle').toString();

var rl = false;

if(getStyle(document.getElementById('left'),'minWidth')=='200px'||getStyle(document.getElementById('left'),'float')=='right'){rl=true}function showLeftMenu(o,id){
var leftMenuObj=$('left_menu_'+id);var lW=760;if(rl==true){var lk=-1;var oldL=lW*-1+20-21;var oldL2=lW*-1-21;o.style.marginLeft='-1px'}else{var lk=1;var oldL=209;var oldL2=229}leftMenuObj.style.left=''+(oldL)+'px';
if(leftMenuObj!=null){leftMenuObj.style.display='block';leftMenuObj.style.width=lW+'px';leftMenuObj.style.minHeight=($('left_menu_obj').offsetHeight)+'px';nTimes=0;JSCTimeOutID=setInterval(function(){nTimes++;leftMenuObj.style.left=''+(oldL+nTimes*lk)+'px';if(nTimes>=20){window.clearInterval(JSCTimeOutID)}},10);$('addPFrame').src='PseudoXMLHTTP.php?xml_id=left_menu_'+id+'&xml_file=<?php echo get_en_url('more.php'); ?>&show_o=index&column_id='+id+''}leftMenuObj.onmouseover=function(){this.style.display='block';this.style.left=''+oldL2+'px';window.clearInterval(JSCTimeOutID)};o.onmouseout=leftMenuObj.onmouseout=function(){leftMenuObj.style.display='none';leftMenuObj.style.left=''+oldL+'px';window.clearInterval(JSCTimeOutID)};}

function blinkOn(){leftMenuObj.style.left=(nTimes)+'px';nTimes++;if(nTimes>=209){window.clearTimeout(JSCTimeOutID)}}
-->
</script>

</body>
<iframe src="PseudoXMLHTTP.php?xml_id=weather&xml_file=<?php echo get_en_url('readonly/weather/getweather.php'); ?>&char=utf-8" style="display:none;" id="sendWeather"></iframe>
<iframe src="PseudoXMLHTTP.php?xml_id=collection&xml_file=<?php echo get_en_url('readonly/run/post_member_collection_show.php'); ?>" style="display:none;"></iframe>

<script type="text/javascript" language="javascript">
var opensugV = getCookie("opensug");
<?php echo file_exists('writable/js/opensug.js') ? '
var opensug = 1;
if (opensugV) {
  if (parseInt(opensugV.substr(0,1)) == 0) {
    opensug = 0;
  }
}
var opensugUrl = \'writable/js/opensug.js?'.filemtime('writable/js/opensug.js').'\';
' : '
var opensug = 0;
if (opensugV) {
  if (parseInt(opensugV.substr(0,1))==1) {
    opensug = 1;
  }
}
var opensugUrl = \'readonly/js/opensug.js\';
'; ?>
if (opensug == 1) {
  document.write('<scr'+'i'+'pt type="text/javascript" language="javascript" src="'+opensugUrl+'"></scr'+'i'+'pt>');
}
</script>
<script type="text/javascript" language="javascript" src="readonly/js/expires.php"></script>
<?php
if ($web['link_type_i'] == 0) {
  @ include 'writable/chuchuang/ad_juejinlian.txt';
}
?>
</html>
