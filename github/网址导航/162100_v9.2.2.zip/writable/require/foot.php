
<!--公用页脚-->
<div id="foot"><!--foot--><a href="about.php">关于本站</a> - <a href="http://info.162100.com/index.s.2-408..1.html">论坛交流</a> - <a href="write_newsite.php">网站提交</a><!--/foot-->
<div id="foot_v"><?php @ require('v.txt'); ?>  &nbsp;&nbsp;Copyright <span class="copy">&copy;</span> <?php echo $web['root']; ?> ,&nbsp;&nbsp;<a href="./" target="_self">返回首页</a> <a href="#" onclick="window.close();return false" target="_self">关闭页面</a>
</div></div>