<?php
$GLOBALS['WEATHER_DATA'] = '../../';
require ($GLOBALS['WEATHER_DATA'].'writable/set/set.php');

$time['now'] = time() + floatval($web['time_pos']) * 3600;
header('Cache-Control: max-age = '.(1589634000-$time['now']).'');
header('Expires: Sat, 16 May 2020 13:00:00 GMT');

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>新闻摘要</title>
<base target="_blank" />
<link href="inc/code/li.css?1516098185" rel="stylesheet" type="text/css">
<script type="text/javascript" language="javascript" src="inc/code/li.js?1516098689"></script>
</head>
<body>

<script type="text/javascript">
var updateStamp='20200516130000';
var newsHotTagName='hotnews';
</script>

<div id="news_li_box">
<ul id="news_li">
<div id="hotnews" alog-group="focustop-hotnews">
<ul><li class="hdline0">
<i class="dot"></i>
<strong>
<a href="http://app.cctv.com/special/cportal/detail/arti/index.html?id=ArtiCiFTrYkddZb9WGE24R2J200515&fromapp=cctvnews&version=804&version=804&allow_comment=1" target="_blank" class="a3" mon="ct=1&a=1&c=top&pn=0">决战决胜——习近平指挥脱贫攻坚进行时</a></strong>
</li>
<li class="hdline1">
<i class="dot"></i>
<strong>
<a href="http://www.xinhuanet.com/politics/leaders/2020-05/14/c_1125986175.htm" target="_blank"  mon="r=1"><b>习近平走秦晋关注脱贫攻坚</b></a>
<i style="font-size: 12px">&nbsp;</i><a href="http://politics.people.com.cn/n1/2020/0515/c1001-31709786.html?from=groupmessage&isappinstalled=0" target="_blank"  mon="r=1"><b>"去嘎查路"是幸福小康路</b></a>
</strong>
</li>
<li class="hdline2">
<i class="dot"></i>
<strong>
<a href="http://politics.people.com.cn/n1/2020/0515/c1001-31710769.html" target="_blank" class="a3" mon="ct=1&a=1&c=top&pn=1">中央政治局常委会召开会议 点了五个地方</a><i style="font-size: 12px">&nbsp;</i><a href="http://news.cctv.com/2020/05/15/ARTIqT2Mcp4ibeU4L2Wbyeoq200515.shtml" target="_blank" class="a3" mon="ct=1&a=1&c=top&pn=1">央视快评</a>
</strong>
</li>
<li class="hdline3">
<i class="dot"></i>
<strong>
<a href="http://news.cyol.com/xwzt/node_68134.htm" target="_blank"  mon="r=1">代表委员履职故事</a>
<i style="font-size: 12px">&nbsp;</i><a href="https://wap.peopleapp.com/article/5497596/5417422" target="_blank"  mon="r=1">刘入源代表:用心用力帮扶乡亲 </a>
</strong>
</li>
<li class="hdline4">
<i class="dot"></i>
<strong>
<a href="http://www.xinhuanet.com/politics/ldzt/qcpbll/index.htm" target="_blank" class="a3" mon="ct=1&a=1&c=top&pn=2">专题:青春蓬勃力量|"90后"在抗疫一线"蜕变成长"</a></strong>
</li>
<li class="hdline5">
<i class="dot"></i>
<strong>
<a href="http://www.qstheory.cn/dukan/qs/2020-05/15/c_1125987745.htm" target="_blank"  mon="r=1">《求是》编辑部：凝聚起实现民族复兴的强大力量 </a>
</strong>
</li>
</ul>
</div>
</ul>
<div id="newsMore" style="height:13px; border-top:1px #D8D8D8 dashed; background:url(inc/img/li/fm.gif) 50% 50% no-repeat; overflow:hidden;"></div>
</div>

<code id="follow" style="display:none">
<!--
<li class="bold-item">

<a href="http://baijiahao.baidu.com/s?id=1666756707512683245" target="_blank">中央:针对多地现无症状感染者情况要加强筛查</a>&nbsp;<a href="https://voice.baidu.com/act/newpneumonia/newpneumonia#tab0" target="_blank">动态</a></li>
<li>
<a href="http://app.cctv.com/special/cportal/detail/arti/index.html?id=Artiadxvfn3bDnwoT6Oeudcc200514&fromapp=cctvnews&version=804&allow_comment=1&allow_comment=1" target="_blank">与科学对决、与政要互怼 特朗普政府令美国疫情乱上加乱 </a></li>
<li>
<a href="http://app.cctv.com/special/cportal/detail/arti/index.html?id=Artir4ditjmIqoSrEfcVp5dK200514&fromapp=cctvnews&version=804&allow_comment=1&allow_comment=1" target="_blank">外交部:美政客不应一味“甩锅”推责</a>&nbsp;<a href="http://app.cctv.com/special/cportal/detail/arti/index.html?id=ArtiHOixvJa11DXSmZ336tO9200514&fromapp=cctvnews&version=804&allow_comment=1&allow_comment=1" target="_blank">美记者:美国全搞砸了</a></li>
<li>
<a href="http://app.cctv.com/special/cportal/detail/arti/index.html?id=Arti5UrJOXEwa3TDJJWVGaKQ200514&fromapp=cctvnews&version=804&allow_comment=1&allow_comment=1" target="_blank">外交部:敦促美方停止对中国诬蔑</a>&nbsp;<a href="http://app.cctv.com/special/cportal/detail/arti/index.html?id=Artil4dxyfeoJByjOcagqERu200514&fromapp=cctvnews&version=804&allow_comment=1&allow_comment=1" target="_blank">制止针对中方滥诉行为</a></li>
<li>
<a href="https://wap.peopleapp.com/article/5497597/5417423" target="_blank">宋丰强委员——心系黄河 改善生态 </a></li>
<li>
<a href="https://wap.gmdaily.cn/article/p58c3312b6eae43769ad742db4998c42b" target="_blank">全国人大代表王娟：应构建铁路安全运行的外部网络 </a></li>


<li class="bold-item">

<a href="https://3w.huanqiu.com/a/c36dc8/3yG2HS7Hwpl?agt=8" target="_blank">美媒：特朗普政府计划恢复对世卫组织部分资助 </a></li>
<li>
<a href="http://news.cyol.com/app/2020-05/15/content_18614467.htm" target="_blank">汶川地震12年后 震区孩子的铁路抗疫 </a></li>
<li>
<a href="https://3w.huanqiu.com/a/de583b/9CaKrnKqYH7?agt=8" target="_blank">国家卫健委驳斥抹黑中国谣言：美官员言论纯属断章取义</a></li>
<li>
<a href="https://3w.huanqiu.com/a/de583b/9CaKrnKqYH5?agt=8" target="_blank">国防部：中方要求法方立即撤销有关对台军售项目 </a></li>
<li>
<a href="https://3w.huanqiu.com/a/de583b/9CaKrnKqYH8?agt=8" target="_blank">中国经济运行逐步向常态化复苏 美媒：将为世界提供经验 </a></li>
<li>
<a href="https://3w.huanqiu.com/a/24d596/3yG0fnmW9rv?agt=8" target="_blank">美众议院通过3万亿美元经济纾困法案 遭共和党抵制</a></li>


<li class="bold-item">

<a href="https://3w.huanqiu.com/a/21eee3/3yFv2QkOM6B?agt=8" target="_blank">全球累计确诊病例逾452万 美国多州面临财务困境</a></li>
<li>
<a href="https://3w.huanqiu.com/a/c36dc8/3yG0rWtjAmN?agt=8" target="_blank">美疾控中心预测:本月底前美国将有超过10万人死于新冠肺炎</a></li>
<li>
<a href="https://3w.huanqiu.com/a/24d596/3yFyLRwCxAs?agt=8" target="_blank">泰国公共卫生部：将中国和韩国撤出危险性传染病地区名单 </a></li>
<li>
<a href="https://3w.huanqiu.com/a/d2d030/3yFxFI1S0V0?agt=8" target="_blank">因一名士兵确诊新冠肺炎 印度一军队大楼因疫情部分封闭 </a></li>
<li>
<a href="https://3w.huanqiu.com/a/a4d1ef/3yFw2ZEz7EV?agt=8" target="_blank">履新不足一月 巴西卫生部长宣布辞职 </a></li>
<li>
<a href="https://3w.huanqiu.com/a/24d596/3yFvXe15bPn?agt=8" target="_blank">秘鲁一水果零售市场近90%被检测者确诊新冠肺炎 </a></li>


<li class="bold-item">

<a href="https://3w.huanqiu.com/a/2928e7/3yG0OhXkY1V?agt=8" target="_blank">卫健委:昨日新增确诊8例 其中境外输入6例本土2例</a></li>
<li>
<a href="https://3w.huanqiu.com/a/105a86/3yFzRkHFp1b?agt=8" target="_blank">吉林市通报2例本土病例轨迹:1人在医院工作 多次乘公交车</a></li>
<li>
<a href="https://3w.huanqiu.com/a/f6f6b5/3yFywOkuLvE?agt=8" target="_blank">海南最新疫情通报：昨日新增确诊病例1例，报告自三亚市</a></li>
<li>
<a href="https://3w.huanqiu.com/a/c39122/3yG0Ni9Z0tx?agt=8" target="_blank">哈尔滨已排查吉林市、舒兰市来哈383人，全部已隔离检测 </a></li>
<li>
<a href="https://3w.huanqiu.com/a/077c70/3yG4NEfZzpi?agt=8" target="_blank">广州公布1例新增无症状感染者：21岁留学生，自美入境 </a></li>
<li>
<a href="https://3w.huanqiu.com/a/67c0c8/3yG47ZA1KWm?agt=8" target="_blank">沙尘午后开始影响北京 短时可达重度以上污染</a></li>


<li class="bold-item">

<a href="https://3w.huanqiu.com/a/fcd50e/3yG2BJePC1S?agt=8" target="_blank">舒兰实施严格管控:封闭居民楼1103栋 封村1205个</a></li>
<li>
<a href="https://3w.huanqiu.com/a/50454a/3yG34tbIXe3?agt=8" target="_blank">壶口落水家庭最后一位遇难者找到，雷霆队员正在打捞 </a></li>
<li>
<a href="https://3w.huanqiu.com/a/0c789f/3yFxuqSadyi?agt=8" target="_blank">丰巢收费背后:多家同行早已收取超时费用 甚至存柜即收费 </a></li>
<li>
<a href="http://m.top.cnr.cn/bdxw/20200516/t20200516_525092000.html" target="_blank">全国人均工资单出炉，6大行业年薪超10万 你被平均了吗？ </a></li>
<li>
<a href="http://m.top.cnr.cn/bdxw/20200516/t20200516_525091993.html" target="_blank">亲妈开玩具车载孩子上路还闯红灯：我不晓得 </a></li>
<li>
<a href="http://m.top.cnr.cn/bdxw/20200516/t20200516_525091992.html" target="_blank">现金被烧，可以拿去银行兑换吗？什么标准？有案例了 </a></li>
-->
</code>

<script type="text/javascript" language="javascript" src="inc/js_update.php?type=li"></script>
</body>
</html>