<?php
$extra = array (
  'name' => '新闻集锦',
  'url' => 'http://www.huanqiu.com',
  'time_step' => 60,
  'img_d' => 'img/more',
  'pic_copy' => 0,
  'open' => 0,
);
?>