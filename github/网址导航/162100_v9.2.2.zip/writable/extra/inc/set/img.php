<?php
$extra = array (
  'name' => '新闻图片',
  'url' => 'http://news.baidu.com',
  'w' => '228',
  'time_step' => 60,
  'img_d' => 'img/img',
  'open' => 1,
);
?>