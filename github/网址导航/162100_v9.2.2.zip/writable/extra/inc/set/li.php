<?php
$extra = array (
  'name' => '新闻摘要',
  'url' => 'http://news.baidu.com',
  'time_step' => 60,
  'hot' => 'hotnews',
  'img_d' => 'img/li',
  'open' => 1,
);
?>