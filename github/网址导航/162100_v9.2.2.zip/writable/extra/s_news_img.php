<?php
$GLOBALS['WEATHER_DATA'] = '../../';
require ($GLOBALS['WEATHER_DATA'].'writable/set/set.php');

$time['now'] = time() + floatval($web['time_pos']) * 3600;
header('Cache-Control: max-age = '.(1589634000-$time['now']).'');
header('Expires: Sat, 16 May 2020 13:00:00 GMT');

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>新闻图片</title>
<base target="_blank" />
<link href="inc/code/img.css?1588395583" rel="stylesheet" type="text/css">
<script type="text/javascript" language="javascript" src="inc/code/img.js?1588395050"></script>
</head>
<body>

<!--[if IE]>
<style>
#news_imgs_box #news_imgs a .txt {
filter:progid:DXImageTransform.Microsoft.Alpha(opacity=70); -moz-opacity:0.7; -khtml-opacity:0.7; opacity:0.7;
background-color:#333333;
}
</style>
<![endif]-->
<script type="text/javascript">
var updateStamp='20200516130000';
</script>

<div id="news_imgs_box">
<div id="news_imgs">
<a href="http://photo.cctv.com/2020/05/16/PHOApmHam9KzcRaQ8QSbxjIG200516.shtml?spm=C35449.P80754075394.S41437.3#pB9aZXl6zLrm200516_1" target="_blank" id="e_img_0"><img src="inc/img/img/0.jpeg?refresh=20200516130000" /><div class="txt">山东威海：初夏时节 虞美人绽放争妍斗艳</div></a>
</div>
<a href="javascript:void(0);" onclick="stepP();return false;" id="n_prev">&lt;</a><a href="javascript:void(0);" onclick="stepN();return false;" id="n_next">&gt;</a>
<input type="hidden" id="keyC" value="0" /><input type="hidden" id="nowMode" value="N" /></div>

<code id="follow" style="display:none">
<!--<a href="https://3w.huanqiu.com/a/3458fa/3yFwMldtxtU?agt=8" target="_blank" id="e_img_1"><img src="inc/img/img/1.jpeg?refresh=20200516130000" /><div class="txt">河南温县：麦田美如画</div></a><a href="http://picture.youth.cn/qtdb/202005/t20200516_12330339.htm" target="_blank" id="e_img_2"><img src="inc/img/img/2.jpeg?refresh=20200516130000" /><div class="txt">重庆高校大学生有序返校</div></a><a href="https://3w.huanqiu.com/a/3458fa/3yFwNxeoM41?agt=8" target="_blank" id="e_img_3"><img src="inc/img/img/3.jpeg?refresh=20200516130000" /><div class="txt">天空之眼瞰广西南丹</div></a><a href="https://3w.huanqiu.com/a/34f321/3yFTZfJ6776?agt=8" target="_blank" id="e_img_4"><img src="inc/img/img/4.jpeg?refresh=20200516130000" /><div class="txt">莫斯科现彩虹与落日余晖相伴景观 美不胜收</div></a><a href="http://www.chinanews.com/tp/hd2011/2020/05-16/940219.shtml" target="_blank" id="e_img_5"><img src="inc/img/img/5.jpeg?refresh=20200516130000" /><div class="txt">罕见“真假美猴王” 猕猴生下双胞胎</div></a><a href="http://www.xinhuanet.com/photo/2020-05/16/c_1125992034.htm" target="_blank" id="e_img_6"><img src="inc/img/img/6.jpeg?refresh=20200516130000" /><div class="txt">意大利新冠治愈病例增至120205例</div></a><a href="http://www.chinanews.com/tp/hd2011/2020/05-16/940212.shtml#nextpage" target="_blank" id="e_img_7"><img src="inc/img/img/7.jpeg?refresh=20200516130000" /><div class="txt">德国餐饮业坚守近两月终“解冻” 业者喜忧参半</div></a>-->
</code>

<script type="text/javascript" language="javascript" src="inc/js_update.php?type=img"></script>
</body>
</html>