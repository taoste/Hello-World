<?php
$web['weather_step'] = '1';
$web['weather_from'] = 'www.tianqi.com';
?>