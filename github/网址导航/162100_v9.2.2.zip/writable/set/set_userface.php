<?php

//图片路径

$web['img_up_dir'] = 'writable/__temp__';

//截图类型（限jpg、gif、png）

$web['max_file_size'][15] = 300;
$web['img_up_format'] = 'gif';
$web['pic_quality'] = 75;  //上传图片质量

//截图命名

$web['img_name_s1'] = 'small1';

$web['img_name_s2'] = 'small2';

//截图尺寸（大、小二种，分宽、高）

$web['img_w_b'] = 96;

$web['img_h_b'] = 96;

$web['img_w_s'] = 48;

$web['img_h_s'] = 48;

?>