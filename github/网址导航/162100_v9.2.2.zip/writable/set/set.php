<?php
@ini_set('default_charset', 'utf-8');
@ini_set('display_errors', false);
error_reporting(E_ERROR | E_WARNING | E_PARSE);

$_GET = preg_replace('/[\r\n\'\"\>\<\&]+/i', '', $_GET);

/* ----------【网站设置】能不用尽量不要用特殊符号，如 \ / : ; * ? ' < > | ，必免导致错误--------- */

if (!isset($GLOBALS['WEATHER_DATA'])) {
  if (file_exists('writable/set/set.php')) {
    $GLOBALS['WEATHER_DATA'] = '';
  } else {
    $GLOBALS['WEATHER_DATA'] = '../../';
  }
}

//基本参数设置：

$web['manager'] = 'admin';  //基础管理员名称
$web['password'] = 'aa7e25f80cf4f64e990b78a9fc5ebd6c';  //基础管理员密码，注：系统出现一切故障时以基础管理员名称和密码为准
$web['code_author'] = strrev('moc.001261 yb derewoP -');  //作者
$web['sitehttp'] = 'http://'.(!empty($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] : $_SERVER['HTTP_HOST']).'/';  //站点网址
$web['root'] = '';
$web['path'] = dirname(trim($web['sitehttp'], '/').$_SERVER['REQUEST_URI'].'.abc').'/';  //路径
$web['sitename'] = '我的网址导航';  //站点名称
$web['sitename2'] = '我的网址';  //站点简称
$web['description'] = '网址导航，首选162100网址导航www.162100.com';  //站点描述
$web['keywords'] = '主页导航,上网导航,网址导航,绿色网址,网址之家,网址大全,网上黄页,集成搜索,一站式搜索';  //关键字
$web['slogan'] = '<link rel="icon" href="favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />';  //口号
$web['link_type'] = 0;  //通过export.php?url=链接路径 中转链接
$web['d_type'] = 0;  //关于首页网址弹出简介？0弹出1不弹
$web['login_key'] = array (
  'baidu' => '0',
  'qq' => '1',
  'weibo' => '0',
);
$web['chmod'] = '755';  //权限
$web['time_pos'] = '8北京，重庆，香港特别行政区，乌鲁木齐，台北';  //服务器时区调整
$web['cssfile'] = 'default/4';  //站点默认风格
$web['search_bar'] = 1;  //默认搜索引擎样式
$web['newinfo_url'] = array("http://info.162100.com/get_newinfo_for162100.php","http://info.162100.com/write.php"); //信息窗调用地址

//用户控制设置：

$web['stop_reg'] = 0;  //用户注册 1禁止 0不禁止 2注册需审核
$web['mail_send'] = 0;  //1发送邮件 0不发送
$web['stop_login'] = 0;  //用户登录密码错误限数 0不限
$web['addfunds'] = 0;  //1开启用户创收模式
$web['loginadd'] = 0.15;  //用户登陆（含注册）、推广URL来访本站赠送货币值
$web['loginadd2'] = 0.1;  //从上线分成
$web['loginadd_limit_ip'] = 1;  //每IP每日限注册次数计赠货币值
$web['cash'] = 10;  //用户提现需达到
$web['class_iron'] = 100; //铁级用户等级分标准
$web['class_silver'] = 500; //银级用户等级分标准
$web['class_gold'] = 1000; //金级用户等级分标准，大于此数量的为钻级用户

if (!function_exists('get_root_domain')) {
  if (file_exists($GLOBALS['WEATHER_DATA'].'readonly/function/get_root_domain.php')) {
    @ require ($GLOBALS['WEATHER_DATA'].'readonly/function/get_root_domain.php');
  }
}
$web['root'] = get_root_domain($web['sitehttp']);


?>