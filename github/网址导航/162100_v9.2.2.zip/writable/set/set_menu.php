<?php
$web['menu'] = array (
  0 => 
  array (
    'open' => 1,
    0 => 
    array (
      0 => '新闻频道',
      1 => 'https://www.hao123.com/star/news-iframe',
      2 => 1000,
      3 => 4000,
      4 => 1,
      5 => 'https://www.hao123.com/star/news-iframe',
      6 => 1190,
      7 => 2000,
      8 => 1,
    ),
    1 => 
    array (
      0 => '电影频道',
      1 => 'http://cdn.inf.v.360.cn/daohang/dianying.html',
      2 => '100%',
      3 => 1800,
      4 => 1,
      5 => 'http://www.hao123.com/syxqdh?menu=dianying',
      6 => 1190,
      7 => 2000,
      8 => 1,
    ),
    2 => 
    array (
      0 => '电视剧',
      1 => 'http://cdn.inf.v.360.cn/daohang/dianshi.html',
      2 => '100%',
      3 => 1800,
      4 => 1,
      5 => 'http://www.hao123.com/syxqdh?menu=dianshi',
      6 => 1190,
      7 => 2000,
      8 => 1,
    ),
    3 => 
    array (
      0 => '听音乐',
      1 => 'writable/__web__/yinyue.html',
      2 => 1000,
      3 => 622,
      4 => 1,
    ),
    4 => 
    array (
      0 => '小游戏',
      1 => 'http://g.360.cn/topbar.html',
      2 => '100%',
      3 => 4000,
      4 => 1,
      5 => 'http://xyx.hao123.com/xyxAutoIframe',
      6 => 1190,
      7 => 2000,
      8 => 1,
    ),
    5 => 
    array (
      0 => '看小说',
      1 => 'http://xiaoshuo.360.cn/index/indexIframe',
      2 => '100%',
      3 => 2000,
      4 => 1,
    ),
    6 => 
    array (
      0 => '购物直达',
      1 => 'http://yzsou.gouwuke.com/?chan=china&search=y&show=y&searchRange=1',
      2 => '100%',
      3 => 3000,
      4 => 1,
      5 => 'http://yzsou.gouwuke.com/?chan=china&search=y&show=y&searchRange=1',
      6 => '100%',
      7 => 3000,
      8 => 1,
    ),
    7 => 
    array (
      0 => '旅游度假',
      1 => '//www.ctrip.com/?AllianceID=5794&sid=150265&ouid=&app=0101F00',
      2 => '100%',
      3 => 2000,
      4 => 1,
      5 => '//www.ctrip.com/?AllianceID=5794&sid=150265&ouid=&app=0101F00',
      6 => '100%',
      7 => 2000,
      8 => 1,
    ),
  ),
);
?>