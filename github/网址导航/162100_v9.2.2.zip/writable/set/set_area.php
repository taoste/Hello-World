<?php


/*
$web['area']['mingz']['name'] = array('0频道名', 1拼音, 2详展数量（新版被取消）, 3置于边栏（模式1|2对齐1|2|3|4）);
$web['area']['mingz']['1'] =    array('0栏目名', 1拼音, 2着色背景,               3列表模式, 4首页展示否（如展示，网址数量（-1不展示/-2按分页|0所有|1-n行））);
*/

$web['area']['homepage']['name'] = array('首页版面', 'sybm', 0, 0);
$web['area']['homepage']['0'] = array('名站', 'mingzhan', 0, 0, 0);
$web['area']['homepage']['4'] = array('权威
推荐', 'tuijian', 1, 1, 0);
$web['area']['homepage']['3'] = array('实用
功能', 'shiyonggongneng', 5, 2, 0);
$web['area']['mingz']['name'] = array('快捷应用', 'kjyy', 0, 22);
$web['area']['mingz']['1'] = array('邮箱登陆', 'youxiangdenglu', 1, 2, 1);
$web['area']['mingz']['3'] = array('股市行情', 'gushixingqing', 2, 2, 1);
$web['area']['mingz']['4'] = array('彩票资讯', 'caipiaozixun', 3, 2, 1);
$web['area']['mingz']['6'] = array('今日要闻', 'jinriyaowen', 4, 2, 1);
$web['area']['mingz']['7'] = array('正品购物', 'zhengpingouwu', 5, 2, 1);
$web['area']['mingz']['8'] = array('住宿旅游', 'zhusulvyou', 6, 2, 1);
$web['area']['mingz']['9'] = array('听音乐', 'tingyinyue', 7, 2, 1);
$web['area']['mingz']['10'] = array('读小说', 'duxiaoshuo', 8, 2, 1);
$web['area']['mingz']['11'] = array('看电影', 'kandianying', 9, 2, 1);
$web['area']['mingz']['13'] = array('电视', 'dianshi', 2, 2, 1);
$web['area']['0']['name'] = array('休闲娱乐', 'xxyl', 0, 0);
$web['area']['0']['0'] = array('音乐', 'yinyue', 1, 1, 1);
$web['area']['0']['1'] = array('视频', 'shipin', 2, 0, 1);
$web['area']['0']['2'] = array('游戏', 'youxi', 3, 2, 1);
$web['area']['0']['3'] = array('小说', 'xiaoshuo', 4, 2, 2);
$web['area']['0']['4'] = array('交友', 'jiaoyou', 5, 2, -1);
$web['area']['0']['5'] = array('影视', 'yingshi', 6, 2, 1);
$web['area']['0']['6'] = array('动漫', 'dongman', 0, 2, -1);
$web['area']['0']['7'] = array('星座', 'xingzuo', 0, 2, -1);
$web['area']['0']['8'] = array('网游', 'wangyou', 7, 2, 2);
$web['area']['0']['9'] = array('体育', 'tiyu', 0, 2, -1);
$web['area']['0']['10'] = array('篮球', 'lanqiu', 0, 2, -1);
$web['area']['0']['11'] = array('足球', 'zuqiu', 0, 2, -1);
$web['area']['0']['12'] = array('明星', 'mingxing', 0, 2, -1);
$web['area']['0']['13'] = array('图片', 'tupian', 0, 2, -1);
$web['area']['0']['14'] = array('笑话', 'xiaohua', 0, 2, -1);
$web['area']['0']['15'] = array('聊天', 'liaotian', 0, 2, -1);
$web['area']['1']['name'] = array('生活服务', 'shfw', 0, 0);
$web['area']['1']['0'] = array('购物', 'gouwu', 1, 2, 1);
$web['area']['1']['1'] = array('旅游', 'lvyou', 2, 2, 1);
$web['area']['1']['2'] = array('美食', 'meishi', 3, 2, 1);
$web['area']['1']['3'] = array('汽车', 'qiche', 4, 2, 1);
$web['area']['1']['4'] = array('天气', 'tianqi', 0, 0, -1);
$web['area']['1']['5'] = array('通信', 'tongxin', 0, 0, -1);
$web['area']['1']['6'] = array('宠物', 'chongwu', 0, 1, -1);
$web['area']['1']['7'] = array('儿童', 'ertong', 0, 1, -1);
$web['area']['1']['8'] = array('女性', 'nvxing', 0, 2, -1);
$web['area']['1']['9'] = array('时尚', 'shishang', 0, 2, -1);
$web['area']['1']['10'] = array('两性', 'liangxing', 0, 2, -1);
$web['area']['1']['11'] = array('生活', 'shenghuo', 0, 2, -1);
$web['area']['1']['12'] = array('健康', 'jiankang', 0, 2, -1);
$web['area']['1']['13'] = array('礼品', 'lipin', 0, 1, -1);
$web['area']['1']['14'] = array('地图', 'ditu', 0, 1, -1);
$web['area']['1']['15'] = array('查询', 'chaxun', 0, 0, -1);
$web['area']['2']['name'] = array('电脑网络', 'dnwl', 0, 0);
$web['area']['2']['0'] = array('手机', 'shouji', 1, 0, 1);
$web['area']['2']['1'] = array('数码', 'shuma', 2, 0, 1);
$web['area']['2']['2'] = array('软件', 'ruanjian', 3, 0, 1);
$web['area']['2']['3'] = array('博客', 'boke', 4, 0, 1);
$web['area']['2']['4'] = array('电脑', 'diannao', 5, 0, 1);
$web['area']['2']['5'] = array('邮箱', 'youxiang', 0, 0, -1);
$web['area']['2']['6'] = array('硬件', 'yingjian', 0, 0, -1);
$web['area']['2']['7'] = array('论坛', 'luntan', 0, 0, -1);
$web['area']['2']['8'] = array('建站', 'jianzhan', 0, 0, -1);
$web['area']['2']['9'] = array('域名', 'yuming', 0, 0, -1);
$web['area']['2']['10'] = array('编程', 'biancheng', 6, 0, 1);
$web['area']['2']['11'] = array('搜索', 'sousuo', 0, 0, -1);
$web['area']['2']['12'] = array('设计', 'sheji', 0, 1, -1);
$web['area']['2']['13'] = array('桌面', 'zhuomian', 0, 0, -1);
$web['area']['2']['14'] = array('杀毒', 'shadu', 0, 1, -1);
$web['area']['2']['15'] = array('SEO', 'SEO', 0, 0, -1);
$web['area']['2']['16'] = array('IT', 'IT', 0, 2, -1);
$web['area']['2']['17'] = array('BT', 'BT', 0, 2, -1);
$web['area']['2']['18'] = array('Flash', 'Flash', 7, 2, 0);
$web['area']['2']['19'] = array('非主流', 'feizhuliu', 0, 0, -1);
$web['area']['3']['name'] = array('商业经济', 'syjj', 0, 0);
$web['area']['3']['0'] = array('股票', 'gupiao', 1, 2, 1);
$web['area']['3']['1'] = array('财经', 'caijing', 2, 2, 1);
$web['area']['3']['2'] = array('银行', 'yinhang', 3, 2, 1);
$web['area']['3']['3'] = array('房产', 'fangchan', 4, 2, 1);
$web['area']['3']['4'] = array('彩票', 'caipiao', 0, 2, -1);
$web['area']['3']['5'] = array('招聘', 'zhaopin', 0, 2, -1);
$web['area']['3']['6'] = array('保险', 'baoxian', 0, 2, -1);
$web['area']['3']['7'] = array('商务', 'shangwu', 0, 2, -1);
$web['area']['4']['name'] = array('社会文化', 'shwh', 0, 0);
$web['area']['4']['0'] = array('新闻', 'xinwen', 1, 2, 1);
$web['area']['4']['1'] = array('军事', 'junshi', 2, 2, 1);
$web['area']['4']['2'] = array('法律', 'falv', 3, 2, 1);
$web['area']['4']['3'] = array('教育', 'jiaoyu', 4, 2, 1);
$web['area']['4']['4'] = array('英语', 'yingyu', 0, 2, -1);
$web['area']['4']['5'] = array('考试', 'kaoshi', 0, 2, -1);
$web['area']['4']['6'] = array('高考', 'gaokao', 0, 2, -1);
$web['area']['4']['7'] = array('考研', 'kaoyan', 0, 2, -1);
$web['area']['4']['8'] = array('科技', 'keji', 0, 2, -1);
$web['area']['4']['9'] = array('人文', 'renwen', 0, 2, -1);
$web['area']['4']['10'] = array('宗教', 'zongjiao', 0, 2, -1);
$web['area']['4']['11'] = array('艺术', 'yishu', 0, 2, -1);
$web['area']['4']['12'] = array('曲艺', 'quyi', 0, 1, -1);
$web['area']['4']['13'] = array('留学', 'liuxue', 0, 0, -1);
$web['area']['4']['14'] = array('校园', 'xiaoyuan', 0, 0, -1);
$web['area']['4']['15'] = array('论文', 'lunwen', 0, 0, -1);
$web['area']['5']['name'] = array('其它类别', 'qtlb', 0, 0);
$web['area']['5']['0'] = array('行业', 'xingye', 1, 1, 1);
$web['area']['5']['1'] = array('公益', 'gongyi', 2, 1, 1);
$web['area']['5']['2'] = array('机构', 'jigou', 3, 0, 1);
$web['area']['5']['3'] = array('高校', 'gaoxiao', 4, 0, 2);
$web['area']['5']['4'] = array('国外网址', 'guowaiwangzhi', 0, 0, -1);
$web['area']['5']['5'] = array('地方服务', 'difangfuwu', 0, 0, -1);
$web['area']['5']['6'] = array('招商加盟', 'zhaoshangjiameng', 0, 0, -1);
$web['area']['5']['7'] = array('电视电台', 'dianshidiantai', 0, 0, -1);
$web['area']['6']['name'] = array('地方网站', 'dfwz', 0, 22);
$web['area']['6']['0'] = array('北京', 'beijing', 1, 0, 1);
$web['area']['6']['1'] = array('天津', 'tianjin', 2, 0, 1);
$web['area']['6']['2'] = array('上海', 'shanghai', 3, 0, 1);
$web['area']['6']['3'] = array('江苏', 'jiangsu', 4, 0, 1);
$web['area']['6']['4'] = array('浙江', 'zhejiang', 5, 0, 1);
$web['area']['6']['5'] = array('湖北', 'hubei', 6, 0, 1);
$web['area']['6']['6'] = array('广东', 'guangdong', 7, 0, 1);
$web['area']['6']['7'] = array('陕西', 'shanxi', 8, 0, 1);
$web['area']['6']['8'] = array('四川', 'sichuan', 9, 0, 1);
$web['area']['6']['9'] = array('重庆', 'chongqing', 1, 0, 1);
$web['area']['6']['10'] = array('辽宁', 'liaoning', 2, 0, 1);
$web['area']['6']['11'] = array('黑龙江', 'heilongjiang', 3, 0, 1);
$web['area']['6']['12'] = array('湖南', 'hunan', 4, 0, 1);
$web['area']['6']['13'] = array('安徽', 'anhui', 5, 0, 1);
$web['area']['6']['14'] = array('山西', 'shanxi2', 6, 0, 1);
$web['area']['6']['15'] = array('吉林', 'jilin', 7, 0, 1);
$web['area']['6']['16'] = array('福建', 'fujian', 8, 0, 1);
$web['area']['6']['17'] = array('河南', 'henan', 9, 0, 1);
$web['area']['6']['18'] = array('河北', 'hebei', 1, 0, 1);
$web['area']['6']['19'] = array('江西', 'jiangxi', 2, 0, 1);
$web['area']['6']['20'] = array('内蒙古', 'neimenggu', 3, 0, 1);
$web['area']['6']['21'] = array('广西', 'guangxi', 4, 0, 1);
$web['area']['6']['22'] = array('海南', 'hainan', 5, 0, 1);
$web['area']['6']['23'] = array('贵州', 'guizhou', 6, 0, 1);
$web['area']['6']['24'] = array('云南', 'yunnan', 7, 0, 1);
$web['area']['6']['25'] = array('西藏', 'xizang', 8, 0, 1);
$web['area']['6']['26'] = array('甘肃', 'gansu', 9, 0, 1);
$web['area']['6']['27'] = array('青海', 'qinghai', 1, 0, 1);
$web['area']['6']['28'] = array('宁夏', 'ningxia', 2, 0, 1);
$web['area']['6']['29'] = array('新疆', 'xinjiang', 3, 0, 1);
$web['area']['6']['30'] = array('山东', 'shandong', 4, 0, 1);
$web['area']['6']['31'] = array('港澳台', 'gangaotai', 5, 0, 1);

$web['mingz_align'] = array (
  0 => 6,
  1 => 'LEFT',
);
$web['kuz_align'] = array (
  0 => 5,
  1 => 'LEFT',
);

if (!function_exists('get_column_html')) {
  function get_column_html($column_id) {
    global $web;
    return $web['html'] == true ? ''.$web['area'][$column_id]['name'][1].'.html' : 'column.php?column_id='.$column_id.'';
  }
}
if (!function_exists('get_class_html')) {
  function get_class_html($column_id, $class_id) {
    global $web;
    return $web['html'] == true ? ''.$web['area'][$column_id]['name'][1].'_'.$web['area'][$column_id][$class_id][1].'.html' : 'class.php?column_id='.$column_id.'&class_id='.$class_id.'';
  }
}

?>