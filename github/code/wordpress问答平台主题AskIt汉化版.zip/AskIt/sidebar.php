<div id="sidebar">
	<div id="sidebar-bottom">
		<div id="sidebar-content">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('侧边栏') ) : ?> 
			<?php endif; ?>
		</div> <!-- end #sidebar-content -->
	</div> <!-- end #sidebar-bottom -->
</div> <!-- end #sidebar -->