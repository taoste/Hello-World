<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php if (is_page() || is_category()) { ?>
	<?php $tagline = get_post_meta($post->ID, 'Tagline', $single = true);
		  if (is_category()) $tagline = category_description();
		  if ($tagline <> '') {	?>
				<p class="tagline">
					<?php echo wp_kses( $tagline, array( 'span' => array() ) ); ?>
				</p>
		  <?php }; ?>	
<?php } elseif (is_single() && get_option('thecorporation_postinfo2') <> '') { ?>
	<p class="tagline">
		<span><?php if (in_array('author', get_option('thecorporation_postinfo2'))) { ?> <?php esc_html_e('作者：','TheCorporation'); ?> <?php the_author_posts_link(); ?><?php }; ?><?php if (in_array('date', get_option('thecorporation_postinfo2'))) { ?> <?php esc_html_e('日期：','TheCorporation'); ?> <?php the_time(get_option('thecorporation_date_format')) ?><?php }; ?><?php if (in_array('categories', get_option('thecorporation_postinfo2'))) { ?> <?php esc_html_e('栏目','TheCorporation'); ?> <?php the_category(', ') ?><?php }; ?><?php if (in_array('comments', get_option('thecorporation_postinfo2'))) { ?> | <?php comments_popup_link(esc_html__('0 comments','TheCorporation'), esc_html__('1 comment','TheCorporation'), '% '.esc_html__('comments','TheCorporation')); ?><?php }; ?></span>
	</p>
<?php }; ?>
<?php endwhile; endif; ?>