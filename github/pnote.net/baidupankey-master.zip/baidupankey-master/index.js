// main
module.exports = require('./lib/baidupan');