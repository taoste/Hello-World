function isPC() {
    var userAgentInfo = navigator.userAgent;
    var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");
    var flag = true;
    for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) >= 0) {
            flag = false;
            break;
        }
    }
    return flag;
}
//初始判断: 一加载页面就判断是否PC，是就进行跳转
if (isPC()) {
    window.location.href = "http://www.kfc.com.cn/kfccda/index.aspx";
}

//实现全屏
function resetPage() {
    var deviceWidth = document.documentElement.clientWidth;
    var scale = 1;

    if (deviceWidth >= 1024) //对应 "kfc-wifi-1024-768.css" => 横版
    {
        scale = deviceWidth / 1024;
    } else if (deviceWidth >= 768) //对应 "kfc-wifi-768-1024.css" => 竖版
    {
        scale = deviceWidth / 768;
    } else // if(deviceWidth > 640) //对应 "kfc-wifi-640-980.css" ... 样式
    {
        scale = deviceWidth / 640;
    }

    document.body.style.zoom = scale;
}

window.onresize = function () {
    resetPage();
}

$(function () {

    resetPage();

    //首页PV加载
    if (window.curChannel.channel == window.codeConsts.channel.ipad) {
        track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_page_pv);
    } else if (window.curChannel.channel == window.codeConsts.channel.android) {
        track2(window.curChannel.channel, window.codeConsts.androidCodes.android_page_pv);
    } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
        track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_page_pv);
    }

    //轮播图加载
    if (window.curChannel.channel == window.codeConsts.channel.ipad) {
        track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_lunbo_pv);
    } else if (window.curChannel.channel == window.codeConsts.channel.android) {
        track2(window.curChannel.channel, window.codeConsts.androidCodes.andriod_lunbo_pv);
    } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
        track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_lunbo_pv);
    }

    //走马灯文字加载
    if (window.curChannel.channel == window.codeConsts.channel.ipad) {
        track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_zoumadeng_pv);
    } else if (window.curChannel.channel == window.codeConsts.channel.android) {
        track2(window.curChannel.channel, window.codeConsts.androidCodes.android_zoumadeng_pv);
    } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
        track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_zoumadeng_pv);
    }



    AnimationObj.cursorImgs = [document.getElementById("cursorImgLink5"), document.getElementById("cursorImgLink4")];
    //轮播文字
    //AnimationObj.cursorTxts = [document.getElementById("cursorTextLink4"), document.getElementById("cursorTextLink3")];
    AnimationObj.cursorTxts = [document.getElementById("cursorImgLink5"), document.getElementById("cursorTextLink4")];
    AnimationObj.cursorCurIdx = 1;
    AnimationObj.cursorImgsIntervalFunc = function () {
        //alert(1);
        //切换动画
        $(".box-img").eq(AnimationObj.cursorCurIdx).fadeIn(0).siblings(".box-img").fadeOut(250);
        //按索引轮播文字
        $(".box-txt").eq(AnimationObj.cursorCurIdx).fadeIn(0).siblings(".box-txt").fadeOut(0);
        var nextIdx = (AnimationObj.cursorCurIdx + 1) % AnimationObj.cursorImgs.length;
        AnimationObj.cursorCurIdx = nextIdx;
    }
    window.setInterval(AnimationObj.cursorImgsIntervalFunc, 6000);

    AnimationObj.cursorImgsIntervalFunc();

});

var AnimationObj = {};

function browserRedirect() {
    //供应商
    var sUserAgent = navigator.userAgent.toLowerCase();
    //alert(sUserAgent);
    var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
    var bIsIphoneOs = sUserAgent.match(/iphone/i) == "iphone";
    var bIsAndroid = sUserAgent.match(/android/i) == "android";
    
    if (bIsIpad) {
        window.curChannel.channel = window.codeConsts.channel.ipad;
    } else if (bIsAndroid) {
        window.curChannel.channel = window.codeConsts.channel.android;
    } else if (bIsIphoneOs) {
        window.curChannel.channel = window.codeConsts.channel.iphone;
    } else {
        window.curChannel.channel = window.codeConsts.channel.unknown;
    }    
}

function loadListners() {
    //判断设备与渠道
    browserRedirect();
    //banner
    //var btn_imgCursors = document.getElementsByClassName("cursor-image-a");
    var btn_imgCursors = document.getElementsByClassName("box-img");
    for (var i = 0; i < btn_imgCursors.length; i++) {
        btn_imgCursors[i].channel = window.curChannel.channel;
        btn_imgCursors[i].onclick = function () { //轮播图点击
            var url = null;
            if (this.className.indexOf("cursor-image4") > -1) {
                url = "http://youhui.kfc.com.cn/mobile/";
            } else if (this.className.indexOf("cursor-image5") > -1) {                
                url = "http://m.kfc.com.cn/ttbj/poster";
            }

            if (window.curChannel.channel == window.codeConsts.channel.ipad) {
                track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_lunbo_click);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.ipadMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.android) {
                track2(window.curChannel.channel, window.codeConsts.androidCodes.android_lunbo_click);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.androidMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
                track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_lunbo_click);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.iphoneMsg, url);
            }            

        }
    }    
    var btn_txtlinks = document.getElementsByClassName("box-txt");
    for (var i = 0; i < btn_txtlinks.length; i++) {
        btn_txtlinks[i].channel = window.curChannel.channel;
        btn_txtlinks[i].onclick = function () { //走马灯文字-点击
            var url = null;
            if (this.className.indexOf("cursor-text4") > -1) {
                url = "http://youhui.kfc.com.cn/mobile/";
            } else {     
                url = "http://m.kfc.com.cn/ttbj/poster";
            }

            if (window.curChannel.channel == window.codeConsts.channel.ipad) {
                track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_zoumadeng_click);
                yumTrack(window.yumConsts.lunboStringEvent, window.yumConsts.ipadMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.android) {
                track2(window.curChannel.channel, window.codeConsts.androidCodes.android_zoumadeng_click);
                yumTrack(window.yumConsts.lunboStringEvent, window.yumConsts.androidMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
                track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_zoumadeng_click);
                yumTrack(window.yumConsts.lunboStringEvent, window.yumConsts.iphoneMsg, url);
            }

        }
    }

    //增加的焦点图显示
    var topbtn_download = document.getElementById("div-top-area0");
    if (topbtn_download) {

        topbtn_download.channel = window.curChannel.channel;
        topbtn_download.onclick = function () { //官方app下载-点击
            if (window.curChannel.channel == window.codeConsts.channel.ipad) {
                track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_guanfang_downloadnow);
                var url = "http://m.kfc.com.cn/kfcgy20150909/index.html";
                yumTrack(window.yumConsts.guanfangAppEvent, window.yumConsts.ipadMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.android) {
                track2(window.curChannel.channel, window.codeConsts.androidCodes.android_guanfang_downloadnow);
                var url = "http://m.kfc.com.cn/kfcgy20150909/index.html";
                window.location = url;
            } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
                track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_guanfang_downloadnow);
                var url = "http://m.kfc.com.cn/kfcgy20150909/index.html";
                yumTrack(window.yumConsts.guanfangAppEvent, window.yumConsts.iphoneMsg, url);
            }
        }
    }


    if (document.getElementById("div-top-area8")) {

        document.getElementById("div-top-area8").onclick = function () {
            var url = 'http://order.kfc.com.cn/mwos/?portalSource=BrandApp';
            if (window.curChannel.channel == window.codeConsts.channel.ipad) {
                //track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.ipadMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.android) {
                //track2(window.curChannel.channel, window.codeConsts.androidCodes.android_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.androidMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
                //track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.iphoneMsg, url);
            }
        }
    }
    if (document.getElementById("div-top-area9")) {

        document.getElementById("div-top-area9").onclick = function () {
            var url = 'http://m.kfc.com.cn/djry20151030/index.html';
            if (window.curChannel.channel == window.codeConsts.channel.ipad) {
                //track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.ipadMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.android) {
                //track2(window.curChannel.channel, window.codeConsts.androidCodes.android_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.androidMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
                //track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.iphoneMsg, url);
            }
        }
    }
    if (document.getElementById("div-top-area10")) {

        document.getElementById("div-top-area10").onclick = function () {
            var url = 'http://m.kfc.com.cn/rice20151029/index.html';
            if (window.curChannel.channel == window.codeConsts.channel.ipad) {
                //track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.ipadMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.android) {
                //track2(window.curChannel.channel, window.codeConsts.androidCodes.android_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.androidMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
                //track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.iphoneMsg, url);
            }
        }
    }
    if (document.getElementById("div-top-area11")) {

        document.getElementById("div-top-area11").onclick = function () {
            var url = 'http://m.kfc.com.cn/dpbj20151102/index.html';
            if (window.curChannel.channel == window.codeConsts.channel.ipad) {
                //track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.ipadMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.android) {
                //track2(window.curChannel.channel, window.codeConsts.androidCodes.android_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.androidMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
                //track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.iphoneMsg, url);
            }
        }
    }
    if (document.getElementById("div-top-area12")) {

        document.getElementById("div-top-area12").onclick = function () {
            var url = 'http://m.kfc.com.cn/double1120151102/index.html';
            if (window.curChannel.channel == window.codeConsts.channel.ipad) {
                //track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.ipadMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.android) {
                //track2(window.curChannel.channel, window.codeConsts.androidCodes.android_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.androidMsg, url);
            } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
                //track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_guanfang_downloadnow);
                yumTrack(window.yumConsts.lunboImgEvent, window.yumConsts.iphoneMsg, url);
            }
        }
    }
    //left-button
    var left_download = document.getElementById("left-button");
    left_download.channel = window.curChannel.channel;
    // left_download.onclick = function () {
    //     if (window.curChannel.channel == window.codeConsts.channel.ipad) {
    //         //   alert("ipad");
    //         track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_dingcan_downloadnow);
    //         var url = "https://lnk0.com/easylink/ELFdIBN9";
    //         yumTrack(window.yumConsts.dingcanAppEvent, window.yumConsts.ipadMsg, url);
    //     } else if (window.curChannel.channel == window.codeConsts.channel.android) {
    //         //  alert("android");
    //         track2(window.curChannel.channel, window.codeConsts.androidCodes.android_dingcan_downloadnow);
    //         window.location.href = "http://res.kfc.com.cn/KFCrefactoringAPP_V4.751_PROD_release_1224-04.apk";
    //         yumTrack(window.yumConsts.dingcanAppEvent, window.yumConsts.androidMsg, url);
    //     } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
    //         //  alert("iphone");
    //         track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_dingcan_downloadnow);
    //         var url = "https://lnk0.com/easylink/ELFdIBN9";
    //         yumTrack(window.yumConsts.dingcanAppEvent, window.yumConsts.iphoneMsg, url);
    //     }

    // }
    //right-button
    var right_download = document.getElementsByClassName("right-button")[0];
    right_download.channel = window.curChannel.channel;
    right_download.onclick = function () { //订餐app下载-点击 => 预付快取-下载点击
        var reg = new RegExp("(^|&)storeCode=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        var url = "http://order.kfc.com.cn/mwos/?portalSource=storewifi";
        if (r != null) {
            var storeCode = unescape(r[2]);
            var url = "http://order.kfc.com.cn/mwos/store/search?portalSource=storewifi&storeCode=" + storeCode;
        }
        yumTrack(window.yumConsts.dingcanAppEvent, window.yumConsts.ipadMsg, url);

    }

    //btn-weibo
    // var btn_weibo = document.getElementsByClassName("btn-weibo")[0];
    // btn_weibo.channel = window.curChannel.channel;
    // btn_weibo.onclick = function() {//关注微博-点击
    //  var url = "http://m.weibo.cn/u/1687422352?";
    //  if(window.curChannel.channel == window.codeConsts.channel.ipad)
    //  {
    //      track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_attention_weiboclick);
    //      yumTrack(window.yumConsts.sinaWebChatEvent, window.yumConsts.ipadMsg, url);
    //  }
    //  else if(window.curChannel.channel == window.codeConsts.channel.android)
    //  {
    //      track2(window.curChannel.channel, window.codeConsts.androidCodes.android_attention_weiboclick);
    //      yumTrack(window.yumConsts.sinaWebChatEvent, window.yumConsts.androidMsg, url);
    //  }
    //  else if(window.curChannel.channel == window.codeConsts.channel.iphone)
    //  {
    //      track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_attention_weiboclick);
    //      yumTrack(window.yumConsts.sinaWebChatEvent, window.yumConsts.iphoneMsg, url);
    //  }
    //  //window.location.href = "http://m.weibo.cn/u/1687422352?";
    // }
    //footer
    var btn_footer = document.getElementsByClassName("footer")[0];
    btn_footer.channel = window.curChannel.channel;
    btn_footer.onclick = function () { //跳转到官网-点击
        var url = "http://www.kfc.com.cn/kfccda/index.aspx?from=mobile";
        if (window.curChannel.channel == window.codeConsts.channel.ipad) {
            track2(window.curChannel.channel, window.codeConsts.ipadCodes.ipad_kendeji_guanfang_click);
            yumTrack(window.yumConsts.toPcPage, window.yumConsts.ipadMsg, url);
        } else if (window.curChannel.channel == window.codeConsts.channel.android) {
            track2(window.curChannel.channel, window.codeConsts.androidCodes.android_kendeji_guanfang_click);
            yumTrack(window.yumConsts.toPcPage, window.yumConsts.androidMsg, url);
        } else if (window.curChannel.channel == window.codeConsts.channel.iphone) {
            track2(window.curChannel.channel, window.codeConsts.iphoneCodes.iphone_kendeji_guanfang_click);
            yumTrack(window.yumConsts.toPcPage, window.yumConsts.iphoneMsg, url);
        }
        //window.location.href = "http://www.kfc.com.cn/kfccda/index.aspx?from=mobile";

    }
}

//...，，
window.yumConsts = {
    lunboImgEvent: "焦点图来源于KFC_Wifi",
    lunboStringEvent: "焦点文字来源于KFC_Wifi",
    guanfangAppEvent: "官方app下载来源于KFC_Wifi",
    dingcanAppEvent: "订餐app下载来源于KFC_Wifi",
    sinaWebChatEvent: "关注微博来源于KFC_Wifi",
    toPcPage: "跳转到PC网站来源于KFC_Wifi",
    androidMsg: "android来源于KFC_Wifi",
    ipadMsg: "ipad来源于KFC_Wifi",
    iphoneMsg: "iphone来源于KFC_Wifi"
};

window.curChannel = {};
window.curChannel.channel = window.codeConsts.channel.unknown;

loadListners();