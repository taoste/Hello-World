

$(document).ready(function(){

// 上部
    $("#c1_1_1").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '会员注册', 'wt.msg', '立即注册');
        }
    })
    $("#c1_1_2").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '外送', 'wt.msg', '外送按钮');
        }
    })
    $("#c1_1_3").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '手机自助点餐_F', 'wt.msg', '手机自助点餐_F');
        }
    })
    $("#c1_1_4").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '附近KFC', 'wt.msg', '附近KFC');
        }
    })
    $("#c1_1_5").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '优惠卷', 'wt.msg', '优惠卷');
        }
    })

// banner
    $(".li-image").eq(0).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner1', 'wt.msg', 'Banner1');
        }
    })
    $(".li-image").eq(1).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner2', 'wt.msg', 'Banner2');
        }
    })
    $(".li-image").eq(2).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner3', 'wt.msg', 'Banner3');
        }
    })
    $(".li-image").eq(3).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner4', 'wt.msg', 'Banner4');
        }
    })
    $(".li-image").eq(4).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner5', 'wt.msg', 'Banner5');
        }
    })

    $(".li-text").eq(0).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner1', 'wt.msg', 'Banner1');
        }
    })
    $(".li-text").eq(1).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner2', 'wt.msg', 'Banner2');
        }
    })
    $(".li-text").eq(2).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner3', 'wt.msg', 'Banner3');
        }
    })
    $(".li-text").eq(3).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner4', 'wt.msg', 'Banner4');
        }
    })
    $(".li-text").eq(4).click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', 'Banner5', 'wt.msg', 'Banner5');
        }
    })


// 下载
    $("#c1_2_1").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '官方APP下载', 'wt.msg', '官方APP下载');
        }
    })
    $("#c1_2_2").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '宅急送', 'wt.msg', '宅急送');
        }
    })
    $("#c1_2_3").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '手机自助点餐', 'wt.msg', '手机自助点餐');
        }
    })


// 底部
    $("#c1_3_1").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '早餐', 'wt.msg', '早餐');
        }
    })
    $("#c1_3_2").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '午餐', 'wt.msg', '午餐');
        }
    })
    $("#c1_3_3").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '下午茶', 'wt.msg', '下午茶');
        }
    })
    $("#c1_3_4").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '晚餐', 'wt.msg', '晚餐');
        }
    })
    $("#c1_3_5").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '夜宵', 'wt.msg', '夜宵');
        }
    })


// 20180321
// Daypart上方

    $("#jrwm").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '肯德基加盟_Daypart上方', 'wt.msg', '肯德基加盟_Daypart上方');
        }
    })

    $("#jrwm1").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '加入我们_Daypart上方', 'wt.msg', '加入我们_Daypart上方');
        }
    })

    $("#jrwm2").click(function(){
        if (window._tag) {
            _tag.dcsMultiTrack('wt.event', '访问电脑版_Daypart上方', 'wt.msg', '访问电脑版_Daypart上方');
        }
    })


});