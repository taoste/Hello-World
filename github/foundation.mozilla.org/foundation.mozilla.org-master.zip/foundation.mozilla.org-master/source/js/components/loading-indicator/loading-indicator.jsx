import React from 'react';

export default () => {
  return <div className="loading-indicator d-inline-block">
    <div className="dot"></div>
    <div className="dot"></div>
    <div className="dot"></div>
  </div>;
};
