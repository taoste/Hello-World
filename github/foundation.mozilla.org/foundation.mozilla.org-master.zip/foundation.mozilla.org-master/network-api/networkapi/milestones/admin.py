from django.contrib import admin

from networkapi.milestones.models import Milestone


admin.site.register(Milestone)
