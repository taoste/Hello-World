from django.apps import AppConfig


class BuyersguideConfig(AppConfig):
    name = 'buyersguide'
