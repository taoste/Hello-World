from django.apps import AppConfig


class FellowsConfig(AppConfig):
    name = 'fellows'
